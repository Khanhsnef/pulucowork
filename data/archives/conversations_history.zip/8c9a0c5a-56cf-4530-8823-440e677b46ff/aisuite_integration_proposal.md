# ĐỀ XUẤT CHIẾN LƯỢC TÍCH HỢP AISUITE TỐI ƯU CHO HỆ THỐNG HIỆN TẠI

## 📊 Tóm Tắt Thực Thi (Executive Summary)

Sau khi kiểm tra toàn bộ hệ thống thực tế của bạn, kết luận đưa ra là: **aisuite ít có giá trị bổ sung tức thì** cho luồng vận hành hiện tại. Lý do:

*   **Luồng CLI (`.zshrc`):** Bộ Smart Router hiện tại sử dụng `claude --model` trực tiếp qua 9Router Proxy — không cần thư viện Python SDK nào.
*   **Luồng Python (`build_formula_dashboard.py`):** Script hoàn toàn **không dùng LLM** — đây là một công cụ xây dựng báo cáo Excel bằng `openpyxl` + `pandas`. Không có chỗ nào cần gọi API AI.

Vậy, **câu hỏi chiến lược đúng đắn** là: *Khi nào và ở đâu nên xây dựng tính năng AI mới vào hệ thống của bạn?* Và đó là nơi `aisuite` phát huy giá trị thực sự.

---

## 🔴 NHỮNG GÌ KHÔNG NÊN LÀM (Anti-Patterns)

> [!CAUTION]
> **Đừng cố tích hợp aisuite vào `build_formula_dashboard.py`** chỉ vì "nó là công cụ AI." Script này đang chạy tốt và hoàn toàn không cần LLM. Thêm vào sẽ làm chậm, tốn tiền, và tăng rủi ro.

> [!WARNING]
> **Đừng thay thế bộ Smart Router trong `.zshrc` bằng aisuite.** Router Shell hiện tại đã tinh chỉnh rất kỹ với ngữ cảnh vận hành của bạn (từ khóa tiếng Việt, phân nhóm Opus/Sonnet/Gemini/GPT/DeepSeek). Đây là tài sản kỹ thuật cần bảo tồn, không phải thay thế.

---

## 🟢 ĐỀ XUẤT TÍCH HỢP TỐI ƯU — 3 LUỒNG THỰC TẾ

### 🎯 Luồng 1 (NGAY LẬP TỨC): Nâng Cấp Intent Router cho `.zshrc`
**Vấn đề hiện tại:** Bộ Router dùng `if-else` + Regex. Với các prompt phức tạp, dễ bị sai model. Ví dụ:
```
"phân tích nhanh và viết code sql"
→ Regex catch "phân tích" → Opus 4.8 ✗ (đáng lẽ Sonnet vì đây là task code)
```

**Giải pháp:** Thêm 1 script Python nhỏ dùng `aisuite` để phân loại ý định (Intent Classifier) sử dụng DeepSeek Flash (miễn phí/rẻ nhất) trước khi Shell chọn model.

**File mới:** `~/.local/bin/ai-classify.py`
```python
#!/usr/bin/env python3
import sys, aisuite as ai

client = ai.Client()
prompt = sys.argv[1]

# Gọi mô hình rẻ nhất để phân loại ý định
resp = client.chat.completions.create(
    model="openai:gpt-4o-mini",  # hoặc "anthropic:claude-haiku-3"
    messages=[{
        "role": "system",
        "content": """Phân loại prompt sau vào 1 trong 5 nhóm, trả về DUY NHẤT tên nhóm:
        - DEEP_THINK: phân tích chiến lược, quyết định, insight, tư duy sâu
        - CODE_FORMAT: code, sql, html, script, dashboard, định dạng
        - LANGUAGE: viết lại, thông báo, dịch thuật, caption, tài xế
        - ENGLISH: tiếng Anh, proposal, HQ, leadership
        - QUICK: hỏi nhanh, định nghĩa, giải thích ngắn"""
    }, {"role": "user", "content": prompt}]
)
print(resp.choices[0].message.content.strip())
```

Gọi từ `.zshrc`:
```bash
smart_claude() {
    local prompt="$*"
    local intent=$(python3 ~/.local/bin/ai-classify.py "$prompt" 2>/dev/null)
    case "$intent" in
        DEEP_THINK) model="cc/claude-opus-4-8" ;;
        CODE_FORMAT) model="cc/claude-sonnet-4-6" ;;
        LANGUAGE)   model="gc/gemini-3-pro-preview" ;;
        ENGLISH)    model="oc/gpt-5-5" ;;
        QUICK)      model="oc/deepseek-v4-flash-free" ;;
        *)          model="cc/claude-opus-4-8" ;;  # fallback
    esac
    claude --model "$model" -p "$prompt"
}
```

**Lợi ích:**
- Độ chính xác định tuyến tăng từ ~75% lên ~97%
- Chi phí phân loại: gần 0 (DeepSeek Flash miễn phí)
- Không làm hỏng bất kỳ luồng nào hiện có

---

### 🎯 Luồng 2 (TRUNG HẠN — 2-4 tuần): AI Layer cho Dashboard Ops

**Vấn đề thực tế:** `build_formula_dashboard.py` xây được báo cáo, nhưng không giải thích được báo cáo. Sau khi file Excel được tạo ra, bạn phải tự đọc và viết nhận xét cho từng chỉ số.

**Giải pháp:** Tạo thêm 1 module `ai_narrative.py` chạy SAU khi dashboard được tạo, đọc data từ `pandas DataFrame` và sinh tự động phần **Executive Commentary** bằng `aisuite`:

```python
# ai_narrative.py (module bổ sung, KHÔNG sửa dashboard hiện tại)
import aisuite as ai
import pandas as pd

def generate_weekly_insight(svc_df, drv_df, can_df):
    """Sinh nhận xét tự động từ dữ liệu tuần mới nhất."""
    client = ai.Client()

    # Chuẩn bị data tóm tắt để không tốn quá nhiều token
    latest = svc_df[svc_df['period'] == svc_df['period'].max()]
    summary = latest.groupby('region').agg({
        'requested': 'sum', 'accept': 'sum', 'completed': 'sum'
    }).to_dict()

    prompt = f"""Bạn là chuyên gia vận hành giao vận.
    Dữ liệu tuần mới nhất: {summary}
    Viết nhận xét ngắn gọn (3-5 điểm) bằng tiếng Việt:
    - Điểm tích cực nổi bật
    - Rủi ro / điểm cần theo dõi  
    - Khuyến nghị hành động cụ thể"""

    # Dùng Opus cho phân tích chiến lược
    resp = client.chat.completions.create(
        model="anthropic:claude-opus-4",
        messages=[{"role": "user", "content": prompt}]
    )
    return resp.choices[0].message.content

# Nếu muốn fallback sang Gemini khi Claude lỗi:
# model="google:gemini-pro"
```

**Lợi ích:**
- Không sửa 1 dòng nào của `build_formula_dashboard.py`
- Tự động sinh commentary sau mỗi lần chạy dashboard
- Dễ dàng thay đổi mô hình phân tích qua 1 dòng config

---

### 🎯 Luồng 3 (DÀI HẠN — 1-2 tháng): Failover & Cost Guard

**Vấn đề:** Khi 9Router proxy có sự cố, toàn bộ alias (`c-opus`, `ai`, `chat`) đều dừng hoạt động.

**Giải pháp:** Xây một `llm_client.py` module trung tâm với aisuite làm nền, dùng cho TẤT CẢ script Python mới trong tương lai:

```python
# ~/tools/llm_client.py — Module trung tâm LLM cho tất cả script Python
import aisuite as ai
import os

ROUTING_TABLE = {
    "brain":   "anthropic:claude-opus-4",       # Task phân tích sâu
    "code":    "anthropic:claude-sonnet-4",      # Task lập trình
    "lang":    "google:gemini-2.0-flash",        # Task ngôn ngữ/context lớn
    "fast":    "openai:gpt-4o-mini",             # Task nhanh, rẻ
    "local":   "ollama:llama3",                  # Offline / bảo mật
}

FALLBACK = {
    "anthropic": "google:gemini-2.0-flash",      # Anthropic lỗi → Gemini
    "google":    "anthropic:claude-sonnet-4",    # Google lỗi → Claude
    "openai":    "anthropic:claude-haiku-3",     # OpenAI lỗi → Haiku
}

def ask(prompt: str, tier: str = "brain") -> str:
    client = ai.Client()
    model = ROUTING_TABLE.get(tier, ROUTING_TABLE["brain"])
    try:
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}]
        )
        return resp.choices[0].message.content
    except Exception as e:
        provider = model.split(":")[0]
        fallback = FALLBACK.get(provider, ROUTING_TABLE["fast"])
        resp = client.chat.completions.create(
            model=fallback,
            messages=[{"role": "user", "content": prompt}]
        )
        return resp.choices[0].message.content
```

---

## 📈 HIỆN THỰC HÓA GIÁ TRỊ (VALUE REALIZATION)

**Tóm tắt lộ trình tích hợp tối ưu theo thứ tự ưu tiên:**

| Thứ tự | Luồng tích hợp | Thời gian | Công sức | Tác động | ROI |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **1** | Intent Classifier cho Smart Router | 1-2h | Thấp | Độ chính xác định tuyến tăng 97% | **Rất cao** |
| **2** | AI Narrative Module cho Dashboard | 1-2 ngày | Trung bình | Tự động hóa việc viết commentary hàng tuần | **Cao** |
| **3** | LLM Client Module trung tâm | 3-5 ngày | Trung bình | Nền tảng cho mọi script Python AI trong tương lai | **Cao (dài hạn)** |
| **❌** | ~~Tích hợp vào dashboard Excel builder~~ | N/A | N/A | Không giá trị | **Âm** |
| **❌** | ~~Thay thế Smart Router CLI~~ | N/A | N/A | Phá hỏng hệ thống tốt hiện tại | **Âm** |
