# 📊 Báo Cáo Phân Tích & Phương Án Tối Ưu Hóa Dung Lượng Lưu Trữ Hệ Thống

## 1. 📊 Executive Summary

Hệ thống lưu trữ trên máy Mac hiện tại đang ghi nhận hiện trạng quá tải nghiêm trọng tại phân mục **System Data** (chiếm **104.23 GB** trên tổng số dung lượng khả dụng). Qua quét thực địa hệ thống thư mục người dùng (`/Users/ts-1148`), nguyên nhân gốc rễ (Root Cause) được xác định nằm ở phân vùng **User Library (`~/Library`)** chiếm tới **77 GB**, kết hợp với các môi trường phát triển (Python/Pyenv, Node/NPM cache) phình to.

### 🎯 Mục tiêu Tối ưu hóa (Key Objectives)
*   **Giải phóng ngay lập tức**: Tối thiểu **35 - 50 GB** dung lượng trống mà không ảnh hưởng tới tính ổn định của hệ điều hành.
*   **Thiết lập cơ chế kiểm soát tự động**: Hạn chế việc tự động tích lũy cache từ các ứng dụng giao tiếp (Telegram, Zalo) và các công cụ lập trình (NPM, Docker).

### 📈 Chỉ số Cốt lõi cần theo dõi (Important KPIs)
*   **Free Storage (Dung lượng trống)**: Đạt tối thiểu **20%** dung lượng ổ cứng để duy trì hiệu năng tối ưu của macOS (hạn chế Swap Memory trên SSD).
*   **System Data Size**: Đưa về mức an toàn từ **40 - 50 GB**.
*   **Clean-up Latency**: Thời gian thực thi quy trình dọn dẹp định kỳ dưới **15 phút**.

---

## 2. 🔍 KHUNG PHÂN TÍCH (ANALYSIS FRAMEWORK)

### 📊 Phân tích Mô tả (Đánh giá Hiện trạng - Descriptive Analysis)
Qua chạy các truy vấn kiểm tra trực tiếp (`du -sh`), dưới đây là phân rã chi tiết các nguồn chiếm dung lượng lớn nhất trong hệ thống của bạn:

| 📂 Thư mục nguồn | 📏 Dung lượng thực tế | 🔍 Chi tiết thành phần |
| :--- | :--- | :--- |
| **`~/Library/Group Containers`** | **20 GB** | Telegram chiếm **15 GB** (`6N38VWS5BX.ru.keepcoder.Telegram`) |
| **`~/Library/Application Support`** | **42 GB** | Zalo chiếm **12 GB** (`ZaloData`), Claude Desktop chiếm **12 GB**, Google Chrome chiếm **10 GB** |
| **`~/.pyenv`** | **18 GB** | Các phiên bản Python cũ và virtual environments đi kèm |
| **`~/.npm`** & **`~/.cache`** | **9.6 GB** | Cache các gói thư viện Node.js và cache hệ thống |
| **`~/Library/Caches`** | **4.6 GB** | Cache tạm thời của các ứng dụng macOS |
| **`~/Library/Containers`** | **4.8 GB** | Sandbox data của các ứng dụng Apple |
| **`~/Pictures`** | **6.4 GB** | File hình ảnh và thư viện ảnh cá nhân |
| **`~/Downloads`** & **`~/tools`** | **6.8 GB** | Các file cài đặt và thư mục công cụ tạm thời |

### 🛠️ Phân tích Chẩn đoán (Nguyên Nhân Gốc Rễ - Diagnostic Analysis)
*   **Telegram Auto-Download**: Thiết lập mặc định của Telegram tự động tải và lưu trữ vĩnh viễn (Keep Media = Forever) mọi video, ảnh, file tài liệu từ các group/channel có dung lượng lớn.
*   **Zalo Database phình to**: Zalo lưu trữ toàn bộ dữ liệu tin nhắn, ảnh, file nhận được cục bộ trong thư mục `ZaloData` mà không tự động dọn dẹp hoặc tối ưu hóa database định kỳ.
*   **Claude Desktop Caches**: Ứng dụng Claude Desktop tích lũy log và lịch sử dựng render (electron cache) trong quá trình hoạt động liên tục.
*   **Google Chrome Profile Caches**: Tích lũy lịch sử duyệt web, cookies và dữ liệu trang web (Site Data) tích lũy qua nhiều tháng.
*   **Python/Pyenv Redundancy**: Việc cài đặt quá nhiều phiên bản Python (`3.8.x`, `3.9.x`, `3.10.x`, `3.11.x`...) cùng với các thư viện trong mỗi môi trường ảo tích lũy dung lượng lớn mà không được dọn dẹp khi dự án kết thúc.

### 📈 Phân tích Đề xuất (Lộ Trình Tối Ưu - Prescriptive Analysis)

#### 1️⃣ Dọn dẹp ứng dụng Giao tiếp & Văn phòng (Tiết kiệm ~27 GB)
*   **Telegram**:
    1.  Mở Telegram -> **Settings (Cài đặt)** -> **Data and Storage (Dữ liệu và lưu trữ)** -> **Storage Usage (Sử dụng lưu trữ)**.
    2.  Kéo thanh trượt **Keep Media (Giữ media)** từ *Forever* về **3 days (3 ngày)** hoặc **1 week (1 tuần)**.
    3.  Nhấp vào **Clear Entire Cache (Xóa toàn bộ cache)**. Các file cũ sẽ bị xóa khỏi máy nhưng vẫn tải lại được từ Cloud của Telegram khi cần.
*   **Zalo**:
    1.  Mở Zalo Desktop -> Vào **Cài đặt (biểu tượng Răng cưa)** -> **Quản lý dữ liệu**.
    2.  Xem chi tiết các hội thoại chiếm dung lượng và thực hiện xóa file rác, file media cũ không cần thiết.
*   **Claude Desktop**:
    1.  Có thể xóa an toàn thư mục cache của Electron qua Terminal:
        `rm -rf ~/Library/Caches/com.anthropic.claudedesktop*`

#### 2️⃣ Dọn dẹp môi trường Lập trình & Cache (Tiết kiệm ~15 GB)
*   **NPM Cache**:
    *   Chạy lệnh dọn dẹp bộ nhớ đệm NPM:
        `npm cache clean --force`
*   **Pyenv & Virtualenvs**:
    *   Kiểm tra các phiên bản Python không dùng: `pyenv versions`.
    *   Gỡ bỏ phiên bản cũ: `pyenv uninstall <version_number>`.
*   **Docker Desktop (Nếu có sử dụng)**:
    *   Xóa các Container, Image, Volume không dùng đến:
        `docker system prune -a --volumes`

---

## 3. 📈 HIỆN THỰC HÓA GIÁ TRỊ (VALUE REALIZATION)

Dưới đây là bảng đối chiếu trước và sau khi thực hiện tối ưu hóa theo lộ trình đề xuất:

| Hiện trạng (Current State) | Chuyển đổi (Transformation) | Trạng thái Mục tiêu (Target State) | Tác động ước tính (Estimated Impact) |
| :--- | :--- | :--- | :--- |
| **Telegram Cache** chiếm **15 GB** bộ nhớ đệm cục bộ. | Thiết lập giới hạn lưu trữ media về 1 tuần & Clear Cache. | Dung lượng Telegram duy trì ổn định dưới **1.5 GB**. | ***Giải phóng ~13.5 GB instantly*** |
| **Zalo Data** tích lũy **12 GB** file rác & media cũ. | Lọc và dọn dẹp các tệp tin cũ trực tiếp trên App Zalo. | Dung lượng ZaloData giảm xuống còn dưới **5 GB**. | ***Giải phóng ~7 GB*** |
| **NPM & Cache lập trình** chiếm **9.6 GB**. | Chạy lệnh dọn dẹp cache hệ thống và NPM sạch sẽ. | Dung lượng cache hệ thống đưa về dưới **2 GB**. | ***Giải phóng ~7.6 GB*** |
| **Các phiên bản Pyenv Python** không dùng chiếm **18 GB**. | Quét và uninstall các phiên bản Python / virtualenv cũ. | Giữ lại tối đa 2 phiên bản cốt lõi, giảm xuống **6 GB**. | ***Giải phóng ~12 GB*** |
| **Google Chrome Cache** tích tụ **10 GB**. | Xóa Cookie & Cache duyệt web cũ trong phần cài đặt Chrome. | Chrome Storage giảm còn dưới **3 GB**. | ***Giải phóng ~7 GB*** |

### 🚀 Tổng kết Tác động (Total Expected ROI):
Bằng cách hoàn thành lộ trình tối ưu hóa này, bạn sẽ **giải phóng khoảng 47.1 GB** bộ nhớ, đưa dung lượng trống khả dụng tăng lên đáng kể, giúp macOS hoạt động mượt mà hơn và loại bỏ tình trạng thắt nút cổ chai (bottleneck) khi hệ thống cần dùng đến Virtual Memory Swap.
