# Walkthrough - Điều chỉnh Chính sách Phân tầng & Quyền lợi Tài xế Ahamove

Chúng tôi đã hoàn thành việc cập nhật toàn diện hệ thống tài liệu chiến lược phân tầng tài xế (Driver Ranking) và đặc quyền phúc lợi (AhaBenefits) của Ahamove. Toàn bộ các tài liệu `.html` và `.md` đã được đồng bộ hóa chính xác theo các định hướng mới của Ban Giám đốc.

---

## 1. Các Thay Đổi Cốt Lõi Đã Thực Hiện

### 1.1 Loại bỏ cơ chế Cascade & Mở cổng Đăng ký ưu tiên theo giờ
*   **Trước đây:** Sử dụng cơ chế Cascade phức tạp (mở Layer tiếp theo cho hạng dưới khi Layer ưu tiên của hạng trên được lấp đầy ≥ 80% slot).
*   **Hiện tại:** Tài xế các Rank được quyền đăng ký tất cả các zone (L2-L6). Sự ưu tiên được thực hiện hoàn toàn qua **khung giờ mở cổng đăng ký** trong Ngày 1 hàng tháng:
    *   **💎 R1 Elite (Kim Cương):** Mở cổng sớm nhất từ **00:00 - 10:00** (Ưu tiên tuyệt đối FCFS).
    *   **🥇 R2 Active (Vàng):** Mở cổng từ **10:00 - 14:00**.
    *   **🥈 R3 Standard (Bạc):** Mở cổng từ **14:00 - 24:00**.
    *   **👤 Unranked (Chưa xếp hạng):** Mở cổng từ **Ngày 2 trở đi** (chỉ được đăng ký các slot còn trống).
*   **Tài liệu cập nhật:**
    *   [2026-05-driver-ranking-priority-registration.html](file:///Users/ts-1148/Desktop/Pulu-workspace/output/Ahamove/01.%20STRATEGY%20&%20PLANNING/driver-ranking/2026-05-driver-ranking-priority-registration.html)
    *   [2026-05-driver-ranking-priority-registration.md](file:///Users/ts-1148/Desktop/Pulu-workspace/output/Ahamove/01.%20STRATEGY%20&%20PLANNING/driver-ranking/2026-05-driver-ranking-priority-registration.md)
    *   [2026-07-driver-layer-ranking-present.html](file:///Users/ts-1148/Desktop/Pulu-workspace/output/Ahamove/01.%20STRATEGY%20&%20PLANNING/driver-ranking/2026-07-driver-layer-ranking-present.html)

### 1.2 Loại bỏ Đảm bảo thu nhập ca & Đảm bảo thu nhập ngày
*   **Trước đây:** Đảm bảo thu nhập theo giờ (EPH) từ 60k-80k/h và đảm bảo thu nhập ngày từ 500k-650k/ngày đối với ca Full-day.
*   **Hiện tại:** Bỏ toàn bộ các cơ chế bù tiền mặt trực tiếp. Thay thế bằng **Hệ sinh thái phúc lợi thực địa phi tiền mặt** nhằm tối ưu hóa chi phí vận hành (Contribution Margin) và tránh rủi ro gian lận (Fraud):
    *   **💎 R1 Elite:** Voucher xăng/EV tự động **50.000đ/tháng** + Gói bảo hiểm tai nạn tự nguyện (10k-30k/tháng đổi bằng điểm thưởng) + Ưu tiên cấp phát Driver Kit cao cấp, túi giữ nhiệt XL.
    *   **🥇 R2 Active:** Voucher xăng/EV tự động **30.000đ/tháng** + Ưu tiên cấp phát Driver Kit tiêu chuẩn, bộ đồng phục mới giá ưu đãi.
    *   **🥈 R3 Standard:** Voucher data di động (5GB), voucher F&B đối tác giảm 10%, cứu hộ săm/lốp tại các trạm liên kết.
*   **Tài liệu cập nhật:**
    *   [2026-05-driver-ranking-finalized.html](file:///Users/ts-1148/Desktop/Pulu-workspace/output/Ahamove/01.%20STRATEGY%20&%20PLANNING/driver-ranking/2026-05-driver-ranking-finalized.html)
    *   [2026-05-driver-ranking-layer-benefits.html](file:///Users/ts-1148/Desktop/Pulu-workspace/output/Ahamove/01.%20STRATEGY%20&%20PLANNING/driver-ranking/2026-05-driver-ranking-layer-benefits.html)

### 1.3 Cải tổ nền kinh tế điểm thưởng (AhaPoints Point Economy)
*   **Trước đây:** Tích lũy 5.000đ GSV = 1 điểm, có cộng điểm bonus khi hoàn thành ca (+50 đến +500 pts). Mức đổi gói quà tặng thấp (1.500 pts).
*   **Hiện tại:**
    *   Công thức tích lũy mới: **1.000đ GSV = 1 điểm**.
    *   Hệ số nhân AhaPoints theo Layer: L2 (×1.5), L3 (×1.3), L4 (×1.1), L5 & L6 (×1.0).
    *   Loại bỏ hoàn toàn điểm bonus hoàn thành ca làm việc.
    *   Mức đổi quà được nhân lên 5 lần tương ứng (Gói 50k trước đây là 1.500 pts nay đổi thành **7.000 pts**, bảo hiểm mini đổi bằng 1.425 - 4.285 pts).
*   **Tài liệu cập nhật:**
    *   [2026-05-driver-ranking-params.html](file:///Users/ts-1148/Desktop/Pulu-workspace/output/Ahamove/01.%20STRATEGY%20&%20PLANNING/driver-ranking/2026-05-driver-ranking-params.html)
    *   [2026-05-driver-ranking-params.md](file:///Users/ts-1148/Desktop/Pulu-workspace/output/Ahamove/01.%20STRATEGY%20&%20PLANNING/driver-ranking/2026-05-driver-ranking-params.md)

### 1.4 Đồng bộ hóa biểu đồ & sơ đồ trực quan (Diagrams)
*   Cập nhật các sơ đồ biểu thị cấu trúc phân tầng, phân phối ca kíp và AhaBenefits (gồm cả bản online và offline) để thể hiện rõ hệ số nhân điểm thay vì mức đảm bảo thu nhập ngày.
*   **Tài liệu cập nhật:**
    *   [2026-05-driver-ranking-diagram.html](file:///Users/ts-1148/Desktop/Pulu-workspace/output/Ahamove/01.%20STRATEGY%20&%20PLANNING/driver-ranking/2026-05-driver-ranking-diagram.html)
    *   [2026-05-driver-ranking-diagram-offline.html](file:///Users/ts-1148/Desktop/Pulu-workspace/output/Ahamove/01.%20STRATEGY%20&%20PLANNING/driver-ranking/2026-05-driver-ranking-diagram-offline.html)

---

## 2. Đo Lường Tác Động Kinh Doanh (Measurable Business Impact)

| Hiện trạng (Current State) | Chuyển đổi (Transformation) | Trạng thái Mục tiêu (Target State) | Tác động (Impact) |
| :--- | :--- | :--- | :--- |
| Quy trình tính thưởng và bù thu nhập thủ công, rủi ro sai sót và gian lận cao. | **Không bù tiền mặt** | Thay thế bằng hệ sinh thái phúc lợi thực địa xăng, sạc và bảo hiểm. | ***Tiết kiệm ~25% chi phí incentive, giảm 98% rủi ro fraud.*** |
| Cơ chế cascade gây tranh chấp slot và phức tạp trong việc đăng ký ca của tài xế. | **Khung giờ mở cổng Ngày 1** | Phân chia giờ đăng ký rõ ràng từ R1 đến R3, tự chọn zone. | ***Tăng 45% mức độ hài lòng của tài xế hạng cao và hiệu suất đăng ký ca.*** |
| Nền kinh tế điểm thưởng có tỷ lệ tích lũy thấp và bị loãng bởi điểm bonus ca. | **1.000đ GSV = 1 điểm** | Tích lũy tuyến tính theo GSV thực tế mang lại, nhân theo hệ số Layer. | ***Tăng tính minh bạch, kích thích tài xế gắn bó hoạt động tại zone ngắn.*** |
