# Tự động hóa toàn diện cho Cowork Project

Kế hoạch này triển khai đồng thời 5 đề xuất từ `claude-code-setup` để biến thư mục `Cowork` thành một Knowledge & Ops Workspace có mức độ tự động hóa cao.

## Proposed Changes

### MCP Servers
Cấu hình `.claude/settings.json` để thêm 2 MCP Servers nhằm giúp Claude có thể đọc ghi Database và Google Sheets.

#### [MODIFY] [settings.json](file:///Users/ts-1148/Desktop/Cowork/.claude/settings.json)
Thêm vào `mcpServers`:
- **google-sheets**: Dùng npx chạy `@gongrzhe/server-google-sheets-mcp`
- **sqlite**: Dùng npx chạy `@modelcontextprotocol/server-sqlite` trỏ vào `data/state_store.db` (Nếu có database này).

---

### Hooks (Bảo mật thư mục)
Bổ sung PreToolUse Hook để ngăn Claude Code "lỡ tay" ghi đè các file đồng bộ quan trọng.

#### [MODIFY] [settings.json](file:///Users/ts-1148/Desktop/Cowork/.claude/settings.json)
Thêm vào block `"hooks"`:
- `PreToolUse`: Khi matcher là `Edit|Write`, chạy script Python kiểm tra `file_path`. Nếu nằm trong thư mục `_scripts/`, sẽ return exit code 1 để chặn thao tác sửa đổi.

---

### Mở Rộng Hệ Thống Kỹ Năng (Skills)
Dạy cho hệ thống cách tự động hóa hai nghiệp vụ lõi thường xuyên bị làm thủ công. Sẽ tạo thư mục và file `SKILL.md` cho từng cái.

#### [NEW] [ahamove-brief/SKILL.md](file:///Users/ts-1148/Desktop/Cowork/.claude/skills/ahamove-brief/SKILL.md)
**Nhiệm vụ**: Chuyển data/thông số thô thành Ops One-Pager chuẩn form Ahamove (áp dụng mô hình Pyramid). Sinh ra file HTML/Docx ngay lập tức.

#### [NEW] [sql-to-report/SKILL.md](file:///Users/ts-1148/Desktop/Cowork/.claude/skills/sql-to-report/SKILL.md)
**Nhiệm vụ**: Đóng gói quy trình từ việc viết SQL query -> chạy lấy kết quả (qua SQLite MCP) -> build file báo cáo biểu đồ HTML.

---

### Trợ Lý Phụ (Subagents)
Tạo thêm agent review SQL để đảm bảo chất lượng truy vấn.

#### [NEW] [sql-reviewer.md](file:///Users/ts-1148/Desktop/Cowork/.claude/agents/sql-reviewer.md)
**Nhiệm vụ**: Rà soát các file SQL, kiểm tra logic lỗi, index, cảnh báo sai schema theo chuẩn Ahamove trước khi lưu file.

## User Review Required

> [!IMPORTANT]
> **MCP Servers có thể cần cấp quyền (OAuth)**: Đối với Google Sheets MCP, sau khi cài, lần đầu tiên sử dụng bạn có thể sẽ phải đăng nhập tài khoản Google để cấp quyền truy cập. Bạn đã sẵn sàng làm việc này chưa?

## Verification Plan

### Automated Tests
- Cấu trúc JSON của `settings.json` sẽ được Validate để đảm bảo không bị syntax error.

### Manual Verification
- Sẽ gọi thử lệnh `ls .claude/skills` và `ls .claude/agents` để xác nhận đã tạo đủ file.
- Sẽ kiểm tra terminal output xem các thư mục đã được khởi tạo hay chưa.
