# Tự động hóa toàn diện cho Cowork Project

- `[x]` Cấu hình file `.claude/settings.json`
  - `[x]` Thêm Google Sheets MCP Server
  - `[x]` Thêm SQLite MCP Server
  - `[x]` Thêm PreToolUse Hook chặn thư mục `_scripts/`
- `[x]` Mở rộng hệ thống Skills
  - `[x]` Tạo skill `ahamove-brief`
  - `[x]` Tạo skill `sql-to-report`
- `[x]` Tạo Subagents
  - `[x]` Tạo file `sql-reviewer.md`
