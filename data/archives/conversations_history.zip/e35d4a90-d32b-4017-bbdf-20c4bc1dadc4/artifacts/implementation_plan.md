# Kế hoạch Triển khai: WORLD 3D Dashboard

Tôi sẽ xây dựng một dashboard bản đồ 3D tương tác giống như trong ảnh (WORLD 3D) bằng công nghệ web hiện đại. Vì bạn không yêu cầu cụ thể framework nào (như Next.js hay React), tôi sẽ sử dụng **HTML, Vanilla JavaScript và CSS** để đảm bảo tính gọn nhẹ, linh hoạt, chạy trực tiếp trên trình duyệt mà không cần cài đặt node_modules rườm rà.

## User Review Required
> [!IMPORTANT]
> - **Dữ liệu (Data):** Tôi sẽ tạo dữ liệu giả lập (mock data) tọa độ tại khu vực Đà Nẵng (DAD) và danh sách Top 20 Khách hàng giống như trong hình để bạn trải nghiệm. Sau này bạn có thể thay thế bằng API thật của hệ thống.
> - **Bản đồ nền (Basemap):** Sẽ sử dụng bản đồ nền tối (Dark mode basemap) miễn phí từ CartoDB (Dark Matter) để không yêu cầu API Key của Mapbox.
> - **Công nghệ 3D:** Sử dụng thư viện `deck.gl` (HexagonLayer/ColumnLayer) kết hợp `maplibre-gl` để render các cột 3D.

## Open Questions
> [!QUESTION]
> Bạn có muốn tôi thiết lập dashboard này như một project **Vite** (cần chạy `npm run dev`) hay chỉ là các file `index.html`, `style.css`, `script.js` tĩnh để bạn có thể mở trực tiếp hoặc tích hợp vào hệ thống hiện tại dễ dàng hơn? (Tôi đề xuất dùng file tĩnh HTML/CSS/JS cho đơn giản).

## Proposed Changes

### Component: Core Web Files

#### [NEW] `index.html`
Cấu trúc giao diện chính của Dashboard:
- Tích hợp CDN của Deck.gl và MapLibre.
- Container toàn màn hình cho Bản đồ 3D.
- Panel bên trái: Tiêu đề "WORLD 3D", Dropdown chọn khu vực, Thống kê tổng quan (Đơn hoàn tất, Khu vực, Dịch vụ...), Thanh trượt chiều cao cột, và Danh sách Dịch vụ (cùng checkbox/màu sắc tương ứng).
- Panel bên phải: Danh sách "TOP 20 KHÁCH HÀNG".
- Panel góc dưới phải: Khung "Phân tích mật độ AI" hiển thị insight.

#### [NEW] `style.css`
Hệ thống CSS tùy chỉnh mang phong cách "Premium Dark Mode & Glassmorphism":
- Sử dụng phông chữ hiện đại (Inter / Roboto).
- Các panel UI được làm mờ (backdrop-filter blur), viền mỏng trong suốt, đổ bóng neon tinh tế.
- Tùy chỉnh thanh cuộn (custom scrollbars) và hiệu ứng hover (micro-animations) để UI có cảm giác sống động.

#### [NEW] `script.js`
Logic điều khiển bản đồ và giao diện:
- **Tạo dữ liệu Mock:** Hàm tạo ngẫu nhiên ~2000 điểm dữ liệu (tọa độ Lat/Lng) quanh khu vực Đà Nẵng, gán nhãn dịch vụ (AIFOOD, ECO, BIKE...) và màu sắc tương ứng.
- **Deck.gl Configuration:** Khởi tạo `Deck` class với `Map` view. Cấu hình góc nhìn nghiêng (pitch) và góc xoay (bearing) để tạo hiệu ứng 3D.
- **Render Layer:** Cập nhật `ColumnLayer` hoặc `HexagonLayer` dựa trên dữ liệu. Chiều cao cột sẽ thay đổi theo số lượng đơn hàng và giá trị của thanh trượt (Slider).
- **Tương tác:** Lắng nghe sự kiện toggle các dịch vụ ở bảng bên trái để filter dữ liệu và re-render bản đồ theo thời gian thực.
- Cập nhật số liệu trên UI dựa trên bộ lọc hiện tại.

## Verification Plan

### Manual Verification
1. Mở file HTML trên trình duyệt (hoặc qua Live Server).
2. Kiểm tra giao diện tổng thể: Các panel có hiệu ứng kính (glassmorphism), màu sắc tối và text rõ nét.
3. Kiểm tra bản đồ 3D: Có thể kéo xoay (Ctrl + Drag), zoom, xem các cột dữ liệu theo khu vực Đà Nẵng.
4. Kiểm tra tương tác: Kéo thanh trượt để thay đổi độ cao cột, bật/tắt các loại dịch vụ ở panel trái để thấy bản đồ cập nhật ngay lập tức.
