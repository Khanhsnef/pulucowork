# WORLD 3D Dashboard — Walkthrough

Dashboard bản đồ mật độ đơn hàng 3D tương tác đã được xây dựng và **kiểm thử thành công 100%**.

## Giao diện Chính

![Giao diện WORLD 3D Dashboard khi khởi chạy](/Users/ts-1148/.gemini/antigravity-ide/brain/e35d4a90-d32b-4017-bbdf-20c4bc1dadc4/artifacts/initial_page_load.png)

## Demo Tương tác

Dưới đây là video ghi lại toàn bộ quá trình kiểm thử các tương tác trên trình duyệt (xoay bản đồ, lọc dịch vụ, kéo thanh trượt chiều cao cột):

![Video demo tương tác WORLD 3D Dashboard](/Users/ts-1148/.gemini/antigravity-ide/brain/e35d4a90-d32b-4017-bbdf-20c4bc1dadc4/artifacts/dashboard_v2_test.webp)

## Bộ lọc Dịch vụ (Service Toggle)

Khi tắt bộ lọc **DAD-AIFOOD** (628 đơn), bản đồ tự động xóa các cột Cyan và cập nhật lại số liệu tổng quan:

![Dashboard sau khi tắt bộ lọc DAD-AIFOOD](/Users/ts-1148/.gemini/antigravity-ide/brain/e35d4a90-d32b-4017-bbdf-20c4bc1dadc4/artifacts/toggled_aifood_off.png)

---

## Cấu trúc Dự án

| File | Vai trò |
| :--- | :--- |
| [index.html](file:///Users/ts-1148/Desktop/Pulu-workspace/world-3d-dashboard/index.html) | Cấu trúc layout, nhúng CDN Deck.gl + MapLibre |
| [style.css](file:///Users/ts-1148/Desktop/Pulu-workspace/world-3d-dashboard/style.css) | Dark Mode Glassmorphism, hiệu ứng neon |
| [script.js](file:///Users/ts-1148/Desktop/Pulu-workspace/world-3d-dashboard/script.js) | Mock data, khởi tạo ColumnLayer, tương tác UI |

## Kết quả Kiểm thử

| Tính năng | Kết quả | Chi tiết |
| :--- | :--- | :--- |
| Hiển thị bản đồ 3D | ✅ Pass | Cột màu đa sắc render mượt trên nền Carto Dark Matter |
| Panel Glassmorphism | ✅ Pass | 3 panel (trái, phải, AI) hiển thị đúng hiệu ứng kính |
| Toggle dịch vụ | ✅ Pass | Bấm tên dịch vụ → cột ẩn/hiện + số liệu cập nhật real-time |
| Thanh trượt chiều cao | ✅ Pass | Kéo slider → cột cao/thấp tức thì (đã test 74x → 251x) |
| Tự động xoay | ✅ Pass | Bấm ▶/⏸ → bản đồ xoay/dừng mượt ở ~60fps |
| Console Errors | ✅ 0 lỗi | Chỉ có 404 `favicon.ico` (không ảnh hưởng) |

## Hướng dẫn Chạy

```bash
cd ~/Desktop/Pulu-workspace/world-3d-dashboard
python3 -m http.server 8000
# Mở http://localhost:8000
```

> [!TIP]
> Để kết nối dữ liệu thật, thay hàm `rawData` trong [script.js](file:///Users/ts-1148/Desktop/Pulu-workspace/world-3d-dashboard/script.js) bằng `fetch()` gọi API nội bộ.
