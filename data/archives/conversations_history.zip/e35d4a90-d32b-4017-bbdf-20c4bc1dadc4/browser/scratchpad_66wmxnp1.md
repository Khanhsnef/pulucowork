# World 3D Dashboard Testing Scratchpad

## Progress Tracker
- [x] Initial Page Load and Wait (8 seconds)
- [x] Verify Map and 3D Columns
- [x] Verify Panel Components
- [x] Check Console Logs for Errors
- [x] Interact with Service Items (Toggle)
- [x] Interact with Height Slider
- [x] Interact with "Đang quay" Button

- [x] Final Summary Documented

## Findings and Observations
1. **Initial Page Load:** The dark theme MapLibre map renders successfully with multicolored 3D GridLayer columns. The glass panels (Left info/toggles, Right customer rankings, Bottom-right AI description) display correctly.
2. **Console Verification:** Only one harmless `favicon.ico` 404 error was found; all key scripts loaded correctly.
3. **Rotation Interaction:** The "Dừng quay" (Pause rotation) button successfully stops the auto-rotation on click, changing the label to "Đang quay" (Play rotation).
4. **Service Item Toggle:** Clicking "DAD-AIFOOD" toggles the service filter off. This:
   - Updates completed orders count (from 1,914 to 1,286).
   - Updates total regions count (from 609 to 514).
   - Correctly hides all cyan columns representing AhaFood orders.
5. **Height Slider:** Dragging/clicking the slider successfully adjusts the height multiplier in real-time (tested at 74x and 251x), rendering columns at the correct heights.

