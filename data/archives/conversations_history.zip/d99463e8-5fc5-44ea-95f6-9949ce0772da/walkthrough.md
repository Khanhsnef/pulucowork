# Hoàn tất chuẩn bị cấu hình Streamlit Cloud

Tôi đã hoàn tất việc thiết lập môi trường cục bộ cho bạn. Dưới đây là những gì đã được thực hiện và các bước tiếp theo để đưa Dashboard của bạn lên sóng (Live) 24/7.

## Những thay đổi đã thực hiện

1. **Kiểm tra Bảo mật (`.gitignore`)**: File cấu hình môi trường `.env` đã được đưa vào danh sách bỏ qua (ignore), đảm bảo bạn không vô tình đẩy các thông tin bảo mật lên GitHub.
2. **Khai báo Thư viện (`requirements.txt`)**: Đã tạo thành công file cấu hình [requirements.txt](file:///Users/ts-1148/Desktop/Pulu-workspace/requirements.txt) ở thư mục gốc chứa các thư viện: `pandas`, `requests`, `streamlit`, `plotly`. Streamlit Cloud sẽ đọc file này để tự động cài đặt môi trường.

---

## BƯỚC TIẾP THEO: Hướng dẫn Deploy lên Streamlit Cloud

Để Dashboard chạy trực tuyến 24/7, bạn cần thực hiện 2 công đoạn chính: Push code lên GitHub và Kết nối với Streamlit Cloud.

### 1. Đẩy Code lên GitHub

Bạn cần commit những thay đổi mới nhất (đặc biệt là file `requirements.txt`) và push lên nhánh `main`:

Mở Terminal của dự án (hoặc công cụ quản lý Git bạn đang dùng) và chạy các lệnh sau:
```bash
git add requirements.txt
git commit -m "chore: add requirements.txt for streamlit cloud deployment"
git push origin main
```

> [!WARNING]
> Hãy chắc chắn rằng bạn đã push thành công code lên GitHub trước khi chuyển sang bước 2.

### 2. Thiết lập trên Streamlit Cloud

1. Truy cập vào **[Streamlit Community Cloud](https://share.streamlit.io/)** và đăng nhập bằng tài khoản GitHub của bạn.
2. Tại màn hình chính, nhấn nút **"New app"**.
3. Chọn tùy chọn: **"Deploy a public app from GitHub"**.
4. Điền các thông tin sau vào Form cấu hình:
   - **Repository:** Gõ tên repo của bạn (Ví dụ: `Khanhsnef/pulucowork` hoặc tên repo tương ứng chứa dự án Pulu-workspace).
   - **Branch:** `main` (hoặc tên nhánh mặc định của bạn).
   - **Main file path:** Đường dẫn chính xác đến file dashboard. Theo cấu trúc hiện tại, hãy điền:
     `output/Ahamove/04. OPS_METRICS/dashboards/sgn_overview_dashboard.py`
5. *(Tùy chọn)* Nhấp vào phần **"Advanced settings"** nếu bạn muốn đặt tên miền tùy chỉnh (Custom App URL), ví dụ: `sgn-overview.streamlit.app`.
6. Nhấn nút **"Deploy!"**.

### Quá trình Khởi tạo (Baking)

Hệ thống sẽ bắt đầu spin-up một server, cài đặt các thư viện từ `requirements.txt` (sẽ mất khoảng 1-2 phút). Sau khi hoàn tất, bạn sẽ thấy Dashboard xuất hiện trên trình duyệt và có thể chia sẻ đường link URL public đó cho bất kỳ ai!

> [!TIP]
> Dashboard của bạn hiện đang truy cập trực tiếp dữ liệu từ file Google Sheet đã được Public dưới dạng CSV, do đó **KHÔNG** cần phải thiết lập Secrets Management trên Streamlit Cloud. Nếu sau này bạn cần truy cập private sheet, bạn sẽ cần thiết lập Service Account Key trong phần Settings > Secrets của ứng dụng.
