# Mục tiêu: Tự động hóa Dữ liệu (Metabase API ➔ Google Sheet ➔ Streamlit)

Tuyệt vời! Nếu bạn có quyền gọi API để lấy dữ liệu trực tiếp từ các Card trên Metabase (dưới dạng JSON/CSV) và đẩy ra Google Spreadsheet, chúng ta sẽ xây dựng được một hệ thống báo cáo hoàn toàn tự động (Automated Data Pipeline) giải quyết trọn vẹn Phương án 3.

## Đề xuất Kiến trúc Hệ thống (System Architecture)

Luồng dữ liệu (Data Flow) sẽ hoạt động như sau:

1. **Bước 1 (Data Extraction):** Một kịch bản Python (Script) sẽ tự động gọi Metabase API (ví dụ: `/api/card/{card_id}/query/csv`) để lấy dữ liệu thô của từng biểu đồ trên cái Dashboard 2307 kia.
2. **Bước 2 (Data Transformation & Load):** Script này sẽ dùng thư viện `gspread` (hoặc Google Drive API) để tự động xóa dữ liệu cũ và ghi đè dữ liệu mới vào 1 file Google Sheet (File này cấu hình là Public view).
3. **Bước 3 (Data Visualization):** App Streamlit (mà bạn vừa deploy) sẽ đọc file Google Sheet này để vẽ biểu đồ Real-time mà không cần ai phải copy-paste số liệu bằng tay nữa.

## Open Questions (Cần bạn xác nhận trước khi code)

Để tôi có thể viết Script chính xác nhất, bạn vui lòng làm rõ các điểm sau:

> [!IMPORTANT]
> 1. **Tình trạng API hiện tại:** Bạn đã có sẵn một script Python/Tool chạy được việc kéo API này chưa, hay bạn chỉ mới có tài liệu (Document) và muốn tôi viết Script Python từ đầu để gọi Metabase API?
> 2. **Authentication (Xác thực):** Để gọi API của Metabase nội bộ Ahamove, bạn có API Key / Session Token không, hay bạn dùng tài khoản Username/Password để gọi API lấy Token (`/api/session`)?
> 3. **Format của Data:** API bạn đang nhắc đến sẽ xuất thẳng ra file Google Sheet cho bạn (công ty có build tool riêng), hay nó chỉ trả về file CSV và mình phải tự viết code đẩy lên Google Sheet?

## User Review Required

Bạn hãy phản hồi các câu hỏi trên. Nếu bạn đã có sẵn cái API Link mẫu hoặc cấu trúc Data trả về, cứ dán thẳng vào đây để tôi xem và viết code nhé!
