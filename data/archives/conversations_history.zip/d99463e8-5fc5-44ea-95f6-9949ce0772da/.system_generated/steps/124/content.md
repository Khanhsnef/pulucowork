Title: Live Content

Description: Fetched live

Source: https://bi.ahamove.com/dashboard/2307-dm-dash-daily-performance-tracker?city=HAN&tab=781-daily&type=Excluded+WH%26GHN#refresh=300

---

<!DOCTYPE html>
<html class="login-pf">

<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="robots" content="noindex, nofollow">

            <meta name="viewport" content="width=device-width,initial-scale=1"/>
    <title>Sign in to Production</title>
    <link rel="icon" href="/resources/hnmi6/login/ahamove/img/favicon.ico" />
            <link href="/resources/hnmi6/common/keycloak/web_modules/@patternfly/react-core/dist/styles/base.css" rel="stylesheet" />
            <link href="/resources/hnmi6/common/keycloak/web_modules/@patternfly/react-core/dist/styles/app.css" rel="stylesheet" />
            <link href="/resources/hnmi6/common/keycloak/node_modules/patternfly/dist/css/patternfly.min.css" rel="stylesheet" />
            <link href="/resources/hnmi6/common/keycloak/node_modules/patternfly/dist/css/patternfly-additions.min.css" rel="stylesheet" />
            <link href="/resources/hnmi6/common/keycloak/lib/pficon/pficon.css" rel="stylesheet" />
            <link href="/resources/hnmi6/login/ahamove/css/styles.css" rel="stylesheet" />
</head>

<body class="">
<div class="login-pf-page">
    <div id="kc-header" class="login-pf-page-header">
        <div id="kc-header-wrapper"
             class="">Production</div>
    </div>
    <div class="card-pf">
        <header class="login-pf-header">
                <h1 id="kc-page-title">        Sign in to your account

</h1>
      </header>
      <div id="kc-content">
        <div id="kc-content-wrapper">


    <div id="kc-form">
      <div id="kc-form-wrapper">
            <form id="kc-form-login" onsubmit="login.disabled = true; return true;" action="https://sso.ahamove.com/realms/Production/login-actions/authenticate?session_code=HN0UEBede3uJ9jW892PsOKS2w0pB8Fg7ks_8Xywa4Ig&amp;execution=f3bdfa84-ded2-4178-92e4-912f4e12c12b&amp;client_id=opstech-ahamove&amp;tab_id=T84e_WZmarc" method="post">
                    <div class="form-group">
                        <label for="username" class="pf-c-form__label pf-c-form__label-text">Username or email</label>

                        <input tabindex="1" id="username" class="pf-c-form-control" name="username" value=""  type="text" autofocus autocomplete="off"
                               aria-invalid=""
                        />


                    </div>

                <div class="form-group">
                    <label for="password" class="pf-c-form__label pf-c-form__label-text">Password</label>

                    <input tabindex="2" id="password" class="pf-c-form-control" name="password" type="password" autocomplete="off"
                           aria-invalid=""
                    />


                </div>

                <div class="form-group login-pf-settings">
                    <div id="kc-form-options">
                        </div>
                        <div class="">
                        </div>

                  </div>

                  <div id="kc-form-buttons" class="form-group">
                      <input type="hidden" id="id-hidden-input" name="credentialId" />
                      <input tabindex="4" class="pf-c-button pf-m-primary pf-m-block btn-lg" name="login" id="kc-login" type="submit" value="Sign In"/>
                  </div>
            </form>
        </div>

    </div>



            <div id="kc-social-providers" class="kc-social-section kc-social-gray">
                <hr/>
                <h4>Or sign in with</h4>

                <ul class="pf-c-login__main-footer-links kc-social-links ">
                        <a id="social-google" class="pf-c-button pf-m-control pf-m-block kc-social-item kc-social-gray "
                                type="button" href="/realms/Production/broker/google/login?client_id=opstech-ahamove&amp;tab_id=T84e_WZmarc&amp;session_code=HN0UEBede3uJ9jW892PsOKS2w0pB8Fg7ks_8Xywa4Ig">
                                <i class="kc-social-provider-logo kc-social-gray fa fa-google" aria-hidden="true"></i>
                                <span class="kc-social-provider-name kc-social-icon-text">Google</span>
                        </a>
                </ul>
            </div>


        </div>
      </div>

    </div>
  </div>
</body>
</html>


