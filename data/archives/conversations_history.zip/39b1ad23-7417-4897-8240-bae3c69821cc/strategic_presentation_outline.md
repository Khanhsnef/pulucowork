# HỆ THỐNG PHÂN TẦNG & XẾP HẠNG TÀI XẾ AHAMOVE 2026 (DETAILS BY SECTION)

---

## 🎯 PHẦN 1: TIÊU CHÍ XẾP HẠNG TÀI XẾ CHÍNH THỨC

### 1. Bản chất thay đổi chiến lược
*   **Dịch chuyển tư duy:** Loại bỏ việc đánh giá rời rạc các chỉ số AR (Tỷ lệ chấp nhận), FR (Tỷ lệ hoàn thành), CR (Tỷ lệ hủy đơn) riêng lẻ. Thay vào đó, áp dụng **DQS (Driver Quality Score)** và **Năng suất (Productivity)** làm hai trụ cột xếp hạng chính thức.
*   **Tác động:** Đồng bộ chất lượng dịch vụ của đối tác, triệt tiêu tình trạng tài xế chất lượng kém "lọc đơn" để nhận thưởng ca mà vẫn bảo vệ trải nghiệm khách hàng.

### 2. Bảng tiêu chuẩn xếp hạng (Rolling 30 ngày)

| Chỉ số xếp hạng | 💎 R1 Elite (Kim Cương) | 🥇 R2 Active (Vàng) | 🥈 R3 Standard (Bạc) | 👤 Unranked (Chưa XH) |
| :--- | :--- | :--- | :--- | :--- |
| **Thang điểm DQS** | **≥ 80** | **≥ 75** | **≥ 75** | **< 75** |
| **Productivity (Đơn/Tháng)** | **≥ 280 đơn/tháng** | **≥ 210 đơn/tháng** | **≥ 70 đơn/tháng** | **—** |
| **Thâm niên hoạt động** | ≥ 1 tháng | ≥ 1 tháng | ≥ 1 tháng | < 1 tháng |
| **Layer ưu tiên** | **L2 Minizone** | **L3 Mediumzone** | **L4 Bigzone** | **L6 MASS** |

---

## 📐 PHẦN 2: KIẾN TRÚC HỆ THỐNG PHÂN TẦNG TÀI XẾ

### 1. Phân bổ cơ cấu Tiers (Quy mô fleet ~30.000 driver/tháng)
*   **💎 R1 Elite (Kim Cương):** Chiếm **~15% fleet** (~4.500 driver) ➔ Core cung ứng chủ lực, chuyên biệt Minizone cự ly ngắn (≤4km).
*   **🥇 R2 Active (Vàng):** Chiếm **~35% fleet** (~10.500 driver) ➔ Lực lượng cốt cán chạy Mediumzone (4 - 7km).
*   **🥈 R3 Standard (Bạc):** Chiếm **~35% fleet** (~10.500 driver) ➔ Phân phối chạy Bigzone cự ly trung bình - dài (7 - 11km).
*   **👤 Unranked (Chưa XH):** Chiếm **~15% fleet** (~4.500 driver) ➔ Tài xế mới hoạt động hoặc bị hạ rank do không đạt DQS/Productivity tối thiểu, chạy L6 Mass tự do.

### 2. Cơ chế Cascade Reveal (Đăng ký ca dự phòng)
Để hạn chế việc tài xế chất lượng cao không đăng ký được ca khi layer chính hết slot (slot fill rate đạt giới hạn), hệ thống tự động kích hoạt hiển thị layer fallback:

```mermaid
graph TD
    %% Styling Classes
    classDef rank fill:#FFF7ED,stroke:#FF7F32,stroke-width:2px,color:#C2410C;
    classDef layer fill:#EEF2FF,stroke:#0E4174,stroke-width:1.5px,color:#0E4174;
    classDef grayLayer fill:#F1F5F9,stroke:#94A3B8,stroke-width:1.5px,color:#475569;

    %% Nodes Declaration
    R1["💎 R1 Elite"]:::rank
    R2["🥇 R2 Active"]:::rank
    R3["🥈 R3 Standard"]:::rank
    UN["👤 Unranked"]:::rank

    L2["L2 Minizone"]:::layer
    L3["Kích hoạt thấy L3 Mediumzone"]:::layer
    L4["Kích hoạt thấy L4 Bigzone"]:::layer
    L5["Kích hoạt thấy L5 Cityzone"]:::layer
    L6["L6 MASS Buffer"]:::grayLayer

    %% Flow Connections
    R1 -->|Mặc định thấy| L2
    R2 -->|Mặc định thấy| L3
    R3 -->|Mặc định thấy| L4
    UN -->|Mặc định chỉ thấy| L6

    L2 -->|Slot lấp đầy ≥ 80%| L3
    L3 -->|Slot lấp đầy ≥ 80%| L4
    L4 -->|Slot lấp đầy ≥ 80%| L5
```

#### **Bảng quy tắc luồng Cascade đăng ký:**

| Hạng Tài Xế | Layer Mặc Định Nhìn Thấy | Điều Kiện Kích Hoạt Cascade | Layer Cascade Hiển Thị Thêm |
| :--- | :--- | :---: | :--- |
| **💎 R1 Elite (Kim Cương)** | L2 Minizone (≤4km) | Slot L2 lấp đầy **≥ 80%** | L3 Mediumzone (4 - 7km) |
| **🥇 R2 Active (Vàng)** | L3 Mediumzone (4 - 7km) | Slot L3 lấp đầy **≥ 80%** | L4 Bigzone (7 - 11km) |
| **🥈 R3 Standard (Bạc)** | L4 Bigzone (7 - 11km) | Slot L4 lấp đầy **≥ 80%** | L5 Cityzone (R3 fallback) |
| **👤 Unranked (Chưa XH)** | L6 MASS Buffer (Tự do) | ❌ Không kích hoạt | ❌ Chỉ hoạt động tại L6 MASS |

---

## 📅 PHẦN 3: QUYỀN TRUY CẬP LAYER & CA LÀM VIỆC

### 1. Khung giờ vàng mở đăng ký ca (FCFS - First Come First Served)
Cửa sổ đăng ký ca ca làm việc được phân khung chi tiết theo rank để đảm bảo quyền ưu tiên cho tài xế hiệu suất cao:
*   **💎 R1 Kim Cương:** Mở cổng từ **00:00 - 10:00** ngày 1 hàng tháng (Ưu tiên tuyệt đối).
*   **🥇 R2 Vàng:** Mở cổng từ **10:00 - 14:00** ngày 1 hàng tháng.
*   **🥈 R3 Bạc:** Mở cổng sau **14:00** ngày 1 hàng tháng.
*   **👤 Unranked:** Mở cổng tự do từ **Ngày 2 đến Ngày 5** hàng tháng.

### 2. Tỷ lệ phân bổ Slot ca và giới hạn ca Full-day

| Hạng tài xế | Ca Sáng <br><small>(08:00 - 12:00)</small> | Ca Chiều <br><small>(13:00 - 17:00)</small> | Ca Tối <br><small>(17:00 - 21:00)</small> | Ca Full-day ★ <br><small>(08:00 - 18:00)</small> |
| :--- | :---: | :---: | :---: | :---: |
| **💎 R1 Elite** | 20% slot | 20% slot | 15% slot | **50% slot (💰 Giới hạn 100-200 ca/ngày)** |
| **🥇 R2 Active** | 40% slot | 40% slot | 40% slot | **50% slot (💰 Giới hạn 100-200 ca/ngày)** |
| **🥈 R3 Standard** | 40% slot | 40% slot | 45% slot | ❌ Không áp dụng |
| **👤 Unranked** | On-demand | On-demand | On-demand | ❌ Không áp dụng |

*   **Chính sách ca Full-day (10 tiếng):** Giới hạn chỉ mở **100 - 200 slot/ngày** (chiếm 10 - 15% tổng lượng ca đăng ký) chia đều cho R1 và R2 nhằm tối ưu hóa cung ứng giờ cao điểm liên tục tại Mini-hub và kiểm soát chặt chẽ P&L ngân sách.

---

## 💰 PHẦN 4: QUYỀN LỢI TÀI XẾ — THU NHẬP & ĐẢM BẢO

### 1. Thu nhập mục tiêu EPH (Earnings Per Hour) theo từng Layer
Mức target tối đa hóa thu nhập thực tế trên giờ chạy (chưa bao gồm incentive thưởng tuần):
*   **L2 Minizone (≤4km):** Target **65.000đ/h (SGN) | 70.000đ/h (HAN)**.
*   **L3 Medium (4 - 7km):** Target **60.000đ/h (SGN) | 65.000đ/h (HAN)**.
*   **L4 Bigzone (7 - 11km):** Target **55.000đ/h (SGN) | 60.000đ/h (HAN)**.
*   **L5 Cityzone (R3 cascade):** Target **55.000đ/h (SGN) | 60.000đ/h (HAN)**.

### 2. Thu nhập Đảm bảo ngày (áp dụng cho ca Full-day 08:00 - 18:00)
*   **R1 Elite/Kim Cương:** Đảm bảo **600.000đ/ngày (SGN) | 650.000đ/ngày (HAN)**.
*   **R2 Active/Vàng:** Đảm bảo **550.000đ/ngày (SGN) | 600.000đ/ngày (HAN)**.

### 3. Quy tắc Đảm bảo thu nhập ca & Chế tài tuần
*   **Điều kiện đạt chuẩn ngày:**
    1.  Duy trì tỷ lệ online liên tục trong ca **≥ 90%**.
    2.  Tỷ lệ chấp nhận đơn hàng phát ra trong ca đạt **100%**.
    3.  Tỷ lệ hoàn thành ca đạt chuẩn rank, không tự ý out ca.
*   **Chế tài tuần:** Thu nhập đảm bảo được đối soát và tính theo tuần dựa trên số ngày đạt điều kiện. **Nếu vi phạm điều kiện quá 2 lần trong một tuần, tài xế sẽ mất toàn bộ quyền nhận tiền bù chênh lệch chênh lệch của cả tuần đó.**

---

## 💎 PHẦN 5: AHABENEFITS — POINTS ECONOMY

### 1. Công thức tích lũy điểm thưởng AhaBenefits
$$\text{Điểm tích luỹ Chuyến xe} = \left( \frac{\text{Doanh thu thực tế (GSV)}}{5.000} \right) \times \text{Hệ số nhân Layer} + \text{Điểm thưởng hoàn ca}$$

*   **Hệ số nhân Layer (áp dụng theo layer vận hành thực tế):**
    *   **L2 Minizone:** Nhân **x1.5** (+30 pts/ca hoàn tất)
    *   **L3 Mediumzone:** Nhân **x1.3** (+25 pts/ca hoàn tất)
    *   **L4 Bigzone:** Nhân **x1.1** (+20 pts/ca hoàn tất)
    *   **L5/L6:** Nhân **x1.0** (Không thưởng ca)

### 2. Ước tính điểm tích luỹ và Ngưỡng đổi thưởng tháng
*   **Ngưỡng đổi thưởng mốc 50k cash:** **1.500 points**.
*   **Ước tính tích luỹ hàng tháng (Mô hình chạy 22 ngày, 1 ca 4h/ngày):**
    *   **R1 Elite (chạy L2):** Tích luỹ **~2.508 points/tháng** (Vượt ngưỡng 50k cash ➔ dư 1.008 pts).
    *   **R2 Active (chạy L3):** Tích luỹ **~2.046 points/tháng** (Vượt ngưỡng 50k cash ➔ dư 546 pts).
    *   **R3 Standard (chạy L4):** Tích luỹ **~1.606 points/tháng** (Vừa đủ vượt ngưỡng 50k cash).
    *   **L6 MASS / Unranked:** Tích luỹ tối đa **~968 points/tháng** (Không bao giờ chạm ngưỡng đổi quà 50k trong tháng ➔ động lực thăng hạng lên R3).

### 3. Gói bảo hiểm tai nạn đặc quyền R1 (đổi bằng điểm)
*   **Gói bảo vệ 10k/tháng:** Đổi bằng **285 points**.
*   **Gói bảo vệ 30k/tháng:** Đổi bằng **857 points**.
*   *Quy định:* Đăng ký đổi điểm trên app trước ngày 25 hàng tháng; gói bảo hiểm có hiệu lực từ ngày 01 tháng kế tiếp.

---

## 📈 PHẦN 6: LỘ TRÌNH THĂNG HẠNG & TIMELINE HÀNG THÁNG

### 1. Lộ trình thăng hạng tiêu biểu của tài xế mới

```
[Unranked / Tài xế mới] 
   ➔ Chạy L6 MASS tự do, tích lũy thâm niên hoạt động
   ➔ Sau 1 tháng: DQS ≥75, Productivity ≥70 đơn ➔ Lên [🥈 R3 Bạc]
   ➔ Cải thiện kỹ năng ghép đơn: DQS ≥75, Productivity ≥210 đơn ➔ Lên [🥇 R2 Vàng]
   ➔ Chuyển đổi sang xe điện EV: DQS ≥80, Productivity ≥280 đơn ➔ Lên [💎 R1 Kim Cương]
```

### 2. Timeline vận hành hệ thống hàng tháng (Tháng T)

```
 Ngày 1 (00:00)         Ngày 1 (10:00)       Ngày 1 (14:00)       Ngày 2 - 5             Hết Ngày 5 (23:59)
   [ 💎 R1 ]              [ 🥇 R2 ]            [ 🥈 R3 ]            [ Unranked ]           [ Auto Assign ]
 Cổng R1 mở             Cổng R2 mở           Cổng R3 mở           Cổng mở tự do          Đóng cổng đăng ký
 Ưu tiên ca Minizone    Đăng ký ca Medium    Đăng ký ca Bigzone   Đăng ký slot còn lại   Gán tự động vào L6
```

*   **Chính sách xuống hạng:** Xét duyệt cập nhật rank tự động 1 lần/tháng vào đầu tháng dựa trên dữ liệu rolling 30 ngày. Nếu đối tác không duy trì đủ KPI tối thiểu trong tháng ➔ sẽ xuống hạng vào tháng tiếp theo và có thể thăng hạng lại ngay sau khi cải thiện các chỉ số.
