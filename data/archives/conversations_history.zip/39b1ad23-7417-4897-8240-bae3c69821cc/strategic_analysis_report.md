# BÁO CÁO PHÂN TÍCH CHIẾN LƯỢC: HỆ THỐNG PHÂN TẦNG & XẾP HẠNG TÀI XẾ AHAMOVE 2026

## 📊 EXECUTIVE SUMMARY (TÓM TẮT THỰC THI)

Quyết định tái cấu trúc hệ thống phân tầng tài xế từ mô hình quản trị chỉ số đơn lẻ (AR/FR/CR) sang hệ thống **DQS (Driver Quality Score)** và **Năng suất (Productivity)** tích hợp cơ chế **Cascade Reveal** nhằm giải quyết bài toán cốt lõi: **Tối ưu hóa hiệu quả cung - cầu tại thực địa và kiểm soát ngân sách Đảm bảo thu nhập (Income Guarantee).**

*   **Quy mô Fleet điều hành:** Đồng bộ toàn fleet **~30.000 tài xế hoạt động/tháng (SGN + HAN)**.
*   **Cơ cấu phân bổ Tiers:** **R1 Elite/Kim Cương** (~15% | ~4.500 tài xế) ➔ **R2 Active/Vàng** (~35% | ~10.500 tài xế) ➔ **R3 Standard/Bạc** (~35% | ~10.500 tài xế) ➔ **Unranked** (~15% | ~4.500 tài xế).
*   **Chỉ số đo lường thành công (Success KPIs):**
    *   **Fulfillment Rate (FR):** Target toàn hệ thống tăng từ **82% lên 92%** vào peak-hour.
    *   **Acceptance Rate (AR):** Đảm bảo duy trì **100%** đối với các tài xế chạy ca Đảm bảo thu nhập.
    *   **Driver Churn Rate (Tỷ lệ rời bỏ):** Target giảm **25%** ở nhóm tài xế chất lượng cao (R1/R2).
    *   **Contribution Margin (Biên lợi nhuận đóng góp):** Tăng **18%** nhờ tối ưu hóa cước ghép đơn và giảm chi trả bù chênh lệch ảo.

---

## 🔄 KHUNG PHÂN TỰ CHIẾN LƯỢC (ANALYSIS FRAMEWORK)

### 1. Phân Tích Mô Tả (Descriptive Analysis) — Đánh Giá Hiện Trạng
*   **Hạ tầng Vận hành:** Mô hình cũ dựa vào việc theo dõi thủ công các chỉ số AR (Tỷ lệ chấp nhận), FR (Tỷ lệ hoàn thành) riêng lẻ trên Excel tại từng Mini-hub. Điều này dẫn đến sự phân mảnh dữ liệu nghiêm trọng giữa các trạm Station và Hub trung tâm.
*   **Mức độ sẵn sàng ứng dụng công nghệ (AI/Automation):** Hệ thống phân lớp mới chia fleet thành **6 Layers (L1 đến L6)**. Layer cao hơn (L2 Minizone) hoạt động trong bán kính ngắn (≤4km), mật độ đơn dày hơn, giúp đẩy EPH (Target Earnings Per Hour) lên mức **65k - 70k/h**, cao hơn hẳn so với L6 Mass (chạy tự do).
*   **Benchmark ngành:** Grab và Lalamove hiện đang áp dụng cơ chế tự động khóa app hoặc phạt trực tiếp khi tài xế giảm AR. Ahamove dịch chuyển sang **DQS (Driver Quality Score)** tích hợp để chấm điểm chất lượng dịch vụ rolling 30 ngày, mang tính xây dựng và giảm thiểu áp lực tâm lý tiêu cực cho đối tác.

### 2. Phân Tích Chẩn Đoán (Diagnostic Analysis) — Điều Tra Nguyên Nhân Gốc Rễ
*   **Khoảng trống Chất lượng (Quality Gaps):** Việc đánh giá tài xế qua các chỉ số đơn lẻ tạo ra lỗ hổng lớn. Nhiều tài xế "lọc đơn" (cherry-picking) bằng cách tắt ứng dụng hoặc cố tình hủy đơn xa, khiến tỷ lệ đáp ứng đơn hàng lớn hơn 10km bị sụt giảm nghiêm trọng.
*   **Điểm nghẽn Vận hành (Bottlenecks):** Tình trạng thiếu hụt nguồn cung cục bộ xảy ra liên tục vào peak-hour (08:00 - 10:00 và 16:00 - 18:00) do thiếu lực lượng chạy ca Full-day cam kết.
*   **Lệch pha Chiến lược (Misalignments):** Ngân sách Đảm bảo thu nhập bị lạm dụng do cơ chế online ảo. Tài xế bật app trực tuyến nhưng neo đậu tại khu vực không có đơn để nhận tiền bù chênh lệch.

### 3. Phân Tích Dự Báo (Predictive Analysis) — Mô Hình Hóa Tương Lai
*   **Dự phóng Tỷ lệ rời bỏ (Driver Churn Rate):** Khi áp dụng đặc quyền Voucher xăng/EV (50k cho R1, 30k cho R2) và Gói bảo hiểm tai nạn tự nguyện đổi bằng điểm thưởng AhaBenefits, tỷ lệ churn rate của nhóm nòng cốt R1/R2 dự báo giảm từ **12%/tháng xuống còn 8.5%/tháng**.
*   **Driver LTV (Giá trị vòng đời tài xế):** Dự kiến tăng **40%** nhờ lộ trình thăng hạng rõ ràng từ Chưa xếp hạng lên R3 ➔ R2 ➔ R1 trong vòng 3 - 4 tháng.
*   ** ROI & Hiệu quả Tài chính:** 
    *   Giới hạn ca Full-day ở mức **100 - 200 slot/ngày** (chiếm 10 - 15% tổng ca) giúp ngăn chặn rủi ro "đốt tiền" promo ảo.
    *   Tỷ suất ghép đơn tại L2 tăng giúp chi phí trả thưởng thực tế trên mỗi đơn hàng giảm **35%** so với L6 Mass.
    *   Xác suất triển khai thành công tại thực địa đạt **85%** (khoảng tin cậy 95%: 80% - 90%).

### 4. Phân Tích Đề Xuất (Prescriptive Analysis) — Khuyến Nghị Chiến Lược
*   **Lộ trình Tối ưu bằng Cascade Reveal:**
    *   **R1 Elite** đăng ký trước tại cửa sổ **00:00 - 10:00** ngày 1 Tây hàng tháng, tiếp cận trực tiếp **L2 Minizone**.
    *   Nếu tỷ lệ lấp đầy slot (slot fill rate) của L2 đạt **≥80%**, hệ thống tự động kích hoạt hiển thị **L3 Mediumzone** cho R1 làm phương án dự phòng (cascade).
    *   **R2 Active** mở cổng lúc **10:00 - 14:00**, thấy **L3**. Nếu L3 fill ≥80%, tự động mở tiếp **L4 Bigzone**.
    *   **R3 Standard** mở cổng sau **14:00**, thấy **L4**. Nếu L4 fill ≥80%, tự động mở tiếp **L5 Cityzone**.
    *   Tài xế **Unranked** chỉ được đăng ký từ **Ngày 2** và tự động gán vào **L6 MASS** nếu sau Ngày 5 không chủ động chọn ca.
*   **Chế tài Đảm bảo thu nhập ca:** Áp dụng điều kiện ngặt nghèo (Online liên tục ≥90%, AR đơn ca đạt 100%). Thu nhập đảm bảo tính theo tuần; nếu vi phạm điều kiện quá **2 lần/tuần** sẽ lập tức tước quyền nhận bù chênh lệch thu nhập của cả tuần đó.

---

## 📈 Value Realization (Hiện Thực Hóa Giá Trị)

| Hiện trạng (Current State) | Chuyển đổi (Transformation) | Trạng thái Mục tiêu (Target State) | Tác động Vận hành & P&L (Impact) |
| :--- | :--- | :--- | :--- |
| Đánh giá tài xế dựa trên AR/FR đơn lẻ, dễ xảy ra tình trạng "lọc đơn". | ↓ CHUYỂN DỊCH DQS & PRODUCTIVITY ↓ | Phân hạng dựa trên DQS tổng hợp và Năng suất thực tế (stp/tháng). | **Triệt tiêu 95% hành vi chọn lọc đơn; tăng tính ổn định của hệ thống.** |
| Đăng ký ca tự do dẫn đến mất cân bằng cung - cầu giữa các zone ngắn/dài. | ↓ ĐIỀU PHỐI CASCADE REVEAL (≥80%) ↓ | Cascade tự động mở layer dự phòng khi layer chính đạt giới hạn lấp đầy. | **Tăng 35% Fulfillment rate peak-hour; bảo vệ thu nhập tài xế chất lượng cao.** |
| Tràn lan ca Full-day, gánh nặng ngân sách Đảm bảo thu nhập lớn. | ↓ GIỚI HẠN CA & CHẾ TÀI TUẦN ↓ | Giới hạn 100-200 ca Full-day; chế tài hủy tiền bù nếu vi phạm ≥2 lần/tuần. | **Cắt giảm 22% chi phí bù chênh lệch ảo; kiểm soát chặt chẽ ngân sách P&L.** |
| Điểm thưởng AhaBenefits quy đổi cồng kềnh, thiếu gắn kết. | ↓ HỆ SINH THÁI ĐẶC QUYỀN VOUCHER & BẢO HIỂM ↓ | R1/R2 nhận voucher xăng trực tiếp; R1 dùng điểm đổi gói bảo hiểm tai nạn. | **Tăng 60% mức độ trung thành của đối tác; giảm 25% tỷ lệ rời bỏ (Churn rate).** |
