# 🛠️ Hướng Dẫn Chuyên Sâu: Thiết Lập & Tối Ưu Hóa Stable Diffusion & Flux.1 Local

## 1. Tóm Tắt Thực Thi (Executive Summary)

*   📊 **Executive Summary:** Việc tự vận hành Stable Diffusion chạy cục bộ (Local Hardware) – trọng tâm là mô hình thế hệ mới **Flux.1 (Dev/Schnell)** và **SDXL** – đại diện cho giải pháp tối ưu hóa chi phí và bảo mật tuyệt đối trong chuỗi cung ứng nội dung số. Bằng cách dịch chuyển từ API Cloud trả phí sang hạ tầng GPU nội bộ, doanh nghiệp làm chủ hoàn toàn dữ liệu hình ảnh, loại bỏ các giới hạn an toàn thông tin của bên thứ ba, và giảm chi phí sản xuất hình ảnh thô về mức $0.
*   🎯 **Mục tiêu Kinh doanh (Business Objectives):**
    *   **Làm chủ hạ tầng AIGC:** Tạo ra quy trình khép kín từ khâu sinh ảnh thô, huấn luyện mô hình nhận diện thương hiệu (LoRA đồng phục tài xế, xe Ahamove) đến khâu retouch.
    *   **Bảo mật dữ liệu tuyệt đối:** Đảm bảo toàn bộ tài sản sáng tạo, ý tưởng chiến dịch, thông tin nội bộ không bị chia sẻ ra ngoài mạng internet.
    *   **Tự do sáng tạo:** Loại bỏ hoàn toàn bộ lọc từ khóa (censorship) của các dịch vụ Cloud lớn để phục vụ các bối cảnh thực tế.
*   📈 **Chỉ số Cốt lõi (Important KPIs):**
    *   **VRAM Consumption (Mức tiêu thụ VRAM):** Giới hạn < 8GB (cấu hình thấp) và < 12GB (cấu hình trung bình) nhờ kỹ thuật lượng tử hóa (Quantization).
    *   **Time-per-Generation (Tốc độ sinh ảnh):** Đạt < 20 giây/ảnh với mô hình Flux Schnell (4 steps) và < 50 giây/ảnh với Flux Dev (20 steps).
    *   **Model Downsizing Rate (Tỷ lệ nén mô hình):** Giảm dung lượng file mô hình từ 23GB (FP16) xuống còn 5GB - 9GB (GGUF Q4/NF4) giúp tiết kiệm bộ nhớ và tăng tốc load.
    *   **Accuracy / Detail Quality (Độ chính xác chi tiết):** Đạt tiêu chuẩn hiển thị thương mại (SLA thiết kế) về tỷ lệ cơ thể người và chữ viết trong hình.

---

## 2. KHUNG PHÂN TÍCH (ANALYSIS FRAMEWORK)

### Phân tích Mô tả (Descriptive Analysis - Đánh giá Hiện trạng)
*   **Hạ tầng Vận hành hiện tại:** Hầu hết máy tính của bộ phận thiết kế đồ họa đều được trang bị card đồ họa Nvidia chuyên dụng (phổ biến từ dòng RTX 3060, RTX 4060 Ti trở lên) hoặc máy Mac Apple Silicon (M-series với Unified Memory lớn). Đây là tài nguyên phần cứng cực kỳ lý tưởng để chạy AI cục bộ mà chưa được khai thác triệt để.
*   **Các mô hình chạy Local tốt nhất:**
    *   **Flux.1-Dev (Black Forest Labs):** Mô hình open-source mạnh nhất hiện tại, vượt trội hơn cả Midjourney v6 về khả năng hiểu cấu trúc prompt phức tạp và chèn chữ (Text Rendering).
    *   **Flux.1-Schnell:** Phiên bản rút gọn tốc độ cao, chỉ cần 4 bước tạo ảnh, rất thích hợp cho máy cấu hình yếu hoặc cần sinh ảnh hàng loạt.
    *   **SDXL 1.0 (Stable Diffusion XL):** Vẫn là lựa chọn số 1 nếu cần sử dụng kho tài nguyên LoRA khổng lồ của cộng đồng trên Civitai (thay đổi khuôn mặt, phong cách nghệ thuật, bối cảnh Việt Nam).

### Phân tích Chẩn đoán (Diagnostic Analysis - Nguyên nhân Gốc rễ)
*   **Khoảng trống Chất lượng (Quality Gaps):** Mô hình Flux.1 nguyên bản (FP16/FP8) yêu cầu phần cứng cực kỳ khắt khe (chạy mượt cần GPU có từ 16GB đến 24GB VRAM). Nếu chạy trực tiếp trên các card đồ họa 8GB/12GB thông thường sẽ gây ra lỗi tràn bộ nhớ **Out of Memory (OOM)** hoặc chuyển sang chạy bằng RAM hệ thống khiến tốc độ tạo ảnh cực kỳ chậm (mất 10-15 phút/ảnh).
*   **Giải pháp Kỹ thuật:** Áp dụng kỹ thuật lượng tử hóa bộ nhớ:
    *   **GGUF (định dạng nén biến):** Cho phép chia nhỏ mô hình và chạy từng phần trên VRAM và RAM hệ thống một cách tối ưu.
    *   **NF4 (Normal Float 4):** Định dạng tối ưu hóa riêng cho GPU Nvidia, giúp chạy mô hình Flux.1-Dev chỉ với 8GB-12GB VRAM mà chất lượng ảnh gần như giữ nguyên so với bản gốc 23GB.

### Phân tích Dự báo (Predictive Analysis - Mô hình hóa Tương lai)
*   **Dự phóng Hiệu suất theo Cấu hình Phần cứng:**
    *   *Macbook M2/M3 Pro/Max (18GB+ RAM):* Sử dụng ComfyUI với Flux.1-Dev GGUF Q8_0 mang lại tốc độ tạo ảnh từ 30s - 45s.
    *   *PC GPU RTX 3060 / 4060 Ti (12GB VRAM):* Sử dụng WebUI Forge với Flux NF4 v2 cho tốc độ tạo ảnh vượt trội từ 20s - 30s.
    *   *PC GPU RTX 3050 / 4060 Laptop (8GB VRAM):* Chạy mượt mà Flux.1-Schnell GGUF Q4_K_M trong vòng dưới 15 giây/ảnh.
*   **Xác suất Thực thi:** Thiết lập thành công hệ thống Fooocus/Forge trong 30 phút với hướng dẫn tự động hóa. Đội ngũ designer mất khoảng 1 tuần để làm quen hoàn toàn với quy trình tối ưu prompt của mô hình mới.

### Phân tích Đề xuất (Khuyến nghị Chiến lược - Prescriptive Analysis)

#### 🚀 Hướng Dẫn Thiết Lập Tối Ưu Theo Từng Công Cụ (UI)

##### Cách 1: Sử dụng WebUI Forge (Đơn giản nhất, tối ưu nhất cho GPU Nvidia)
*   *Phù hợp cho:* Người dùng PC có card Nvidia RTX 8GB - 12GB VRAM muốn cài đặt nhanh, giao diện dễ dùng gần giống Automatic1111 truyền thống.
*   *Các bước cài đặt:*
    1.  Tải và cài đặt [Git](https://git-scm.com/) và [Python 3.10.6](https://www.python.org/).
    2.  Mở Terminal/Command Prompt tại thư mục làm việc và clone mã nguồn Forge:
        ```bash
        git clone https://github.com/lllyasviel/stable-diffusion-webui-forge.git
        ```
    3.  Tải file mô hình Flux NF4 đã được đóng gói sẵn: **`flux1-dev-bnb-nf4-v2.safetensors`** (tải trên Hugging Face của tác giả `lllyasviel`).
    4.  Di chuyển file mô hình vừa tải vào thư mục:
        `\stable-diffusion-webui-forge\models\Stable-diffusion\`
    5.  Chạy file `webui-user.bat` (trên Windows) hoặc `./webui.sh` (trên Mac/Linux) để khởi động giao diện trên trình duyệt (`http://127.0.0.1:7860`).
    6.  Chọn mô hình Flux NF4 ở góc trên cùng bên trái, chọn Sampler là `Euler` + Scheduler là `Simple` (hoặc `Normal`), đặt số Steps từ `20 - 25`, CFG Scale là `1.0` (Flux hoạt động tốt nhất ở mức CFG 1.0 - 3.5) và bắt đầu tạo ảnh.

##### Cách 2: Sử dụng ComfyUI với định dạng GGUF (Chuyên nghiệp nhất, tùy biến sâu nhất)
*   *Phù hợp cho:* Người dùng Macbook Apple Silicon hoặc PC cần xây dựng các Workflow phức tạp như Face-swap, ControlNet, Image-to-Image nâng cao.
*   *Các bước cài đặt:*
    1.  Cài đặt [ComfyUI](https://github.com/comfyanonymous/ComfyUI) và cài đặt thêm **ComfyUI Manager**.
    2.  Mở ComfyUI Manager -> Chọn **Install Custom Nodes** -> Tìm kiếm từ khóa `ComfyUI-GGUF` (của tác giả `city96`) và nhấn Install -> Restart ComfyUI.
    3.  Tải các file thành phần lượng tử hóa của Flux.1 từ Hugging Face:
        *   **Model UNet:** Tải file `flux1-dev-Q4_K_M.gguf` (hoặc `Q8_0.gguf` nếu có VRAM > 12GB) -> Bỏ vào thư mục `ComfyUI/models/unet/`.
        *   **Text Encoder:** Tải file `t5xxl_q4_k_m.gguf` -> Bỏ vào thư mục `ComfyUI/models/clip/`.
        *   **VAE:** Tải file `flux_vae.safetensors` -> Bỏ vào thư mục `ComfyUI/models/vae/`.
    4.  Tải workflow mẫu cho Flux.1 GGUF (định dạng ảnh `.png` hoặc file `.json` chứa sơ đồ node) từ Civitai hoặc các cộng đồng Reddit. Kéo thả file này vào giao diện ComfyUI để tự động thiết lập sơ đồ node.

---

## 3. 📈 HIỆN THỰC HÓA GIÁ TRỊ (VALUE REALIZATION)

**Đo lường Sự chuyển đổi khi tối ưu hóa Stable Diffusion/Flux chạy Local:**

| Chỉ số Vận hành (Metrics) | Hiện trạng (Cloud API / Midjourney) | Chuyển đổi (Tối ưu Local Flux.1 NF4/GGUF) | Tác động Đột phá (Impact) |
| :--- | :--- | :--- | :--- |
| **Chi phí tạo ảnh (Cost per Image)** | Phát sinh phí từ $0.05 - $0.20/ảnh trên các nền tảng trả phí. | ↓ **TỰ VẬN HÀNH PHẦN CỨNG CỤ CỤC BỘ** ↓ | ***Giảm 100% chi phí vận hành thiết kế thô (CPI = $0)*** |
| **Bảo mật dữ liệu (Data Privacy)** | Ý tưởng sản phẩm mới và hình ảnh nhân sự nội bộ phải tải lên máy chủ Cloud bên thứ ba. | ↓ **XỬ LÝ OFFLINE TRÊN GPU NỘI BỘ** ↓ | ***Triệt tiêu 100% rủi ro rò rỉ thông tin sáng tạo chiến dịch*** |
| **Khả năng chèn chữ (Text Rendering)** | Các mô hình SDXL cũ hoặc SD 1.5 thường vẽ chữ bị lỗi font, sai chính tả nghiêm trọng. | ↓ **TÍCH HỢP T5-XXL TEXT ENCODER CỦA FLUX** ↓ | ***Độ chính xác viết chữ đạt > 90%, giảm 80% thời gian retouch chữ*** |
| **Tùy biến thương hiệu (Brand Personalization)** | Không thể huấn luyện mô hình nhận diện riêng của doanh nghiệp trên các Cloud đóng. | ↓ **TRAIN LORA TRÊN NỀN TẢNG LOCAL** ↓ | ***Tạo ảnh tài xế mặc đúng đồng phục, logo thương hiệu chuẩn xác*** |
