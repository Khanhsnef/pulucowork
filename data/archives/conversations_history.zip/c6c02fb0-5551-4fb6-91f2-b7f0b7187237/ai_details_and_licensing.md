# ℹ️ Thông Tin Nguồn Gốc, Bản Quyền & Chi Phí Vận Hành Của Local AI

## 1. Tóm Tắt Thực Thi (Executive Summary)

*   📊 **Executive Summary:** Giải pháp Local AI được xây dựng trên hai nền tảng mã nguồn mở lớn nhất thế giới hiện nay là **Stable Diffusion** và mô hình thế hệ mới **Flux.1**. Cả hai mô hình này cùng với giao diện điều khiển **WebUI Forge** đều **hoàn toàn miễn phí 100%** để tải xuống, cài đặt và chạy cục bộ trên máy tính cá nhân của bạn. Không có phí đăng ký, không giới hạn lượt tạo, và không thu phí trên mỗi bức ảnh. Chi phí duy nhất là chi phí khấu hao phần cứng máy tính và tiền điện tiêu thụ khi card đồ họa RTX 3060 Ti hoạt động hết công suất.
*   🎯 **Mục tiêu Kinh doanh (Business Objectives):**
    *   Hiểu rõ nguồn gốc công nghệ để đảm bảo tính pháp lý khi sử dụng hình ảnh thương mại cho các hoạt động của Ahamove.
    *   Định lượng chính xác cơ cấu chi phí vận hành (Unit Economics) giữa mô hình Cloud AI trả phí định kỳ và Local AI tự vận hành.
*   📈 **Chỉ số Cốt lõi (Important KPIs):**
    *   **Direct Software Cost (Chi phí phần mềm trực tiếp):** $0 (Miễn phí hoàn toàn).
    *   **Commercial License Availability (Giấy phép thương mại):** Có sẵn tùy theo phiên bản mô hình được chọn.
    *   **Power Consumption Cost (Chi phí điện năng):** Ước tính khoảng ~500đ - 1.000đ cho mỗi 100 ảnh được tạo ra (Dựa trên công suất tiêu thụ của RTX 3060 Ti ~200W).

---

## 2. KHUNG PHÂN TÍCH (ANALYSIS FRAMEWORK)

### Phân tích Mô tả (Descriptive Analysis - Nguồn gốc & Nhà phát triển)

#### 1. Stable Diffusion là gì? Ai tạo ra?
*   **Định nghĩa:** Là mô hình AI tạo ảnh từ văn bản (Text-to-Image) bằng phương pháp khuếch tán (diffusion) mã nguồn mở nổi tiếng nhất thế giới.
*   **Nhà phát triển:** Được phát triển bởi công ty **Stability AI** (trụ sở tại London, Anh) hợp tác cùng các nhóm nghiên cứu tại Đại học LMU Munich (Đức) và cộng đồng Runway.
*   **Chi phí:** Hoàn toàn miễn phí khi chạy offline trên máy cá nhân.

#### 2. Flux.1 là gì? Ai tạo ra?
*   **Định nghĩa:** Là mô hình tạo ảnh thế hệ mới nhất (phát hành giữa năm 2024), sử dụng kiến trúc lai tiên tiến (Rectified Flow Transformers) mang lại chất lượng ảnh và khả năng viết chữ vượt trội hơn cả Midjourney v6.
*   **Nhà phát triển:** Được phát triển bởi **Black Forest Labs** (trụ sở tại Đức). Đây là startup được thành lập bởi chính **nhóm kỹ sư cốt lõi và các nhà sáng lập ban đầu đã tạo ra Stable Diffusion** sau khi họ rời Stability AI.
*   **Chi phí:** Bản **Flux.1-Schnell** và **Flux.1-Dev** được cung cấp dưới dạng mã nguồn mở (Open-weights) để cộng đồng tự tải về chạy miễn phí trên máy cá nhân.

#### 3. WebUI Forge là gì? Ai tạo ra?
*   **Định nghĩa:** Giao diện đồ họa chạy trên trình duyệt web giúp người dùng dễ dàng bấm nút, gõ prompt, chỉnh sửa ảnh (Inpaint/Outpaint) mà không cần lập trình.
*   **Nhà phát triển:** Được phát triển bởi **Illyasviel** (một lập trình viên huyền thoại trong cộng đồng Stable Diffusion, cũng là người tạo ra ControlNet). Forge là phiên bản cải tiến tối ưu hóa tốc độ và giảm VRAM từ giao diện gốc Automatic1111.
*   **Chi phí:** Miễn phí 100% mã nguồn mở trên GitHub.

---

### Phân tích Chẩn đoán (Diagnostic Analysis - Giấy phép & Bản quyền Thương mại)

Mặc dù việc sử dụng và chạy trên máy tính cá nhân là miễn phí, bạn cần lưu ý quy định thương mại sau để áp dụng vào các chiến dịch truyền thông Ahamove:

1.  **Stable Diffusion 1.5 / SDXL:**
    *   *Giấy phép:* CreativeML OpenRAIL-M.
    *   *Sử dụng thương mại:* **Được phép hoàn toàn**. Bạn có thể dùng ảnh tạo ra để chạy quảng cáo, in ấn, truyền thông mà không cần trả phí bản quyền cho Stability AI.
2.  **Flux.1-Schnell (Bản siêu nhanh):**
    *   *Giấy phép:* Apache 2.0.
    *   *Sử dụng thương mại:* **Được phép hoàn toàn và miễn phí**.
3.  **Flux.1-Dev (Bản chất lượng cao nhất - Cài đặt trong bộ kit):**
    *   *Giấy phép:* Giấy phép phi thương mại của Black Forest Labs (dành cho mục đích nghiên cứu, cá nhân).
    *   *Sử dụng thương mại:* Nếu Ahamove sử dụng ảnh từ Flux.1-Dev trực tiếp cho các chiến dịch quảng cáo lớn có phát sinh doanh thu trực tiếp, về mặt pháp lý cần liên hệ mua bản quyền thương mại từ Black Forest Labs.
    *   *Giải pháp thay thế miễn phí:* Nếu cần dùng thương mại hoàn toàn miễn phí chất lượng cao, bạn nên dùng mô hình **SDXL** hoặc **Flux.1-Schnell** được tích hợp sẵn trong bộ cài.

---

## 3. 📈 HIỆN THỰC HÓA GIÁ TRỊ (VALUE REALIZATION)

**So sánh chi phí giữa các giải pháp AI tạo ảnh:**

| Tiêu chí so sánh | Cloud AI Trả Phí (Midjourney / ChatGPT Plus) | Local AI Tự Vận Hành (Forge + Flux.1/SDXL) | Giá trị của Local AI |
| :--- | :--- | :--- | :--- |
| **Phí phần mềm hàng tháng** | Tốn khoảng $10 - $30/tháng (~250.000đ - 750.000đ/tháng). | **0đ** (Tải về và sử dụng miễn phí vĩnh viễn). | ***Tiết kiệm trực tiếp lên đến 9 triệu đồng/năm mỗi tài khoản*** |
| **Phí trên mỗi ảnh tạo ra** | Giới hạn số lượng ảnh nhanh, hết lượt phải chờ hoặc mua thêm gói. | **0đ** (Tạo bao nhiêu ảnh tùy thích, không giới hạn số lượng). | ***Chi phí tiệm cận $0 cho các khâu thử nghiệm thiết kế thô*** |
| **Quyền sở hữu hình ảnh** | Phụ thuộc vào điều khoản của nhà cung cấp Cloud, đôi khi khó bảo hộ bản quyền. | Hình ảnh được tạo offline trên máy của bạn, thuộc quyền sở hữu độc quyền của bạn. | ***Đảm bảo an toàn pháp lý tuyệt đối cho các tài sản sáng tạo của Ahamove*** |
