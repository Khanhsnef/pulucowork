# Checklist
- [x] Confirm dashboard title 'AHAMOVE SMARTOPS SIMULATOR' is NOT displayed due to app error.
- [ ] Check if metrics cards display values (No, blocked by compilation error).
- [x] Capture a clear screenshot of the page (Captured `exception_page`).
- [x] Check for visible exceptions (Found Streamlit TypeError: MarkdownMixin.markdown() got an unexpected keyword argument 'unsafe_allow_name').
- [ ] Report Fulfillment Rate (FR), Demand (Orders), Active Capacity (Drivers), CPO contribution (Cannot retrieve due to exception).

## Exception Details
- File: `/Users/ts-1148/Desktop/Pulu-workspace/output/Ahamove/04. OPS_METRICS/dashboards/incentive_simulation_app.py`, line 17.
- Code block:
  ```python
  st.markdown("""
  <style>
  ...
  </style>
  """, unsafe_allow_name=True, unsafe_allow_html=True)
  ```
- Error: `TypeError: MarkdownMixin.markdown() got an unexpected keyword argument 'unsafe_allow_name'. Did you mean 'unsafe_allow_html'?`
