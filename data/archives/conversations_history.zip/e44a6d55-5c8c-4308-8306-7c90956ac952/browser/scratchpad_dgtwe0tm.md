# Checklist
- [x] Navigate/Reload http://localhost:8502/
- [x] Locate the Leaderboard and 'Số ngày các chỉ số đạt % FC SGN' section
- [x] Take a screenshot and save it as an artifact

