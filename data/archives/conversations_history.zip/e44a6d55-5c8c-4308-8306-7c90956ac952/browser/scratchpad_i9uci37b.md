# Checklist
- [x] Navigate to http://localhost:8502/ (or use open tab)
- [x] Wait for the dashboard to load completely (e.g., check for Streamlit loading spinner or check DOM)
- [x] Scroll down to the bottom right to inspect the Accuracy table (🎯 Số ngày các chỉ số đạt % FC SGN)
- [x] Take a screenshot and analyze for any errors
- [x] Report findings

# Findings
- The "Accuracy table" (titled "🎯 SỐ NGÀY CÁC CHỈ SỐ ĐẠT % FC SGN") located at the bottom right of the page is rendering as raw HTML text inside a preformatted code container (like `st.code` or `st.text`) instead of being rendered as an HTML table.
- Raw HTML tags like `<tr>`, `<td style='padding: 0.4rem; font-weight:700;'>Request</td>` are completely visible as text to the user.
