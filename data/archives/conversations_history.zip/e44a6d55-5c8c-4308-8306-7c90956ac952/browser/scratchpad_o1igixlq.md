# Task Checklist
- [x] Reload dashboard page (http://localhost:8502/)
- [x] Wait 3 seconds for load
- [x] Read DOM/capture screenshot of current view
- [x] Scroll down to Leaderboard cards and Accuracy table
- [x] Take final screenshot and save to artifacts
