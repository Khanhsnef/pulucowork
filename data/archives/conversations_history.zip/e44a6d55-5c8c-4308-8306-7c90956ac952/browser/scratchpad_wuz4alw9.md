# Checklist for SGN Ops Dashboard Verification
- [x] List all open pages to check if localhost:8502 is already open
- [x] Navigate to http://localhost:8502/ (or reuse page if open)
- [x] Wait for the page to load completely (check for errors/Streamlit loading indicators)
- [x] Verify columns 'LM (Whole)', 'LM (MTD)', 'MoM (Whole)', 'MoM (MTD)' exist in cockpit
- [x] Verify there is no TypeError on the page
- [x] Capture a screenshot of the cockpit table
- [x] Document findings and update the walkthrough
