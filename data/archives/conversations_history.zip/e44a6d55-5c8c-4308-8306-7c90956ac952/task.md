# SGN Dashboard v3.0 — Task Checklist

## Phase 1 — Quick Wins ✅
- [x] Đọc toàn bộ source data (190 rows × 96 cols)
- [x] Đọc toàn bộ code dashboard hiện tại (1473 lines)
- [x] Thêm constants mới (FR_ROWS, ACTIVE_TIME_ROWS, CHANNEL_ACT_REQ/DEM_ROWS)
- [x] Thêm KPI cards hàng 1: Actual Request, Actual Demand, FR%, Active, Utilization, Productivity
- [x] Thêm KPI cards hàng 2: Request MTD, Demand MTD, Productivity MTD, Active 4h% Retention
- [x] Thêm FR% series (R180) vào chart Request vs Demand (dual-axis)
- [x] FR% target slider trong sidebar

## Phase 2 — Sub-Metrics Drill-down ✅
- [x] Tab "Demand Analysis" với 4 sub-tabs
- [x] Tab "Channel Performance": bảng 6 channels (FC Req/Dem, Actual Req/Dem, FR%)
- [x] Tab "Channel Actual": chart Actual Request by channel stacked bar
- [x] Tab "Channel Mix": stacked % chart + FR% trend by channel
- [x] Tab "FR Heatmap": 6 channels × 15 ngày (PASS/UNDER/OVER colors)
- [x] Supply & Driver Analytics với 4 sub-tabs
- [x] Tab "Segment Efficiency": bảng 5 segments × 10 metrics
- [x] Active Time Window table (1h/2h/4h by segment)
- [x] Supply Utilization Rate trend + segment utilization table

## Phase 3 — Advanced Analytics ✅
- [x] Tab "Trend & Pattern Analysis" với 4 sub-tabs
- [x] 90-day rolling trend (Request/Demand/FR% dual-axis)
- [x] Weekday pattern chart (Mon-Sun bar + FR% bar)
- [x] Accuracy Counter table (Pass/Under/Over per metric)
- [x] Leaderboard Top 5 (Request + Demand, separate columns)

## DONE — Dashboard v3.0 (2218 lines) ✅
