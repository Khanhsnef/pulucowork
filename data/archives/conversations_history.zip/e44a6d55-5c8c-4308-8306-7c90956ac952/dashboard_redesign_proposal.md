# 🗺️ Đề Xuất Nâng Cấp Toàn Diện: SGN Ops Dashboard v3.0

## 📊 Mapping Source Data → Nhóm Chỉ Số

### Dữ liệu hiện có trong sheet (96 cột × ~190 dòng):
| Source Row | Label | Kiểu | Độ sâu |
|---|---|---|---|
| R05–R12 | FC Request (Total + 5 channels + WH) | Số lượng | Daily/MTD/LM |
| R13–R20 | FC Demand (Total + 5 channels + WH) | Số lượng | Daily/MTD/LM |
| R21–R27 | Actual Request (Total + 5 channels + WH) | Số lượng | Daily |
| R28–R34 | Actual Demand (Total + 5 channels + WH) | Số lượng | Daily |
| R35–R41 | % FC Request (Total + by channel) | % | Daily |
| R42–R48 | % FC Demand (Total + by channel) | % | Daily |
| R50–R57 | Active actual (Total + FT/PT/NLM/Return/NIM/NID) | Số tài xế | Daily/MTD/LM |
| R58–R65 | Capacity (Total + FT/PT/NLM/Return/NIM/NID/NIM) | Giờ | Daily/MTD/LM |
| R66–R73 | Online hours (Total + FT/PT/NLM/Return/NIM/NID) | Giờ | Daily/MTD/LM |
| R74–R81 | Productivity = Cap/Active (Total + by segment) | đơn/tài xế | Daily/MTD/LM |
| R82–R89 | Online/Driver (Total + by segment) | giờ/tài xế | Daily/MTD/LM |
| R90–R97 | Prod/Onlinehour (Total + by segment) | đơn/giờ | Daily/MTD/LM |
| R98–R177 | Active by segment × time-window (1h/2h/4h) | Số tài xế | Daily |
| R180–R186 | % Actual FR by channel | % | Daily |

---

## 🏗️ Kiến Trúc Dashboard 4 Lớp

```
Layer 1: EXECUTIVE SUMMARY (Health Snapshot)
    ↓
Layer 2: OPERATIONAL OVERVIEW (Demand + Supply)
    ↓
Layer 3: SUB-METRICS (Channel / Segment drill-down)
    ↓
Layer 4: DETAILS (Active time windows, trend lines, forecasting accuracy)
```

---

## Layer 1 — 🔴 Executive Summary (Snapshot / KPI Pulse)

**Vị trí:** Đầu trang, luôn hiển thị. Mục tiêu: chỉ cần nhìn 5 giây biết ngay hôm qua tốt/xấu.

### Metric Cards (hàng ngang, 6 card):
| Card | Chỉ số | Source | So sánh |
|---|---|---|---|
| 1 | **Actual Request** (Yest) | R21[col6] | vs FC R05[col6], vs LM same DOW |
| 2 | **Actual Demand** (Yest) | R28[col6] | vs FC R13[col6], vs LM same DOW |
| 3 | **Fulfillment Rate** (FR) | R180[col6] = R28/R21 | vs LM same DOW, target 75%+ |
| 4 | **Active Drivers** (Yest avg) | R166[col6] | vs Plan (scaled), vs LM |
| 5 | **Productivity** (Yest) | R74[col6] = Cap/Active | vs LM (R74[col2]) |
| 6 | **Online/Driver** (Yest) | R82[col6] | vs LM (R82[col2]) |

> [!IMPORTANT]
> **Chưa có trên dashboard hiện tại:** Card FR (Actual FR = R180 by channel breakdown) và Productivity/Online-Driver chưa được hiển thị dưới dạng KPI card nổi bật.

### Gauge / Mini Sparkline:
- Mỗi card có sparkline 7 ngày gần nhất
- Màu: 🟢 ≥95% plan, 🟡 85–95%, 🔴 <85%

---

## Layer 2 — 📊 Operational Overview (Demand & Supply)

### Nhóm 2A — Demand (Cầu)

#### 2A.1 Request vs Demand vs FR — Trend Chart (đã có)
- Daily Request (R21) vs FC Request (R05) — đã có
- Daily Demand (R28) vs FC Demand (R13) — đã có
- **[MỚI]** Daily Actual FR % (R180) trên trục Y phụ (secondary axis), line chart

#### 2A.2 FC Achievement Table — MTD Cockpit (đã có, cần bổ sung)
| Chỉ số | Today (FC) | Yesterday (Actual) | MTD | LM Whole | LM MTD | vs Plan | vs LM MTD |
|---|---|---|---|---|---|---|---|
| Request | R05 | R21 | sum(R21) | R21[col2] | calc | % | % |
| Demand | R13 | R28 | sum(R28) | R28[col2] | % | % | % |
| **[MỚI] FR%** | calc | R180 | avg(R180) | calc LM | calc | target diff | MoM |
| **[MỚI] GHN Actual** | R07 | R23 | sum(R23) | R23[col2] | % | % | % |
| **[MỚI] KA Actual** | R08 | R24 | sum(R24) | R24[col2] | % | % | % |
| **[MỚI] MP Actual** | R09 | R25 | sum(R25) | R25[col2] | % | % | % |
| **[MỚI] SME Actual** | R10 | R26 | sum(R26) | R26[col2] | % | % | % |
| **[MỚI] WH Actual** | R12 | R27 | sum(R27) | R27[col2] | % | % | % |

#### 2A.3 Channel Mix Chart — [MỚI]
- Stacked bar: GHN / KA / MP / SME / WH — % contribution mỗi ngày
- Cho thấy xu hướng channel nào đang tăng/giảm tỷ trọng

### Nhóm 2B — Supply (Cung)

#### 2B.1 Driver Active — Trend Chart (đã có một phần)
- Daily Active Drivers (R166) vs Plan
- **[MỚI]** Thêm Capacity (R58) trên trục phụ (tổng giờ khả dụng)
- **[MỚI]** Thêm Online Hours (R66) — giờ thực tế online

#### 2B.2 Supply Efficiency KPIs — [MỚI hoàn toàn]
| Chỉ số | Công thức | Source | Ý nghĩa |
|---|---|---|---|
| **Utilization Rate** | Online Hours / Capacity | R66/R58 | Tỷ lệ tận dụng năng lực khả dụng |
| **Productivity** | Capacity / Active | R74 | Đơn TB mỗi tài xế mỗi ngày |
| **Online/Driver** | Online Hours / Active | R82 | Giờ online TB mỗi tài xế |
| **Prod/Online Hour** | Productivity / Online/Driver | R90 | Hiệu suất mỗi giờ online |

---

## Layer 3 — 🔬 Sub-Metrics (Channel & Segment Drill-down)

### Tab 3A — Channel Performance — [MỚI hoàn toàn]

#### 3A.1 Bảng Channel vs FC Achievement
| Channel | FC Request | Actual Request | % FC | FC Demand | Actual Demand | FR% | MoM Request |
|---|---|---|---|---|---|---|---|
| **Total SGN** | R05 | R21 | R35 | R13 | R28 | R180 | calc |
| **GHN** | R07 | R23 | R37 | R15 | R30 | R182 | calc |
| **KA** | R08 | R24 | R38 | R16 | R31 | R183 | calc |
| **MP** | R09 | R25 | R39 | R17 | R32 | R184 | calc |
| **SME** | R10 | R26 | R40 | R18 | R33 | R185 | calc |
| **WH** | R12 | R27 | R41 | R20 | R34 | R186 | calc |

> **Data đã có đầy đủ trong sheet!** Chỉ cần xây UI.

#### 3A.2 Channel Trend Lines — [MỚI]
- Line chart so sánh 5 channels theo ngày (30 ngày gần nhất)
- Toggle: Request / Demand / FR%
- Highlight weekday vs weekend pattern

### Tab 3B — Driver Segment Performance — [MỚI hoàn toàn]

#### 3B.1 Bảng Segment vs Plan
| Segment | Active (Yest) | Active MTD avg | Plan | vs Plan | Capacity | Online Hrs | Productivity | Online/Driver |
|---|---|---|---|---|---|---|---|---|
| **FT** | R99 | avg(R99) | scaled | % | R59 | R67 | R75 | R83 |
| **PT** | R112 | avg(R112) | scaled | % | R60 | R68 | R76 | R84 |
| **NLM** | R125 | avg(R125) | scaled | % | R61 | R69 | R77 | R85 |
| **Return** | R138 | avg(R138) | scaled | % | R62 | R70 | R78 | R86 |
| **NIM** | R151 | avg(R151) | scaled | % | R63 | R71 | R79 | R87 |

> [!NOTE]
> Productivity per segment cho phép so sánh hiệu suất FT vs PT vs NLM — thường FT >200 đơn/ngày, PT ~50–80.

#### 3B.2 Segment Mix Trend — [MỚI]
- Stacked area chart: % mix của FT/PT/NLM/Return/NIM mỗi ngày
- Phát hiện cơ cấu tài xế đang dịch chuyển

---

## Layer 4 — 🔭 Details (Active Windows + Accuracy Analysis)

### Tab 4A — Active Time Window Analysis — [MỚI hoàn toàn]

**Data có sẵn: Active_1h / Active_2h / Active_4h theo từng segment**

| Segment | Active 1h (Yest) | Active 2h (Yest) | Active 4h (Yest) | Total | 1h/Total% |
|---|---|---|---|---|---|
| FT | R100 | R105 | R110 | R99 | calc |
| PT | R113 | R118 | R123 | R112 | calc |
| NLM | R126 | R131 | R136 | R125 | calc |
| NIM | R154 | R159 | R164 | R151 | calc |
| **Total** | R167 | R172 | R177 | R166 | calc |

> **Ý nghĩa kinh doanh:**
> - **1h active** = tài xế ít online — rủi ro availability giờ cao điểm
> - **4h+ active** = tài xế full-time committed — nhóm cốt lõi
> - Tỷ lệ Active 4h / Total là proxy của **driver retention quality**

#### Biểu đồ đề xuất:
- **Heatmap:** 7 ngày × 3 time windows × 5 segments (màu intensity = số tài xế)
- **Stacked bar:** Active 1h / 2h / 4h theo ngày — xem xu hướng

### Tab 4B — Forecast Accuracy Deep Dive — [MỚI / đang ở level đơn giản]

#### 4B.1 Daily Accuracy Tracker (đang có, cần nâng cấp)
| Ngày | FC Req | Actual Req | ±% | FC Dem | Actual Dem | ±% | FR% |
|---|---|---|---|---|---|---|---|
| 16-Jun | R05[c6] | R21[c6] | calc | R13[c6] | R28[c6] | calc | R180[c6] |
| 15-Jun | ... | ... | ... | ... | ... | ... | ... |

#### 4B.2 Channel Accuracy Matrix — [MỚI hoàn toàn]
- Heatmap: 5 channels × 30 ngày — màu PASS/UNDER/OVER so với FC
- Cho thấy channel nào forecast accuracy tốt nhất/kém nhất

#### 4B.3 Weekday Pattern Analysis — [MỚI]
- Box plot hoặc line chart theo thứ (Mon–Sun)
- Average Actual Request per weekday (30 ngày) vs FC
- Cho thấy pattern Mon-low, Sat/Sun-drop, working days high

---

## 🆕 Chỉ Số Mới Đề Xuất (Derived, chưa hiển thị)

### Có thể tính ngay từ source hiện tại:

| # | Chỉ số mới | Công thức | Source rows | Insight |
|---|---|---|---|---|
| 1 | **Fulfillment Rate by Channel** (daily) | Actual Demand / Actual Request | R28-34 / R21-27 | Channel nào FR thấp nhất? |
| 2 | **Supply Utilization Rate** | Online Hours / Capacity | R66 / R58 | Tài xế dùng bao nhiêu % năng lực đã đăng ký? |
| 3 | **Active Driver Retention 4h+** | Active 4h / Total Active | R177 / R166 | % tài xế gắn bó |
| 4 | **Channel Request Mix %** | Channel Actual / Total Actual | R22-27 / R21 | Tỷ trọng mỗi channel |
| 5 | **Gap vs FC (Cumulative)** | MTD Actual - MTD FC | running sum | Đang surplus hay deficit so với plan? |
| 6 | **Weekday vs Weekend Ratio** | avg(Tue-Sat) / avg(Sun-Mon) | all date series | Pattern seasonality |
| 7 | **Prod/Onlinehour Trend** | R90 daily series | R90-R97 | Efficiency xu hướng tăng/giảm? |
| 8 | **Segment Concentration Index** | (FT active / Total active) × 100 | R99 / R166 | Phụ thuộc vào FT nhiều không? |

---

## 🗂️ Tab / Page Structure Đề Xuất

```
📊 SGN Ops Dashboard v3.0
│
├── 🔴 [TAB 1] Executive Summary          ← HIỆN TẠI (cần nâng cấp KPI cards)
│   ├── KPI Pulse (6 cards + sparklines)
│   ├── Daily Operating Cockpit table
│   └── Leaderboard + Accuracy table
│
├── 📦 [TAB 2] Demand Analysis            ← MỚI
│   ├── Request vs Demand vs FR% (dual-axis chart)
│   ├── Channel Achievement Table
│   ├── Channel Mix Stacked Bar
│   └── Channel FR% Heatmap (30 days)
│
├── 🚗 [TAB 3] Supply & Driver            ← CẢI TIẾN
│   ├── Active Drivers by Segment (trend)
│   ├── Segment Efficiency Table (Prod / Online/Driver)
│   ├── Active Time Window breakdown (1h/2h/4h)
│   └── Supply Utilization Rate chart
│
├── 📈 [TAB 4] Trend & Pattern Analysis   ← MỚI
│   ├── 90-day rolling Request/Demand trend
│   ├── Weekday pattern analysis (Mon-Sun box)
│   ├── Month-over-Month comparison
│   └── Forecast Accuracy Heatmap (channel × day)
│
└── 🔬 [TAB 5] Segment Deep Dive         ← MỚI
    ├── Chọn segment → xem all metrics
    ├── Active 1h/2h/4h breakdown
    ├── Productivity & Efficiency per segment
    └── MoM comparison per segment
```

---

## ⚡ Roadmap Triển Khai (3 Giai Đoạn)

### Phase 1 — Quick Wins (1–2 ngày)
- [ ] Thêm FR% card vào KPI row (tính từ R180)
- [ ] Thêm Utilization Rate = Online Hrs / Capacity (R66/R58)
- [ ] Bổ sung tab "Channel Breakdown" trong Visual Analytics — bảng 6 channels vs FC
- [ ] Thêm series FR% lên chart Request vs Demand (trục phụ)

### Phase 2 — Sub-Metrics Drill-down (2–3 ngày)
- [ ] Tab 3: Supply & Driver — bảng Segment × (Active / Cap / Online Hrs / Prod / Online/Driver)
- [ ] Active Time Window table (1h/2h/4h by segment)
- [ ] Channel FR% heatmap (7 ngày × 6 channels)
- [ ] Channel Mix % stacked bar chart

### Phase 3 — Advanced Analytics (3–5 ngày)
- [ ] Tab 4: 90-day trend với month bands
- [ ] Weekday pattern chart (grouped bar Mon-Sun)
- [ ] Tab 5: Segment deep dive with drilldown selector
- [ ] Forecast Accuracy Heatmap (channel × 30 days, PASS/UNDER/OVER)

---

## 📐 Nguyên Tắc Thiết Kế UX

1. **Information Hierarchy:** Chỉ số quan trọng nhất (FR%, Active, Demand) luôn visible mà không cần scroll
2. **Progressive Disclosure:** Click/tab để đi vào layer sâu hơn — không dump all data lên 1 màn hình
3. **Context Always Present:** Mỗi số đều có baseline so sánh (vs FC, vs LM, vs target)
4. **Color Coding Consistent:**
   - 🟢 Xanh = đạt/tốt (≥95% plan)
   - 🟡 Vàng = cảnh báo (85–94%)
   - 🔴 Đỏ = alert (<85%)
   - 🔵 Xanh dương = thông tin trung tính (FC, historical)
5. **Mobile-readable:** Cards và số liệu key đủ lớn để xem trên điện thoại

---

## ❓ Open Questions (cần User xác nhận trước khi implement)

1. **Tab cấu trúc:** Anh muốn các tầng thông tin trên cùng 1 trang dài (scroll) hay tách thành nhiều Tab riêng?
2. **Channel WH:** WH (Warehouse) có phải ưu tiên tương đương GHN/KA/SME không, hay để cuối?
3. **Target FR%:** Target chuẩn cho FR là bao nhiêu (75%? 80%?) để hệ thống tô màu đúng?
4. **Thời hạn xem:** Anh cần xem data bao nhiêu ngày lịch sử? Hiện tại sheet có data từ 19-Mar đến nay (~3 tháng).
5. **Export:** Có cần nút Export PDF/Excel không, hay chỉ view on dashboard?
