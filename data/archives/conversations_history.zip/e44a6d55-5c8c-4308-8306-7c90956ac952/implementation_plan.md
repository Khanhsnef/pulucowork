# Kế hoạch nâng cấp SGN Ops Overview Dashboard (Phiên bản 2.1)

Tài liệu này mô tả chi tiết kế hoạch kỹ thuật để thực hiện các yêu cầu nâng cấp mới nhất cho SGN Ops Overview Dashboard.

## Ý kiến phản hồi cần thực hiện (User Requirements)

1. 📈 **So sánh Productivity MTD với kế hoạch cùng giai đoạn:** 
   - Thay vì để trống cột `planning` và `vs planning` cho chỉ số Productivity ở cấp độ MTD, chúng ta sẽ tính toán kế hoạch Productivity cho cùng kỳ (từ ngày 1 đến Yesterday) dựa trên công thức:
     $$\text{Planning Productivity MTD} = \frac{\text{Planning Capacity MTD}}{\text{Planning Active Drivers MTD (Average)}}$$
2. 🎨 **Phân biệt màu sắc tiêu đề bảng Daily Operating Cockpit:**
   - Chia nhóm màu sắc của tiêu đề các cột để người dùng nhìn rõ và phân biệt nhanh:
     - **Today** (Kế hoạch hôm nay): Làm nổi bật bằng màu cam sáng hoặc vàng hổ phách (`#D97706` / `#FF7F32`).
     - **Yesterday & MTD** (Dữ liệu thực tế kỳ hiện tại): Màu xanh lam đậm/classic blue (`#1E3A8A`).
     - **Last Week & Last Month** (Dữ liệu thực tế kỳ đối sánh): Màu xám đá đậm/slate (`#475569`).
     - **Planning** (Kế hoạch hôm qua & kế hoạch MTD): Màu xanh mòng két/teal (`#0F766E`).
3. 🔢 **Thêm nhãn số liệu cho biểu đồ (Chart Data Labels):**
   - Cấu hình Plotly hiển thị số liệu trực tiếp trên các điểm nút của biểu đồ đường (`lines+markers+text`) và cột (`bar+text`).
   - Tối ưu khoảng cách và kích thước font chữ của nhãn, định dạng số rút gọn (ví dụ: `8.5k` hoặc `8.3`) để tránh chồng chéo làm mất số hoặc rối mắt.
4. 🏆 **Leaderboard theo Demand thực tế:**
   - Thay vì sử dụng số Requests, Leaderboard Top 3 ngày nhiều đơn nhất tháng 06/2026 sẽ lấy dữ liệu từ dòng **Actual demand** (dòng 29 trong CSV, tức row index 28).
5. 📅 **Loại bỏ ngày hôm nay khỏi biểu đồ:**
   - Ngày hôm nay (17-Jun) có dữ liệu thực tế (Actual) chưa hoàn thành (bằng 0 hoặc rất nhỏ), gây ra độ dốc sụt giảm đột ngột trên biểu đồ làm xấu giao diện. Chúng ta sẽ lọc bỏ ngày hôm nay ra khỏi toàn bộ chuỗi số liệu vẽ biểu đồ.

---

## Các Thay đổi Đề xuất (Proposed Changes)

### [sgn_overview_dashboard.py](file:///Users/ts-1148/Desktop/Pulu-workspace/output/Ahamove/04. OPS_METRICS/dashboards/sgn_overview_dashboard.py)

#### 1. Loại bỏ ngày hôm nay khỏi Biểu đồ
- Trong hàm `process_series()`, trước khi resample theo ngày/tuần và lọc khoảng thời gian, chúng ta sẽ drop ngày hôm nay (`date_today` = 17-Jun-2026) ra khỏi index của series.

#### 2. Cập nhật Thuật toán Tính toán Bảng Cockpit
- Sử dụng các dòng forecast thực tế từ sheet để tính toán cho dòng **Complete**:
  - `planning`: `val(14, col_yesterday)` (dòng SME+MP+KA Forecast Demand) thay vì công thức nhân `0.81` thủ công.
  - `today`: `val(14, col_today)`.
  - `plan_mtd`: `get_row_mtd_sum(14)` (tổng Forecast Demand MTD).
- Tính toán giá trị kế hoạch MTD (`plan_mtd`) cho các chỉ số tài xế:
  - **Active plan MTD**: Trung bình cộng của active plan hàng ngày trong kỳ MTD.
    $$\text{Active plan MTD} = \text{Average}_{d \in \text{mtd\_cols}}\left( \text{act\_plan\_16jun\_total} \times \frac{\text{Forecast Request}(d)}{69263} \right)$$
  - **Capacity (Cap) plan MTD**: Tổng cộng capacity plan hàng ngày trong kỳ MTD.
    $$\text{Cap plan MTD} = \sum_{d \in \text{mtd\_cols}}\left( \text{cap\_plan\_16jun\_total} \times \frac{\text{Forecast Request}(d)}{69263} \right)$$
  - **Supply hour plan MTD**: Tổng cộng supply hours plan hàng ngày trong kỳ MTD.
  - **Productivity (Prod) plan MTD**:
    $$\text{Prod plan MTD} = \frac{\text{Cap plan MTD}}{\text{Active plan MTD}}$$
  - **online/driver plan MTD**:
    $$\text{online/driver plan MTD} = \frac{\text{Supply hour plan MTD}}{\text{Active plan MTD}}$$
  - Áp dụng tương tự cho từng phân khúc tài xế (`FT`, `PT`, `NLM`, `Return`, `NIM`, `NID`).

#### 3. Thiết kế CSS và Phân chia Màu sắc Tiêu đề
- Thay đổi phần HTML/CSS tạo header của bảng Cockpit. Thêm CSS class cho từng cột tiêu đề:
  - Cột `yesterday` và `MTD`: Class `.hdr-actual-current` (màu nền `#1E3A8A`, màu chữ trắng).
  - Cột `last week` và `last month`: Class `.hdr-actual-past` (màu nền `#475569`).
  - Cột `planning` (hôm qua và MTD): Class `.hdr-plan` (màu nền `#0F766E`).
  - Cột `today` (kế hoạch hôm nay): Class `.hdr-today` (màu nền `#D97706`).

#### 4. Thêm Data Labels cho biểu đồ Plotly
- Cập nhật hàm `render_line_chart` sử dụng `mode="lines+markers+text"`.
- Đặt thuộc tính `text` của Scatter là chuỗi số liệu được định dạng gọn (VD: đơn hàng chia cho 1,000 thêm chữ 'k', năng suất giữ 1 chữ số thập phân).
- Thiết lập `textposition="top center"` để nhãn nằm phía trên marker và không đè lên đường vẽ.
- Cập nhật hàm `render_bar_chart` để hiển thị nhãn số cột.

#### 5. Sửa dữ liệu Leaderboard
- Đọc dữ liệu từ dòng index 28 (CSV dòng 29 `Actual demand`) để xác định Top 3 ngày nhiều đơn nhất.

---

## Kế hoạch Xác minh (Verification Plan)

### Kiểm tra tự động
- Chạy script kiểm tra công thức toán học Productivity MTD để đảm bảo không bị lỗi chia cho 0 và giá trị delta hợp lý.
- Đảm bảo script Streamlit biên dịch thành công mà không có lỗi cú pháp.

### Kiểm tra thủ công
- Dùng Browser Subagent để kiểm tra trực quan giao diện tại `http://localhost:8502`:
  - Xác minh màu sắc tiêu đề bảng Cockpit hiển thị đúng 4 nhóm màu đã phân chia.
  - Xác minh nhãn dữ liệu trên các biểu đồ hiển thị rõ ràng, không bị chồng chéo che khuất lẫn nhau.
  - Xác minh biểu đồ không còn điểm rơi tụt của ngày hôm nay (17-Jun).
  - Xác minh Top 3 Leaderboard hiển thị số lượng đơn hàng (Actual Completed) khớp với dòng 29 trong CSV.
