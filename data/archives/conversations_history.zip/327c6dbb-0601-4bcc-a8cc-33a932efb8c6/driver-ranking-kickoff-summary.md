# 🚀 KICK-OFF BRIEF — Driver Ranking & AhaBenefits 2026

> **Project:** Re-structure Driver Pool · Phân tier Rank + Loyalty Program  
> **Owner:** Driver Management Team · Ahamove  
> **Version:** 2026-05-27 → Kick-off tháng 6/2026  
> **Status:** 🟡 Ready for Cross-team Alignment

---

## 📊 Executive Summary

### Bài Toán Cần Giải

Fleet hiện tại **~10.500 weekly active drivers** vận hành theo mô hình đồng nhất (flat), không có cơ chế phân biệt quality drivers với low performers. Hệ quả:

- **Fulfillment Rate** không được tối ưu vào peak-hour do không ưu tiên tài xế chất lượng cao
- **Driver Churn** tăng ở nhóm high-performer vì thiếu recognition & incentive phân tầng
- **Cost efficiency thấp**: Incentive budget phân bổ dàn trải, không đánh trúng nhóm tạo ra GSV cao nhất
- **Supply-Demand mismatch** tại L2/L3 Minizone & Mediumzone — vùng có biên lợi nhuận cao nhất

### Giải Pháp Đề Xuất

Triển khai **3-tier Ranking System (R1 💎 – R2 🥇 – R3 🥈 + Unranked)** kết hợp **AhaBenefits Point Economy** nhằm:

| Mục Tiêu | Cơ Chế |
|---|---|
| Giữ chân High-performer | Full-day Guarantee + Layer ưu tiên L2/L3 |
| Tăng Fulfillment Rate peak-hour | Slot allocation có cấu trúc theo rank & ca |
| Tối ưu Incentive Budget | Layer multiplier thay thế flat bonus |
| Xây dựng Driver Loyalty LTV | AhaPoints → Benefits Catalog partner rewards |

---

## 🎯 Cấu Trúc Rank & Điều Kiện Xét

### Tiêu Chí Rank (xét monthly)

| Rank | DQS (Driver Quality Score) | DCR (Drop/Cancel Rate) | Productivity/tháng |
|---|---|---|---|
| 💎 R1 Kim Cương | ≥ 80 | ≤ 10% | ≥ 280 đơn |
| 🥇 R2 Vàng | ≥ 75 | ≤ 10% | ≥ 210 đơn |
| 🥈 R3 Bạc | ≥ 75 | ≤ 15% | ≥ 70 đơn |
| Unranked | < 75 | — | — |

### Fleet Target Ratio (~10.500 weekly actives)

| Rank | Target % | Số lượng |
|---|---|---|
| 💎 R1 Kim Cương | 15% | ~1.575 tài xế |
| 🥇 R2 Vàng | 35% | ~3.675 tài xế |
| 🥈 R3 Bạc | 35% | ~3.675 tài xế |
| Unranked | 15% | ~1.575 tài xế |

---

## 📈 KPIs Cần Theo Dõi — Bổ Sung Chi Tiết

### 🔴 KPIs Cốt Lõi (Primary — Dashboard thời gian thực)

| KPI | Định Nghĩa | Target | Owner |
|---|---|---|---|
| **Active Drivers / tuần** | Số driver hoàn thành ≥1 đơn trong 7 ngày | ~10.500 (SGN+HAN) | BI |
| **Rank Distribution %** | Tỷ lệ R1/R2/R3/Unranked so với fleet | 15/35/35/15% | BI + Ops |
| **Fulfillment Rate (FR)** | Đơn hoàn thành / Tổng đơn nhận | ≥ 95% peak-hour | BI |
| **Acceptance Rate (AR)** | Đơn chấp nhận / Tổng đơn dispatch | Target theo rank | BI |
| **Drop/Cancel Rate (DCR)** | Đơn huỷ / Tổng đơn nhận | R1 ≤10%, R3 ≤15% | BI |
| **Driver Quality Score (DQS)** | Composite score (AR, FR, Rating, Complaint) | R1 ≥80, R2 ≥75 | Product |
| **Slot Fill Rate / Ca** | % slot đã filled / tổng slot mở theo rank & ca | ≥ 85% | Ops |
| **Cascade Trigger Rate** | % ca phải cascade sang layer kế tiếp | Monitor — baseline Q3 | BI |

### 🟡 KPIs Tài Chính & Incentive (Financial Health)

| KPI | Định Nghĩa | Target | Owner |
|---|---|---|---|
| **Cost per Order (CPO)** | Tổng incentive / Tổng đơn hoàn thành | So sánh before/after | Finance |
| **Incentive Budget Utilization** | Chi thực tế / Budget duyệt (200M/tháng) | ≤ 100% | Finance |
| **Full-day Guarantee Trigger Rate** | % tài xế R1/R2 claim guarantee | < 20% (tức driver đang đủ đơn) | Finance + Ops |
| **Voucher Redemption Rate** | Voucher xăng/EV được dùng / được cấp | > 70% | Finance |
| **AhaPoints Burn Rate** | % điểm được đổi trước khi expire | > 80% | Product |
| **Points Economy Cost (PEC)** | Tổng giá trị rewards đổi / tháng | Baseline sau launch | Finance |
| **Driver LTV (Lifetime Value)** | Doanh thu tài xế mang lại × thời gian gắn bó | So sánh R1 vs Unranked | BI |
| **Partner Reward Fill Rate** | % reward catalog có đủ hàng | ≥ 95% | Ops + BD |

### 🟢 KPIs Trải Nghiệm Tài Xế (Driver Experience)

| KPI | Định Nghĩa | Target | Owner |
|---|---|---|---|
| **Driver Churn Rate (30-day)** | % driver active tháng này nhưng inactive tháng sau | < 15% (R1/R2 < 8%) | Ops |
| **Rank Promotion Rate** | % driver được thăng rank mỗi tháng | > 10% (healthy mobility) | BI |
| **Rank Demotion Rate** | % driver bị giảm rank | < 5% (stable pool) | BI |
| **App Engagement (AhaBenefits tab)** | DAU trên tab Benefits / Total active drivers | > 40% | Product |
| **Time-to-Rank (TTR)** | Số ngày trung bình từ Unranked → R3 | < 45 ngày | BI |
| **NPS Tài Xế (Driver NPS)** | Net Promoter Score sau launch | > 50 (baseline survey) | Comms + CS |
| **Complaint Rate liên quan Rank** | Khiếu nại về xét rank / tổng tài xế | < 0.5% | CS |
| **Points-to-Reward Conversion** | % tài xế tích đủ điểm đổi ≥1 reward/quý | > 60% (R3+) | Product |

### 🔵 KPIs Vận Hành Layer & Dispatch (Operational)

| KPI | Định Nghĩa | Target | Owner |
|---|---|---|---|
| **Layer L2 Fill Rate** | Slot L2 Minizone được fill bởi R1 | > 90% trước khi cascade | Ops |
| **Overflow Rate** | % đơn phải dispatch ra ngoài primary layer | < 15% (efficiency target) | Ops + Product |
| **Peak-hour Supply Gap** | Số slot R1/R2 thiếu trong Ca Sáng/Chiều | 0 (target zero gap) | Ops |
| **Dispatch SLA** | Thời gian dispatch trung bình đến khi tài xế chấp nhận | < 60s peak / < 90s off-peak | Product |
| **Booking Window Lead Time** | Thời gian trung bình trước ca tài xế book slot | Monitor (optimize window) | Product |

---

## ✅ CROSS-TEAM CHECKLIST — Kick-off Project

> Đây là danh sách việc cần **team khác bổ sung và hỗ trợ** để triển khai thành công.  
> Driver Management Team sẽ là **BRE (Business Requirements) Owner** và phối hợp với từng team.

---

### 🛠️ PRODUCT TEAM

**Dependency mức độ: 🔴 CRITICAL — Blockers cần unblock trước Sprint 1**

- [ ] **Định nghĩa DQS (Driver Quality Score)** — Công thức tính, trọng số từng thành phần (AR, FR, Rating, Complaint), tần suất cập nhật (realtime / daily batch)
- [ ] **Thiết kế Data Model** — `PointTransaction`, `DriverPointWallet`, `ShiftSlot`, `RankSnapshot` (theo spec đã có trong tài liệu, cần confirm schema)
- [ ] **Quyết định các Open Questions** (7 câu hỏi trong Phần 7 tài liệu):
  - `RESERVED pts` có expire cuối quý không?
  - Layer overflow xác định bằng origin zone hay assigned zone?
  - Điểm PENDING cuối quý xử lý ra sao?
  - Driver bị suspend → điểm freeze hay expire?
- [ ] **Thiết kế Notification System** — 8 trigger events theo spec (cuối ca, đổi thành công, vi phạm, 7-day trước quý reset, rank thay đổi, v.v.)
- [ ] **Thiết kế AhaBenefits Tab UI/UX** — Catalog phân tier R3+/R2+/R1, redemption flow, balance display, point history
- [ ] **Define điều kiện Bonus Hoàn Ca** — Online in zone threshold (% thời lượng ca) + AR/chuyến tối thiểu để nhận bonus
- [ ] **Partner API Integration Spec** — Timeout 30s, retry logic, RESERVED → AVAILABLE fallback flow
- [ ] **Admin Tool cho CS/Ops** — Manual points adjustment (add/deduct) với audit log

---

### 💻 ENGINEERING / TECH TEAM

**Dependency mức độ: 🔴 CRITICAL**

- [ ] **Backend: Rank Calculation Engine** — Batch job cuối tháng tính rank, output `RankSnapshot` table
- [ ] **Backend: Point Ledger System** — PENDING → AVAILABLE → RESERVED → REDEEMED state machine, T+1 credit logic (batch job 02:00–04:00)
- [ ] **Backend: Slot Allocation Engine** — Slot fill theo rank, cascade trigger tại 80% fill threshold, cửa sổ ưu tiên +2h cho rank cao
- [ ] **Backend: Dispatch Layer Routing** — Cascade logic L2→L3→L4→L5→L6, layer multiplier assignment theo origin zone hay assigned zone
- [ ] **Backend: Full-day Guarantee Checker** — Validate điều kiện (online ≥95%, AR=100%, FR, DCR, no self-cancel), trigger bù tiền
- [ ] **Backend: Quarter-end Expiry Job** — Expire điểm AVAILABLE cuối quý, bảo vệ RESERVED 7 ngày, reset balance
- [ ] **Frontend: AhaBenefits Module** — Tích hợp vào driver app (iOS + Android)
- [ ] **Infrastructure: Points scalability** — Ước tính ~10.500 drivers × 22 ca/tháng × avg 93 pts = ~21.5M point transactions/tháng
- [ ] **Logging & Audit Trail** — Mọi adjustment thủ công cần log: actor, timestamp, reason, delta

---

### 📊 BI / DATA TEAM

**Dependency mức độ: 🟠 HIGH**

- [ ] **Dashboard Rank Distribution** — Realtime hoặc D+1, breakdown SGN/HAN, trend theo tháng
- [ ] **Dashboard Supply-Demand per Layer per Ca** — Slot fill rate, overflow rate, cascade trigger rate
- [ ] **Driver LTV Model** — Phân tích GSV × retention theo rank cohort (R1 vs R2 vs Unranked)
- [ ] **Driver Churn Prediction** — Model dự báo churn 30-day theo rank, early warning system
- [ ] **Point Economy Monitoring** — Avg pts earned/driver/tháng, burn rate, expire rate, cost per point redeemed
- [ ] **Baseline Data Collection** — Đo FR, AR, DCR, DQS hiện tại (before state) trước khi launch để có baseline so sánh
- [ ] **A/B Test Framework** — Nếu soft launch theo cohort, cần infra để so sánh control vs treatment
- [ ] **SQL Query Templates** — Automate tính incentive, slot allocation, point ledger reconciliation

---

### 💰 FINANCE TEAM

**Dependency mức độ: 🟠 HIGH**

- [ ] **Phê duyệt Budget 200M/tháng** — Voucher xăng R1 (~59M) + R2 (~83M) + buffer (~58M)
- [ ] **Phê duyệt biến phí Bảo hiểm tai nạn R1** — Tối đa ~47M/tháng nếu 100% R1 đăng ký gói 30k (cần approve riêng)
- [ ] **Unit Economics Model** — CPO trước/sau, ROI của Full-day Guarantee, breakeven analysis
- [ ] **Partner Reward Cost Accounting** — Paid reward (~50k/driver/tháng) + free items cost allocation
- [ ] **Incentive Reconciliation Process** — Quy trình đối soát AhaPoints với partner invoice hàng tháng
- [ ] **Tax & Compliance** — Xác định rewards có chịu thuế TNCN không (nếu giá trị > ngưỡng)
- [ ] **Point Liability Accounting** — Điểm chưa đổi = contingent liability → cần phương pháp hạch toán

---

### 🤝 BUSINESS DEVELOPMENT / PARTNER TEAM

**Dependency mức độ: 🟡 MEDIUM**

- [ ] **Ký kết Partner Agreement** — Xăng/EV (Petrolimex, EVinfast?), F&B, Bảo dưỡng, Data (Viettel/Vinaphone), Sức khoẻ
- [ ] **Negotiate Discount Rates** — Theo catalog đã đề xuất (Xăng 5-15%, Bảo dưỡng 15-30%, v.v.)
- [ ] **Partner API Integration** — Kết nối hệ thống voucher/mã giảm giá, timeout < 30s
- [ ] **Catalog Availability per City** — Confirm partner coverage SGN vs HAN (câu hỏi #7 trong Open Questions)
- [ ] **Partner SLA Agreement** — Đảm bảo reward availability ≥ 95%, refund flow khi fail
- [ ] **Insurance Partner** — Ký hợp đồng bảo hiểm tai nạn Mini cho R1 (mức bảo hiểm, quy trình claim)

---

### 🎯 OPERATIONS TEAM

**Dependency mức độ: 🟠 HIGH**

- [ ] **Define Zone Boundaries** — Xác định ranh giới chính thức L2 Minizone / L3 Mediumzone / L4 Bigzone / L5 Cityzone / L6 MASS cho SGN & HAN
- [ ] **Slot Quota per Zone per Ca** — Quyết định tổng số slot mỗi layer mỗi ca (input cho slot allocation engine)
- [ ] **Communication Plan cho Tài Xế** — Thông báo về hệ thống rank mới, lộ trình, FAQ
- [ ] **CS Escalation Playbook** — Quy trình xử lý khiếu nại liên quan rank, điểm bị trừ, slot không book được
- [ ] **Field Testing / Pilot** — Xác định zone/nhóm tài xế thí điểm trước khi full rollout
- [ ] **Ops Dashboard Training** — Hướng dẫn team Ops sử dụng Admin Tool để adjust điểm, monitor rank

---

### 📣 MARKETING / COMMS TEAM

**Dependency mức độ: 🟡 MEDIUM**

- [ ] **Driver Communication Campaign** — Announce hệ thống rank mới (Zalo, in-app push, SMS)
- [ ] **Benefit Highlight Content** — Infographic, video giải thích quyền lợi từng rank (R1/R2/R3)
- [ ] **Partner Co-branding** — Phối hợp với partners cho material quảng bá tại điểm đổi thưởng
- [ ] **Driver NPS Survey** — Thiết kế và launch survey baseline trước kick-off, follow-up sau 3 tháng
- [ ] **Referral/Recruitment Campaign** — Dùng rank system làm USP để thu hút driver mới

---

### 🏥 RISK & COMPLIANCE / LEGAL TEAM

**Dependency mức độ: 🟡 MEDIUM**

- [ ] **Anti-fraud Policy** — Quy định rõ hành vi gian lận điểm, quy trình điều tra, mức xử phạt (-50 pts + review rank)
- [ ] **Data Privacy Compliance** — Thu thập và xử lý điểm số tài xế có tuân thủ quy định PDPA/nghị định 13 không
- [ ] **Driver Agreement Update** — Cập nhật điều khoản về hệ thống rank, quyền lợi, điều kiện mất rank
- [ ] **Insurance Product Approval** — Phê duyệt sản phẩm bảo hiểm tai nạn Mini với cơ quan quản lý

---

## 📅 Lộ Trình Đề Xuất (Suggested Timeline)

| Giai Đoạn | Thời Gian | Mục Tiêu |
|---|---|---|
| **Phase 0 — Alignment** | Tuần 1-2 (T6/2026) | Cross-team kick-off, unblock Open Questions, baseline data collection |
| **Phase 1 — Foundation** | Tháng 7/2026 | Backend data model, rank engine, slot allocation engine |
| **Phase 2 — AhaBenefits MVP** | Tháng 8/2026 | Point ledger, catalog v1 (3-5 partners), driver app integration |
| **Phase 3 — Pilot** | Tháng 9/2026 | Soft launch 1 zone (SGN L2/L3), monitor KPIs, calibrate |
| **Phase 4 — Full Rollout** | Tháng 10/2026 | Mở rộng toàn SGN + HAN, full catalog, insurance |
| **Phase 5 — Optimize** | Q4/2026 | A/B test incentive, dynamic slot adjustment, LTV analysis |

---

## ⚠️ Rủi Ro & Điểm Cần Quyết Định Ngay

| # | Rủi Ro | Mức Độ | Cần Ai Quyết Định |
|---|---|---|---|
| 1 | RESERVED pts expire cuối quý → driver backlash | 🔴 HIGH | Product + Legal |
| 2 | Partner API timeout → redemption fail rate cao | 🔴 HIGH | Engineering + BD |
| 3 | DQS chưa có formula → rank calculation block toàn bộ | 🔴 HIGH | Product + BI |
| 4 | Budget bảo hiểm tai nạn chưa được phê duyệt | 🟠 MEDIUM | Finance + Legal |
| 5 | Zone boundaries L2–L5 chưa được confirm chính thức | 🟠 MEDIUM | Ops + Product |
| 6 | Driver resistance khi biết có rank system | 🟠 MEDIUM | Comms + Ops |
| 7 | Catalog partner coverage SGN vs HAN không đồng đều | 🟡 LOW-MEDIUM | BD |

---

*📌 Tài liệu này được tổng hợp từ: `2026-05-driver-ranking-ahabenefits-combined.docx`*  
*🗓️ Cập nhật: 2026-06-04 | Prepared by: Driver Management Team*
