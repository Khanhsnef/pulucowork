# Hướng Dẫn Kết Nối Gemini Pro & BananaPro (NanoBanana) Qua 9Router

Tự động hóa quy trình sáng tạo hình ảnh truyền thông đối tác tài xế (Driver Engagement) bằng cách tích hợp Gemini Pro và NanoBanana API thông qua cổng kết nối trung gian 9Router. Hệ thống giảm tải áp lực thiết kế thủ công, hỗ trợ các chiến dịch chuyển đổi xe điện (EV) và tối ưu hóa chi phí vận hành sáng tạo.

---

## 1. Tóm Tắt Thực Thi (Executive Summary)

### 📊 Executive Summary
Giải pháp tích hợp giúp Ahamove tự động hóa hoàn toàn quy trình thiết kế ấn phẩm truyền thông cho tài xế. Bằng cách kết hợp khả năng lập luận của **Gemini Pro** (để viết prompt và lên ý tưởng truyền thông) với hiệu suất sinh ảnh chuyên biệt của **BananaPro** (thông qua cổng NanoBanana API), tất cả được quản lý tập trung và định tuyến thông minh qua **9Router** chạy cục bộ tại hệ thống.

### 🎯 Mục tiêu Kinh doanh (Business Objectives)
*   **Tối ưu hóa CPO & Creative Budget:** Giảm chi phí tạo ảnh truyền thông xuống mức tối thiểu nhờ tận dụng hạn ngạch miễn phí từ Gemini API và tối ưu hóa chi phí của NanoBanana.
*   **Tăng tốc độ truyền thông (SLA):** Rút ngắn thời gian sản xuất ấn phẩm từ 2 ngày xuống dưới 5 phút cho các chiến dịch khẩn cấp (thời tiết, peak-hour, sự cố vận hành).
*   **Tăng tỷ lệ tương tác (CTR):** Đa dạng hóa hình ảnh truyền thông cá nhân hóa tới từng nhóm đối tác tài xế Bike/Hub.

### 📈 Chỉ số Cốt lõi (Important KPIs)
*   **Fulfillment Rate (Tỷ lệ hoàn thành ảnh):** Đạt 100% yêu cầu sinh ảnh truyền thông chuẩn hóa tự động.
*   **Cost per Asset (Chi phí trung bình mỗi ảnh):** Mục tiêu dưới $0.05/ảnh.
*   **Latency SLA (Thời gian phản hồi sinh ảnh):** Dưới 15 giây/ảnh.
*   **CTR của banner thông báo:** Đạt trên 8% so với mức trung bình 5% trước đây.

---

## 2. KHUNG PHÂN TÍCH (ANALYSIS FRAMEWORK)

### Phân tích Mô tả (Đánh giá Hiện trạng - Descriptive Analysis)
*   **Hạ tầng Vận hành hiện tại:** Bộ phận Driver Management hiện đang sử dụng các mẫu thiết kế tĩnh trên Figma hoặc Canva, chỉnh sửa thủ công. Tốc độ truyền tải thông tin đến tài xế bị trễ nhịp so với các biến động thực địa (như giờ cao điểm peak-hour, mưa ngập, hoặc điều chỉnh thưởng incentive đột xuất).
*   **Benchmarks Hiệu suất:** Các đối thủ lớn như Grab Express và Be Delivery đã tự động hóa luồng phân phối banner cá nhân hóa qua ứng dụng tài xế dựa trên thời gian thực.
*   **Hệ sinh thái Liên quan:** Yêu cầu sự phối hợp chặt chẽ giữa bộ phận Operations (Driver Engagement), BI (cung cấp dữ liệu tài xế để cá nhân hóa) và Tech/Product (tích hợp API hiển thị banner trên app tài xế).

### Phân tích Chẩn đoán (Điều tra Nguyên nhân Gốc rễ - Diagnostic Analysis)
*   **Khoảng trống Chất lượng (Quality Gaps):** Thiếu tính cá nhân hóa trong truyền thông. Banner chung chung không thúc đẩy tài xế hoạt động vào peak-hour.
*   **Điểm nghẽn Vận hành (Bottlenecks):** Đội ngũ thiết kế quá tải, không thể hỗ trợ các yêu cầu thiết kế phát sinh tức thời từ phía vận hành thực địa.
*   **Lệch pha Chiến lược (Misalignments):** Ngân sách dành cho Marketing và Incentive bị thắt chặt trong Q2 2026, đòi hỏi giải pháp tối ưu hóa chi phí sản xuất ấn phẩm.

### Phân tích Dự báo (Mô hình hóa Tương lai - Predictive Analysis)
*   **Dự phóng Kết quả:** Tự động hóa 90% việc tạo ảnh banner thông báo thường nhật. Giải phóng 30% thời gian làm việc của nhân sự vận hành.
*   **Mô hình hóa Tác động:** Tăng 20% khả năng tương tác của tài xế thông qua các thông báo trực quan, góp phần giữ chân đối tác tài xế (Driver Retention) và tăng tỷ lệ nhận đơn (Acceptance Rate) vào khung giờ khó khăn.

### Phân tích Đề xuất (Khuyến nghị Chiến lược - Prescriptive Analysis)
*   **Lộ trình Tối ưu:** Triển khai kết nối Gemini Pro và NanoBanana API (BananaPro) qua 9Router chạy local để xây dựng hệ thống tự động sinh ảnh.
*   **Bản đồ Thực thi:** Hướng dẫn kỹ thuật từng bước kết nối trên hệ thống:

#### BƯỚC 1: KHỞI ĐỘNG CỔNG KẾT NỐI 9ROUTER
Mở terminal trên máy và chạy dịch vụ 9Router:
```bash
9router
```
*(Hoặc dùng lệnh đầy đủ: `cd ~/tools/9router && npm run dev`)*. Dịch vụ chạy trên cổng `http://localhost:20128`.

#### BƯỚC 2: KẾT NỐI GEMINI PRO API KEY
1. Truy cập giao diện quản trị 9Router tại địa chỉ `http://localhost:20128`.
2. Đăng nhập bằng mật khẩu được thiết lập trong `.env.local` (mật khẩu mặc định: `Khanh.le@123`).
3. Điều hướng đến phần **Providers** > Tìm kiếm **Gemini**.
4. Nhấp vào nút **Connect** và dán mã API Key của Google AI Studio (lấy từ [Google AI Studio](https://aistudio.google.com/app/apikey)).
5. Nhấp vào **Save** để kích hoạt. 9Router sẽ tự động nhận diện các mô hình Gemini Pro (ví dụ: `gemini-2.5-pro`, `gemini-2.0-flash`).

#### BƯỚC 3: KẾT NỐI BANANAPRO / NANOBANANA API
1. Tại giao diện **Providers** của 9Router > Tìm kiếm **NanoBanana API** (đây là cổng tích hợp chính thức của mô hình tạo ảnh BananaPro trong 9Router).
2. Nhấp vào **Connect** và dán mã API Key của NanoBanana API (lấy từ [NanoBanana API Dashboard](https://nanobananaapi.ai/dashboard) hoặc nền tảng đối tác bananaproai.com).
3. Nhấp vào **Save**. 9Router sẽ tự động kết nối và đồng bộ danh sách mô hình tạo ảnh từ NanoBanana API.

#### BƯỚC 4: GỌI API ĐỂ TẠO ẢNH TRUYỀN THÔNG TỰ ĐỘNG
9Router cung cấp endpoint chuẩn tương thích OpenAI tại địa chỉ:  
`POST http://localhost:20128/v1/images/generations`

Sử dụng cURL hoặc tích hợp vào code backend để sinh ảnh:
```bash
curl -X POST http://localhost:20128/v1/images/generations \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Một đối tác tài xế Ahamove mặc áo khoác màu cam đặc trưng, đội mũ bảo hiểm Ahamove, đang mỉm cười thân thiện bên cạnh xe máy điện Selex trong bối cảnh phố phường Hà Nội hiện đại, phong cách ảnh chụp chuyên nghiệp, ánh sáng tự nhiên",
    "model": "nanobanana/nano-banana-pro",
    "n": 1,
    "size": "1024x1024"
  }'
```
Kết quả trả về sẽ chứa đường dẫn URL chứa ảnh đã sinh ra để tải về hoặc đưa thẳng lên giao diện truyền thông tài xế.

---

## 3. 📈 HIỆN THỰC HÓA GIÁ TRỊ (VALUE REALIZATION)

### Đo lường Tác động Kinh doanh (Measurable Business Impact)

| Hiện trạng (Current State) | Chuyển đổi (Transformation) | Trạng thái Mục tiêu (Target State) | Tác động (Impact) |
| :--- | :--- | :--- | :--- |
| Quy trình thiết kế ảnh truyền thông thủ công trên Canva/Figma tốn 24-48 giờ/yêu cầu. | ↓ TỰ ĐỘNG HÓA QUA API ↓ | Sinh ảnh trực tiếp qua API 9Router tích hợp Gemini Pro & NanoBanana. | **Giảm 99% thời gian xử lý (dưới 15 giây/ảnh), đáp ứng tức thì các chiến dịch khẩn cấp.** |
| Chi phí nhân sự và vận hành thiết kế cao ($2 - $5/ảnh thiết kế). | ↓ TỐI ƯU HÓA CHI PHÍ ROUTER ↓ | Tận dụng quota free của Gemini và định tuyến giá rẻ của NanoBanana. | **Giảm 95% chi phí sáng tạo ấn phẩm truyền thông (xuống < $0.05/ảnh).** |
| Ảnh truyền thông mang tính đại trà, không có tính cá nhân hóa cho từng nhóm tài xế (Bike vs Hub). | ↓ CÁ NHÂN HÓA HÀNG LOẠT ↓ | Sinh ảnh động dựa trên thông tin định danh tài xế qua hệ thống backend. | **Tăng 30% tỷ lệ tương tác (CTR) của tài xế đối với các thông báo và banner tuyển dụng.** |

---
**Tài liệu vận hành Ahamove - Driver Management Team | 2026-05-28**
