# Hướng Dẫn Cấu Hình Cline, Roo, Continue, OpenCode & OpenClaw Với 9router

Tài liệu này hướng dẫn bạn cấu hình các công cụ lập trình AI mã nguồn mở hàng đầu để kết nối với proxy cục bộ **9router** (mặc định chạy tại địa chỉ `http://localhost:20128/v1`).

---

## 1. Cấu Hình Cline (VS Code Extension)

**Cline** hỗ trợ kết nối trực tiếp đến các cổng tương thích OpenAI mà không cần can thiệp hệ thống.

### Các bước thực hiện:
1. Mở VS Code, click vào biểu tượng **Cline** ở thanh sidebar bên trái.
2. Click vào biểu tượng **Cài đặt (Gear icon)** ở góc trên bên phải giao diện Cline.
3. Cấu hình các thông số như sau:
   *   **API Provider:** Chọn `OpenAI Compatible`
   *   **Base URL:** Nhập `http://localhost:20128/v1`
   *   **API Key:** Nhập một chuỗi ký tự bất kỳ làm placeholder (Ví dụ: `9router` hoặc `sk-9router`). *Vì 9router sẽ quản lý API Key thực tế của bạn.*
   *   **Model ID:** Nhập ID của model bạn đã cấu hình trong 9router (Ví dụ: `claude-3-5-sonnet-20241022` hoặc `deepseek-chat`).
4. Bấm **Save** để lưu lại.

---

## 2. Cấu Hình Roo Code (VS Code Extension)

**Roo Code** (bản fork của Cline) có giao diện và cách cấu hình tương tự.

### Các bước thực hiện:
1. Mở sidebar **Roo Code** trong VS Code.
2. Click vào biểu tượng **Cài đặt**.
3. Cấu hình tương tự Cline:
   *   **Provider:** Chọn `OpenAI Compatible`
   *   **Base URL:** Nhập `http://localhost:20128/v1`
   *   **API Key:** Nhập placeholder `9router`
   *   **Model ID:** Nhập ID model bạn muốn sử dụng (Ví dụ: `claude-3-5-sonnet-20241022`).
4. Bấm **Save**.

---

## 3. Cấu Hướng Dẫn Cấu Hình Continue (VS Code & JetBrains)

**Continue** được cấu hình thông qua file `config.json` cục bộ.

### Các bước thực hiện:
1. Click vào biểu tượng **Gear (Cài đặt)** ở góc dưới bên phải khung chat của Continue, hoặc mở trực tiếp file tại đường dẫn:
   *   **macOS / Linux:** `~/.continue/config.json`
   *   **Windows:** `%USERPROFILE%\.continue\config.json`
2. Thêm hoặc sửa đổi cấu hình trong mảng `models` và `tabAutocompleteModel` như sau:

```json
{
  "models": [
    {
      "title": "9router Claude Sonnet",
      "provider": "openai",
      "model": "claude-3-5-sonnet-20241022",
      "apiBase": "http://localhost:20128/v1",
      "apiKey": "9router"
    },
    {
      "title": "9router DeepSeek Coder",
      "provider": "openai",
      "model": "deepseek-coder",
      "apiBase": "http://localhost:20128/v1",
      "apiKey": "9router"
    }
  ],
  "tabAutocompleteModel": {
    "title": "9router Autocomplete",
    "provider": "openai",
    "model": "deepseek-coder",
    "apiBase": "http://localhost:20128/v1",
    "apiKey": "9router"
  }
}
```
3. Lưu file. **Continue** sẽ tự động nhận diện cấu hình mới ngay lập tức.

---

## 4. Cấu Hình OpenCode (CLI / TUI Agent)

**OpenCode** lưu trữ cấu hình nhà cung cấp trong file cấu hình JSON cục bộ của nó.

### Các bước thực hiện:
1. Mở hoặc tạo file cấu hình nhà cung cấp tại đường dẫn cấu hình mặc định của OpenCode (thường là `~/.opencode/opencode.json` hoặc file `providers.json` tương ứng).
2. Thêm hoặc cập nhật provider tương thích OpenAI trỏ về 9router:

```json
{
  "providers": {
    "9router": {
      "type": "openai",
      "baseURL": "http://127.0.0.1:20128/v1",
      "apiKey": "9router",
      "models": [
        "claude-3-5-sonnet-20241022",
        "deepseek-coder"
      ]
    }
  },
  "defaultProvider": "9router"
}
```
3. Khởi động lại session OpenCode trong terminal của bạn để áp dụng cấu hình.

---

## 5. Cấu Hình OpenClaw (Self-hosted Agent Framework)

**OpenClaw** có thể tích hợp qua file `.env` hoặc file cấu hình gateway của nó.

### Các bước thực hiện:
1. Khi chạy lệnh khởi tạo `openclaw onboard`, hãy chọn tùy chọn nhà cung cấp là **Custom OpenAI Endpoint**.
2. Nếu cấu hình thủ công qua file `.env` hoặc file config:
   *   Thiết lập biến môi trường API Base:
       ```env
       OPENAI_API_BASE=http://localhost:20128/v1
       OPENAI_API_KEY=9router
       DEFAULT_MODEL=claude-3-5-sonnet-20241022
       ```
3. Chạy lệnh khởi động OpenClaw để kiểm tra kết nối thông qua dashboard của 9router.
