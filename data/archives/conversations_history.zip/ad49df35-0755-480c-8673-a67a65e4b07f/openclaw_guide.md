# Cẩm Nang Cấu Hình & Sử Dụng OpenClaw (Tích Hợp 9router)

## Tóm Tắt Thực Thi (Executive Summary)

*   🤖 **OpenClaw là gì:** Một khung tác nhân AI mã nguồn mở, tự lưu trữ (self-hosted), hoạt động như một "bộ khung ngoài" (exoskeleton) cho phép LLM tương tác trực tiếp với hệ điều hành thông qua terminal, chỉnh sửa tệp tin, và quản lý các tác vụ tự động.
*   🔌 **Kết nối 9router:** Giúp định tuyến toàn bộ yêu cầu của OpenClaw qua proxy cục bộ để tiết kiệm token và tự động đổi model thông minh.
*   💡 **Mô hình sử dụng:** Dùng làm trợ lý chạy lệnh terminal trực tiếp, kiểm thử nhanh, và sửa lỗi code cục bộ song song với **Antigravity** trong IDE.

---

## KHUNG SETUP & CẤU HÌNH (Setup Guide)

Hệ thống của bạn đã được cài đặt gói global `openclaw` và cấu hình ban đầu thông qua `openclaw onboard`. Dưới đây là cách quản lý và tối ưu cấu hình:

### 1. File Cấu Hình Cốt Lõi
Toàn bộ cấu hình của OpenClaw được lưu trữ tại file:
*   [openclaw.json](file:///Users/ts-1148/.openclaw/openclaw.json)

Khi kết nối qua **9router**, phần cấu hình model trong file này sẽ trỏ về cổng tương thích OpenAI cục bộ:
```json
{
  "gateway": {
    "auth": {
      "token": "0c440fe3e0f985320d384ad19678b79ea5960ce9c8361960"
    }
  },
  "models": {
    "default": "openai/claude-3-5-sonnet-20241022",
    "providers": {
      "openai": {
        "apiKey": "9router",
        "apiBase": "http://localhost:20128/v1"
      }
    }
  }
}
```

### 2. Quản Lý Dịch Vụ Gateway (Chạy ngầm)
OpenClaw chạy một dịch vụ nền (Gateway) để kết nối TUI và Web UI:
*   **Khởi động lại Gateway:** `openclaw gateway restart`
*   **Dừng Gateway:** `openclaw gateway stop`
*   **Kiểm tra trạng thái:** `openclaw gateway status`

---

## CÁCH SỬ DỤNG HẰNG NGÀY (Daily Usage Guide)

### 1. Tương Tác Qua Giao Diện Terminal (TUI)
Để bắt đầu làm việc với agent ngay trong terminal, chạy lệnh:
```bash
openclaw tui
```
*Hoặc sử dụng lệnh tắt:* `openclaw chat`

#### Các lệnh điều khiển hữu ích bên trong TUI:
Gõ các lệnh sau trực tiếp vào dòng chat ở dưới cùng:

| Lệnh (Command) | Chức năng (Function) |
| :--- | :--- |
| `/model` | **Thay đổi model** của session hiện tại (ví dụ chọn giữa Claude 3.5 Sonnet và DeepSeek Coder). |
| `/new` | **Tạo phiên làm việc mới**, làm sạch ngữ cảnh cũ để tránh lãng phí token. |
| `/clear` | Xóa sạch màn hình chat hiện tại (nhưng vẫn giữ ngữ cảnh). |
| `/exit` | **Thoát** khỏi giao diện TUI về terminal thường. |
| `/tools` | Danh sách các công cụ mà Agent được phép dùng (Đọc file, Chạy lệnh terminal, Web search). |

---

### 2. Tương Tác Qua Giao Diện Trình Duyệt (Web UI / ClickClack)
Nếu bạn không quen sử dụng giao diện đen trắng của terminal, hãy sử dụng giao diện web:
1. Mở trình duyệt web của bạn.
2. Truy cập vào địa chỉ Web UI cục bộ:
   *   [http://127.0.0.1:18789/#token=0c440fe3e0f985320d384ad19678b79ea5960ce9c8361960](http://127.0.0.1:18789/#token=0c440fe3e0f985320d384ad19678b79ea5960ce9c8361960)
3. Giao diện này cung cấp trải nghiệm chat như Claude.ai hay ChatGPT nhưng có hiển thị chi tiết các bước chạy lệnh terminal và chỉnh sửa file của agent.

---

### 3. Phân Phối Công Việc Giữa Antigravity & OpenClaw

Để đạt năng suất cao nhất, hãy áp dụng mô hình phân vai sau:

*   **Antigravity (IDE):** Đảm nhận phân tích logic nghiệp vụ lớn, giải thích luồng code phức tạp và đưa ra sơ đồ kiến trúc (như phân tích Driver Churn Framework).
*   **OpenClaw (Terminal):** Giao các task thực thi lặp đi lặp lại.
    *   *Ví dụ:* "OpenClaw, hãy viết một shell script tự động quét và tối ưu hóa các tệp tin log cũ".
    *   *Ví dụ:* "Chạy bộ test suite của dự án này và sửa các lỗi compiler nếu có".

---

## 📈 HIỆN THỰC HÓA GIÁ TRỊ (Value Realization)

| Hiện trạng trước đây | Cải tiến sau khi có OpenClaw & 9router | Tác động cụ thể |
| :--- | :--- | :--- |
| Bạn phải tự copy code, chạy test thủ công, và tự sửa các lỗi cú pháp lặt vặt. | **Tự động hóa hoàn toàn:** OpenClaw tự chạy test, tự đọc log lỗi, và tự sửa code trực tiếp trên ổ đĩa. | ***Tiết kiệm 60% thời gian debug lỗi cú pháp.*** |
| Chi phí API tăng cao khi dùng các Agent thực thi dòng lệnh do cơ chế gửi lại ngữ cảnh lớn. | **Tiết kiệm token:** Proxy 9router nén dữ liệu output của terminal (RTK) giúp giảm 20-40% lượng token tiêu thụ. | ***Giảm chi phí vận hành AI hàng tháng.*** |
