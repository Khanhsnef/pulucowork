# Phân Tích Hiệu Suất Hệ Thống: Cảnh Báo Nghẽn Cổ Chai Tài Nguyên

## 1. Tóm Tắt Thực Thi (Executive Summary)

*   📊 **Executive Summary:** Hạ tầng máy tính đang rơi vào trạng thái quá tải tài nguyên (Resource Exhaustion) nghiêm trọng. Hiện tượng "mạng chập chờn" là **ảo giác vận hành** do CPU quá tải làm chậm tốc độ render, thực tế đường truyền mạng vẫn đạt chuẩn.
*   🎯 **Mục tiêu Kinh doanh (Business Objectives):** Giải phóng ngay lập tức điểm nghẽn bộ nhớ, khôi phục tốc độ xử lý (SLA) và ngăn chặn rủi ro sập hệ thống (System Crash).
*   📈 **Chỉ số Cốt lõi (Important KPIs):**
    *   **System Load Average:** `15.35` (Cực kỳ rủi ro, hệ thống đang phải xếp hàng xử lý lượng lớn tác vụ).
    *   **CPU Utilization:** `86.9%` (User: 42.38%, Sys: 44.53% - Hệ thống tốn quá nhiều sức lực cho việc hoán đổi nền).
    *   **Available RAM:** Chỉ còn `147MB` (Cạn kiệt tài nguyên cung).
    *   **Network Packet Loss:** `0%` với Latency `~50ms` (Mạng hoạt động hoàn hảo).

## 2. KHUNG PHÂN TÍCH (ANALYSIS FRAMEWORK)

### Phân tích Mô tả (Đánh giá Hiện trạng - Descriptive Analysis)
*   *Hạ tầng Vận hành hiện tại:* Máy tính đã hoạt động liên tục (uptime) **5 ngày 22 giờ**.
*   *Benchmarks Hiệu suất:* Hoạt động nén bộ nhớ (Compressor) lên đến `3.3GB`, cho thấy RAM vật lý không đủ đáp ứng Cầu (nhu cầu xử lý của các ứng dụng). Hệ thống đang phải phụ thuộc hoàn toàn vào cơ chế Swap (hoán đổi ổ cứng thành RAM ảo) với hơn `100 triệu` lượt swap-in/out.

### Phân tích Chẩn đoán (Điều tra Nguyên nhân Gốc rễ - Diagnostic Analysis)
*   *Khoảng trống Chất lượng (Quality Gaps):* Hiện tượng giật lag bắt nguồn từ mức độ tiêu hao Sys CPU quá cao (`44.53%`), điều này xảy ra do máy phải chật vật hoán đổi dữ liệu từ RAM xuống ổ cứng và ngược lại.
*   *Điểm nghẽn Vận hành (Bottlenecks):* **Trình duyệt Google Chrome** đang là nguyên nhân cốt lõi phá vỡ cân bằng Cung - Cầu tài nguyên. Đặc biệt, có một luồng `Google Chrome Helper` (PID `99226`) đang trong trạng thái `stuck` (treo cứng), tiêu tốn liên tục thời gian xử lý và chiếm bộ nhớ. Ngoài ra, hàng chục Helper phụ khác đang ngốn lượng lớn RAM (mỗi luồng khoảng ~200-300MB).

### Phân tích Dự báo (Mô hình hóa Tương lai - Predictive Analysis)
*   *Dự phóng Kết quả (Outcome Projections):* Nếu tiếp tục duy trì trạng thái này, máy tính sẽ rơi vào hiện tượng *Thrashing* (chỉ lo hoán đổi bộ nhớ, không xử lý được tác vụ thực), dẫn đến sập ứng dụng và mất dữ liệu đang làm việc.
*   *Mô hình hóa Tác động (Impact Modeling):* Năng suất làm việc sẽ giảm sút nghiêm trọng do thời gian chờ phản hồi (SLA drop) từ các phần mềm tăng gấp nhiều lần.

### Phân tích Đề xuất (Khuyến nghị Chiến lược - Prescriptive Analysis)
*   *Lộ trình Tối ưu (Optimal Path):*
    1.  **Can thiệp khẩn cấp:** Mở `Activity Monitor` (hoặc chạy lệnh `kill -9 99226`) để buộc dừng tiến trình Chrome bị treo. Tốt nhất là tắt toàn bộ trình duyệt Chrome để giải phóng bộ nhớ.
    2.  **Khôi phục hệ thống:** Thực hiện Khởi động lại (Restart) máy để thiết lập lại vùng nhớ (Clear Cache/Memory) và tắt các tiến trình rác tồn đọng sau gần 6 ngày hoạt động.
*   *Tối ưu Nguồn lực (Resource Optimization):* Hạn chế mở hàng loạt Tab Chrome. Đề xuất ứng dụng các cơ chế quản trị bộ nhớ tự động (Tab Suspender) để giải quyết tình trạng rò rỉ bộ nhớ (Memory Leak).

## 3. 📈 HIỆN THỰC HÓA GIÁ TRỊ (VALUE REALIZATION)

| Hiện trạng (Current State) | Chuyển đổi (Transformation) | Trạng thái Mục tiêu (Target State) | Tác động (Impact) |
| :--- | :--- | :--- | :--- |
| RAM cạn kiệt (147MB Free), CPU Load > 15, trình duyệt treo cứng. | ↓ TÁI PHÂN BỔ TÀI NGUYÊN ↓<br>*(Kill Chrome + Restart)* | Giải phóng 4GB+ RAM, Load Average duy trì dưới mức 3.0. | ***Phục hồi 100% hiệu suất làm việc & Xóa bỏ tình trạng giật lag*** |
| Ảo giác "mạng chập chờn" do giao diện không phản hồi kịp. | ↓ HIỆU CHUẨN NHẬN THỨC ↓ | Chẩn đoán dựa trên dữ liệu Ping nội bộ (0% Loss, 50ms). | ***Phát hiện đúng nguyên nhân gốc rễ (Hệ thống, không phải Đường truyền)*** |
