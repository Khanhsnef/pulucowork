# Kế hoạch tái cấu trúc và dọn dẹp Workspace

Đề xuất phương án tổ chức lại các thư mục trong workspace, gom các script bổ trợ và file tạm ra khỏi thư mục `Output` và thư mục gốc, giúp workspace sạch sẽ, chuyên nghiệp và dễ quản lý.

## Đánh giá hiện trạng & Phát hiện rác (Clutter Issues)

1. **Script code nằm rải rác trong `Output`**:
   * File `Output/Ahamove/02. CAMPAIGNS_PROJECTS/create-form.gs` (Google Apps Script) nằm chung với các file báo cáo/campaign tracking.
2. **Thư mục Template trùng lặp**:
   * Thư mục `Output/templates/` chứa các bản template HTML cũ (`slide-theme-dark.html`, `analytics-report.html`, `ahamove-weekly-perf-mau2.html`...). Trong khi toàn bộ đã được chuẩn hóa và gom về thư mục master `_templates/` ở root.
   * Thư mục `Output/Ahamove/01. STRATEGY & PLANNING/templates/` hiện đang trống rỗng (chỉ có `.gitkeep`).
3. **Các file dữ liệu tạm và file trùng lặp trong `Output/Ahamove/04. OPS_METRICS/`**:
   * File `4664` (thực chất là một CSV export) là file hardlink trùng lặp với file `raw-data/Analyze bấy bá - phần 2 - dispatch.csv` (cùng kích thước 1.9MB).
   * File tạm của MS Excel: `~$weekly-ops-dashboard.xlsx` và `copyweekly-ops-dashboard.xlsx` (bản copy cũ).
4. **File rác ở thư mục gốc (Root Workspace)**:
   * File Excel tạm: `~$OKR Q2-2026 - DM Team (Khanh Le).xlsx`
   * File test tạm: `hello.txt`
   * File backup: `2026-06-08T15-33-01.954+07-00-openclaw-backup.tar.gz`
   * File CSV thô: `sgn_sheet_raw.csv` (dữ liệu thô nên được cất gọn).

---

## Đề xuất cấu trúc mới (Proposed Structure)

### 1. Phân loại cấu trúc chính
* **`Output/`**: Chỉ chứa tài liệu đầu ra cuối cùng (PDF, HTML, Excel report hoàn chỉnh) và các dashboard tương tác đang sử dụng. Không chứa script code bổ trợ, file test hoặc file raw data thô.
* **`_scripts/`**: Nơi duy nhất chứa code script chạy tự động hoặc bổ trợ. Chia nhóm theo dự án (ví dụ: `_scripts/driver-ranking/`, `_scripts/ops-metrics/`, `_scripts/campaigns/`).
* **`data/`**: Chứa các file SQLite DB hoặc raw CSV dữ liệu đầu vào.
* **`_templates/`**: Thư mục master chứa các template HTML chuẩn và file index thư viện `TEMPLATE-LIBRARY.html`.

### 2. Các file sẽ di chuyển & Dọn dẹp

#### [DELETE] Các file rác/trùng lặp
* Delete: `Output/Ahamove/04. OPS_METRICS/4664` (File trùng lặp hardlink).
* Delete: `Output/Ahamove/04. OPS_METRICS/~$weekly-ops-dashboard.xlsx` (Excel temp lock file).
* Delete: `~$OKR Q2-2026 - DM Team (Khanh Le).xlsx` (Excel temp lock file ở root).
* Delete: `hello.txt` (File test rác ở root).
* Delete thư mục trống: `Output/Ahamove/01. STRATEGY & PLANNING/templates/`
* Delete thư mục trùng lặp: `Output/templates/` (Đã được chuyển hết sang `_templates/` ở root).

#### [MODIFY] Di chuyển các file code và data về đúng vị trí
* Move `Output/Ahamove/02. CAMPAIGNS_PROJECTS/create-form.gs` ➔ [NEW] `_scripts/campaigns/create-form.gs`
* Move `sgn_sheet_raw.csv` ➔ `data/sgn_sheet_raw.csv` (Gom file dữ liệu thô vào `data/`).
* Move `2026-06-08T15-33-01.954+07-00-openclaw-backup.tar.gz` ➔ `.tmp/openclaw-backup.tar.gz` (Cất file backup nén vào thư mục tạm `.tmp`).
* Move `Output/Ahamove/04. OPS_METRICS/copyweekly-ops-dashboard.xlsx` ➔ `Output/Ahamove/04. OPS_METRICS/raw-data/copyweekly-ops-dashboard.xlsx` (Cất bản copy cũ của dashboard vào thư mục dữ liệu).

---

## Kế hoạch kiểm tra & Xác nhận (Verification Plan)
1. **Kiểm tra cú pháp và sự tồn tại**:
   Chạy lệnh tìm kiếm trong `Output` để đảm bảo không còn file `.gs` hay `.py` bổ trợ nào khác, và không còn file tạm `~$*.xlsx`.
2. **Kiểm tra đồng bộ**:
   Đảm bảo thư mục `_templates` vẫn hoạt động tốt khi truy cập các template.
