# 📑 BRIEF PRESENTATION: DRIVER RANKING & AHABENEFITS V2.0
> **Dự án:** Tái cấu trúc Hệ thống Xếp hạng Đối tác & Hệ sinh thái Phúc lợi Đặc quyền v2.0
> **Người trình bày:** Driver Management Team
> **Tài liệu tham chiếu:** [2026-05-driver-ranking-presentation.html](file:///Users/ts-1148/Desktop/Pulu-workspace/Output/Ahamove/01. STRATEGY & PLANNING/driver-ranking/2026-05-driver-ranking-presentation.html)

---

## 1. TÓM TẮT THỰC THI (EXECUTIVE SUMMARY)

Dự án **Driver Ranking & AhaBenefits v2.0** được xây dựng nhằm giải quyết triệt để sự thiếu hiệu quả của mô hình xếp hạng cũ. Thay vì duy trì một hệ thống thăng hạng mang tính hình thức, phiên bản v2.0 thiết lập một **cơ chế ràng buộc khép kín**: Chất lượng phục vụ định lượng bằng điểm **DQS** quyết định Thứ hạng (**Rank**), Thứ hạng quyết định khung giờ ưu tiên đăng ký các Vùng hoạt động hiệu suất cao (**Layer**), và sự hấp dẫn của phúc lợi (**AhaPoints**) tại các Layer này đóng vai trò lực kéo tự nhiên điều phối nguồn cung.

*   🎯 **Mục tiêu Kinh doanh (Business Objectives):**
    *   **Chuẩn hóa chất lượng dịch vụ:** Loại bỏ các đối tác gian lận hoặc chất lượng kém thông qua bộ chỉ số DQS làm mồi lọc tiên quyết.
    *   **Tự động điều phối nguồn cung:** Sử dụng cơ chế đăng ký ca và hệ số AhaPoints để kéo tài xế tự nguyện lấp đầy các khu vực trọng điểm vào giờ cao điểm (Peak-hour), giảm phụ thuộc vào thưởng tiền mặt trực tiếp (Promo/Incentives).
    *   **Tối ưu hóa ngân sách P&L:** Tinh giản cơ cấu chi phí hỗ trợ, chuyển dịch từ chi phí cố định (Đảm bảo thu nhập) sang chi phí biến đổi linh hoạt dựa trên hiệu suất đóng góp thực tế.
*   📈 **Chỉ số Cốt lõi (Important KPIs):**
    *   **DQS (Driver Quality Score):** Duy trì tỷ lệ R1 Elite đạt DQS &ge; 80, R2/R3 &ge; 75.
    *   **Fulfillment Rate (FR):** Tỷ lệ lấp đầy ca đạt &ge; 90% tại L2 Minizone và L3 Mediumzone.
    *   **Acceptance Rate (AR):** Đạt &ge; 90% toàn hệ thống nhờ cơ chế đăng ký theo ca cam kết.
    *   **Contribution Margin (CM) & CPO (Cost per Order):** Giảm CPO trung bình nhờ tối ưu hóa cơ cấu thưởng AhaPoints.

---

## 2. KHUNG PHÂN TÍCH CHIẾN LƯỢC (STRATEGIC ANALYSIS FRAMEWORK)

### 2.1. Phân Tích Mô Tả (Descriptive Analysis - Hiện Trạng)
Hệ thống cũ chỉ đo lường số lượng cuốc xe (Productivity) mà thiếu đi bộ chỉ số chất lượng dịch vụ (DQS) và tỷ lệ hoàn thành đơn (FR). Tài xế không có động lực nâng cao thái độ phục vụ do đặc quyền giữa các Rank mờ nhạt, thiếu tính phân hóa. Ngân sách thưởng ca bị phân mảnh và không đem lại hiệu quả giữ chân tài xế trung thành.

### 2.2. Phân Tích Chẩn Đoán (Diagnostic Analysis - Nguyên Nhân)
*   **Khoảng trống Chất lượng:** Tài xế cày cuốc số lượng đơn để giữ Rank nhưng chất lượng SLA suy giảm.
*   **Lệch pha Chiến lược:** Cơ chế đảm bảo thu nhập (Income Guarantee) cũ tạo tâm lý ỷ lại. Tài xế không muốn đăng ký các khu vực xa hoặc khó khăn do thiếu lực đẩy về kinh tế.
*   **Điểm nghẽn Vận hành:** Mất cân bằng cung cầu vào Peak-hour tại các khu vực trung tâm do thiếu cơ chế điều phối ca động lực.

### 2.3. Phân Tích Dự Báo (Predictive Analysis - Dự Phóng Tương Lai)
*   Áp dụng hệ số AhaPoints nhân &times;1.5 (L2) và &times;1.3 (L3) sẽ dịch chuyển **tới 70%** lượng tài xế hoạt động tích cực tự nguyện đổ về khu vực trọng điểm.
*   Việc siết chặt giờ mở cổng đăng ký ca theo Rank (0-12h cho R1, 12-18h cho R2, 18-24h cho R3) sẽ thúc đẩy tỷ lệ duy trì Rank tăng **35%** để giành quyền chọn ca tốt nhất.

### 2.4. Phân Tích Đề Xuất (Prescriptive Analysis - Lộ Trình Tối Ưu)
Quy chuẩn hóa hệ thống thành bộ Slide Presentation 9 bước để thuyết phục C-level và các bộ phận vận hành (Operations, Product, BI):

---

## 3. KHUNG DẪN DẮT THUYẾT TRÌNH (SLIDE NARRATIVE FLOW)

*(Kịch bản thuyết trình chi tiết từng slide, kết nối mạch lạc từ nỗi đau đến giải pháp và lộ trình thực thi)*

### Slide 1: Bối Cảnh & Thách Thức (Nỗi đau hiện tại)
*   **Kịch bản thuyết trình:** "Thưa các anh chị, hệ thống Ranking cũ của chúng ta đã hoàn thành sứ mệnh lịch sử nhưng đang bộc lộ điểm yếu chết người: **Không phản ánh đúng chất lượng dịch vụ và thiếu sự phân hóa đặc quyền**. Tài xế cày đơn nhiều nhưng SLA kém vẫn được xếp hạng cao, trong khi các Rank không đem lại quyền lợi rõ ràng làm mất động lực phấn đấu của tài xế."

### Slide 2: 01. Tiêu Chí Xếp Hạng Mới (Chất lượng là vé vào cửa)
*   **Kịch bản thuyết trình:** "Để giải quyết vấn đề này, chúng ta đưa **DQS (Driver Quality Score)** vào lõi xét duyệt. R1 yêu cầu DQS &ge; 80, R2/R3 yêu cầu &ge; 75. Năng suất cuốc xe (Productivity) vẫn giữ vai trò điều kiện đủ. Chỉ những tài xế thực sự xuất sắc mới có thể thăng hạng."

### Slide 3: 02. Layer Access & Priority (Khung giờ mở cổng)
*   **Kịch bản thuyết trình:** "Tài xế Rank cao sẽ có đặc quyền gì? Đó là **Khung giờ đăng ký ca**. Chúng ta mở cổng đăng ký ca sớm nhất cho R1 Elite từ **00:00 - 12:00**, R2 Active từ **12:00 - 18:00**, R3 Standard từ **18:00 - 24:00**. Tài xế chưa xếp hạng phải chờ sang Ngày 2+ để nhận các slot thừa. R1 được ưu tiên chọn ca tốt nhất, zone tốt nhất."

### Slide 4: 03. Định Nghĩa Hệ Thống Layer (L1 - L6)
*   **Kịch bản thuyết trình:** "Vậy hệ thống Layer hoạt động ra sao? Chúng ta chia làm 6 Layer rõ rệt để tối ưu hóa nguồn cung:
    *   **L1 KA/MP:** Phục vụ khách hàng lớn và sàn TMĐT, gán trực tiếp (Assigned), không qua đăng ký ca.
    *   **L2 Minizone:** Bán kính ngắn &le;4km, mật độ đơn và tỷ lệ ghép đơn cực cao, ưu tiên cho R1 Elite.
    *   **L3 Mediumzone:** Bán kính trung bình &le;8km, cân bằng cự ly, ưu tiên cho R2 Active.
    *   **L4 Bigzone:** Vùng Quận/Huyện diện rộng, cự ly dài hơn, ưu tiên cho R3 Standard.
    *   **L5 Cityzone:** Vùng hoạt động tự do toàn thành phố cho mọi Rank.
    *   **L6 MASS:** Chế độ On-demand tự do cho tài xế chưa xếp hạng hoặc trễ ca."

### Slide 5: 04. Quyền lợi Rank & AhaBenefits (Hệ thống phúc lợi đặc quyền)
*   **Kịch bản thuyết trình:** "Bên cạnh thời gian đăng ký ca, chúng ta thiết lập hệ sinh thái AhaBenefits để thay thế dần các gói đảm bảo thu nhập cũ. 
    *   **Về Rank:** R1 được tặng Voucher xăng/sạc 50k/tháng và đặc quyền bảo hiểm tai nạn; R2 nhận voucher 30k/tháng.
    *   **Về Layer:** Tích điểm AhaPoints theo công thức tinh gọn: `earned_pts = round(round(trip_GSV / 1.000) * layer_multiplier)`. L2 nhân **&times;1.5**, L3 nhân **&times;1.3**, L4 nhân **&times;1.1**. Minizone (L2) và Mediumzone (L3) có thêm sự hỗ trợ trực tiếp từ Đội trưởng. L4/L5 hoàn toàn tự quản (Không có Đội trưởng)."

### Slide 6: 05. Hệ Sinh Thái Vòng Lặp (Lực tự vận động)
*   **Kịch bản thuyết trình:** "Bốn yếu tố trên tạo thành một vòng lặp khép kín: Tài xế muốn hưởng hệ số điểm thưởng nhân &times;1.5 hấp dẫn của L2 &rarr; buộc phải đăng ký Layer L2 &rarr; số lượng slot L2 có hạn nên phải tranh nhau đăng ký sớm &rarr; muốn được đăng ký sớm ở khung giờ 00:00 - 12:00 thì phải đạt Rank R1 &rarr; muốn đạt Rank R1 thì bắt buộc phải duy trì DQS & Năng suất xuất sắc. Hệ thống tự vận hành mà không cần thúc ép thủ công."

### Slide 7: 06. Bảng Tổng Hợp (Dữ liệu quy chuẩn)
*   **Kịch bản thuyết trình:** "Đây là bảng so sánh trực quan toàn bộ các tham số đã được đồng bộ hóa. Từ điều kiện xét duyệt, khung giờ mở cổng đăng ký ca, hệ số nhân điểm AhaPoints của từng Layer, đến quyền lợi bảo hiểm và công cụ dụng cụ hỗ trợ."

### Slide 8: 07. Timeline Triển Khai (Lộ trình 3 giai đoạn từ giữa tháng 7)
*   **Kịch bản thuyết trình:** "Lộ trình triển khai dự án sẽ trải qua 3 giai đoạn:
    *   **Giai đoạn 1 (Giữa tháng 7/2026):** Hoàn thiện kỹ thuật, áp dụng DQS, truyền thông đào tạo tài xế và xây dựng song song cơ chế ưu tiên đăng ký của AhaBenefits.
    *   **Giai đoạn 2 (Tháng 8/2026):** Chạy thử nghiệm Shadow Mode (chạy ngầm đo DQS nhưng chưa khóa đăng ký) tại HAN trước, sau đó mở rộng vào SGN.
    *   **Giai đoạn 3 (Tháng 9/2026):** Triển khai chính thức toàn diện, đồng bộ hóa toàn bộ hệ sinh thái AhaBenefits và áp dụng chế độ lọc Rank cứng."

### Slide 9: 08. Bản Đồ Hiện Thực Hóa Giá Trị (Business Impact)
*   **Kịch bản thuyết trình:** "Cuối cùng là tác động thực tế của dự án đối với P&L và SLA. Bằng cách tiêu chuẩn hóa DQS, phân quyền mở cổng đăng ký sớm và dùng hệ số AhaPoints làm mồi nhử, chúng ta chuyển đổi từ trạng thái thụ động ép vùng sang trạng thái tài xế tự nguyện điều phối, tối ưu hóa triệt để chi phí vận hành vận tải."

---

## 4. 📈 HIỆN THỰC HÓA GIÁ TRỊ (VALUE REALIZATION)

| Hiện trạng (Current State) | Chuyển đổi (Transformation) | Trạng thái Mục tiêu (Target State) | Tác động kinh doanh (Measurable Impact) |
| :--- | :--- | :--- | :--- |
| Quy trình tính thưởng ca thủ công trên Excel, rủi ro sai sót cao. | ↓ **TỰ ĐỘNG HÓA SQL & APP** ↓ | Điểm AhaPoints tính tự động theo ca đăng ký thực tế trên App. | ***Giảm 90% công sức vận hành của Ops team, triệt tiêu rủi ro gian lận điểm thưởng.*** |
| Thiếu hụt tài xế cục bộ vào khung giờ cao điểm peak-hour. | ↓ **ĐIỀU PHỐI CUNG TỰ NGUYỆN** ↓ | Áp dụng hệ số nhân điểm AhaPoints đặc quyền (&times;1.5 cho L2, &times;1.3 cho L3) để tạo lực hút cung. | ***Tăng 35% Fulfillment rate tại các zone trọng yếu; giảm 15% tỷ lệ rơi rớt đơn (SLA drop).*** |
| Quyền lợi các Rank mờ nhạt, tài xế không có mục tiêu phấn đấu. | ↓ **PHÂN CẤP KHUNG GIỜ MỞ ĐĂNG KÝ CA** ↓ | Khóa cứng giờ mở cổng theo Rank (R1: 0-12h, R2: 12-18h, R3: 18-24h). | ***Tăng 40% tỷ lệ duy trì chất lượng dịch vụ (DQS &ge; 75/80) của tài xế tích cực.*** |
| Chi phí đảm bảo thu nhập cố định tăng cao gây áp lực lên P&L. | ↓ **CHUYỂN DỊCH PHÚC LỢI PHI TIỀN MẶT** ↓ | Chuyển sang đổi điểm lấy voucher xăng, sạc điện, data, bảo hiểm do đối tác tài trợ. | ***Tối ưu hóa 25% ngân sách incentive, giảm chi phí CPO (Cost per Order) thực tế.*** |
