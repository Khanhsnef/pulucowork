# 🧠 PHÂN TÍCH CHIẾN LƯỢC: `rohitg00/agentmemory`

> **Persistent Memory Layer cho AI Coding Agents** · ⭐ 22.5k Stars · 🍴 1.9k Forks · Apache-2.0

---

## 📊 Executive Summary

**agentmemory** là một open-source persistent memory layer được thiết kế để giải quyết bài toán cốt lõi của mọi AI coding agent: **mất ngữ cảnh giữa các session**. Thay vì re-explain kiến trúc mỗi lần bắt đầu chat, agent "nhớ" toàn bộ lịch sử làm việc và tự inject context phù hợp vào session mới.

**Verdict nhanh:** Đây là một trong những dự án open-source **kỹ thuật solid nhất** trong hệ sinh thái AI agent hiện tại — kiến trúc lai (hybrid search), pipeline đa tầng, và hệ sinh thái tích hợp rộng. Tuy nhiên, có một số **red flags về tính minh bạch benchmark** cần lưu ý.

---

## 🎯 Mục tiêu Kinh doanh & Bài toán Giải quyết

### Vấn đề cốt lõi (Problem Statement)

```
Session 1: "Build JWT auth for the API"  
→ Agent writes code, runs tests, fixes bugs  
→ Session ENDS → ALL CONTEXT LOST  

Session 2: "Now add rate limiting"  
→ Developer phải re-explain: "auth uses jose library,  
   middleware in src/middleware/auth.ts, tests in test/auth.test.ts..."  
→ Waste 5-15 phút đầu mỗi session
```

### Giải pháp

| Hiện trạng | Chuyển đổi | Trạng thái Mục tiêu |
|:---|:---|:---|
| Mất context sau mỗi session | ↓ Auto-capture & compress ↓ | Agent biết toàn bộ history project |
| Re-explain thủ công | ↓ Semantic search + inject ↓ | Context inject tự động khi start session |
| Giới hạn 200 dòng CLAUDE.md | ↓ Searchable database ↓ | Unlimited searchable memory |

---

## 🔬 KHUNG PHÂN TÍCH KỸ THUẬT

### 1. Kiến Trúc Tổng Quan

```
┌─────────────────────────────────────────────────────────┐
│                    AGENT (Claude, Cursor, Copilot...)    │
├──────────────┬──────────────┬──────────────────────────┤
│  Hook Layer  │  MCP Server  │    REST API (:3111)       │
│  (12 hooks)  │  (53 tools)  │    + WebSocket            │
├──────────────┴──────────────┴──────────────────────────┤
│                  agentmemory Core (Node.js/TypeScript)   │
├─────────────┬────────────────┬──────────────────────────┤
│  Memory     │  LLM Compress  │   Knowledge Graph        │
│  Pipeline   │  (structured   │   Extraction             │
│             │  facts/concepts│   (optional)             │
├─────────────┴────────────────┴──────────────────────────┤
│                    iii Engine (Rust binary)               │
│         BM25 + Vector + Graph — Hybrid Search            │
├─────────────────────────────────────────────────────────┤
│       Storage: Local FS / Docker / Cloud Deploy          │
└─────────────────────────────────────────────────────────┘
```

### 2. Memory Pipeline (Chi tiết)

**Capture Phase** (PostToolUse hook):
1. `SHA-256 dedup` — bỏ duplicate trong 5 phút
2. `Privacy filter` — strip secrets/API keys
3. `Store raw observation` → disk
4. `LLM compress` → structured facts + concepts + narrative
5. `Vector embedding` (6 providers + local `all-MiniLM-L6-v2`)
6. `Index` trong **BM25 + Vector** dual index

**Session End** (Stop/SessionEnd hook):
1. Summarize session
2. Knowledge graph extraction (nếu `GRAPH_EXTRACTION_ENABLED=true`)
3. Slot reflection (nếu `SLOT_REFLECT_ENABLED=true`)

**Retrieval Phase** (SessionStart hook):
1. Load project profile (top concepts, files, patterns)
2. **Hybrid search**: BM25 + Vector + Graph
3. **RRF fusion** (k=60) + session diversity (max 3 results/session)
4. Token budget enforcement (default: 2000 tokens)
5. Auto-inject vào conversation

### 3. Retrieval Strategy — Đánh giá Kỹ thuật

| Signal | Algorithm | Strength |
|:---|:---|:---|
| Keyword matching | BM25 (multilingual) | Exact term, code symbols |
| Semantic similarity | Vector (MiniLM-L6-v2) | Concept-level ("database performance" → finds "N+1 fix") |
| Contextual graph | Knowledge graph (optional) | Relationship traversal |
| Fusion | RRF k=60 | Balances all 3 signals |

> **Nhận xét:** Đây là state-of-the-art retrieval architecture. Hybrid BM25 + Vector với RRF là pattern được validate bởi BEIR benchmark và nhiều production RAG systems. **Technically sound.**

### 4. 4-Tier Memory Consolidation

Inspired bởi **Ebbinghaus Forgetting Curve**:
- Memories decay theo thời gian
- Frequently accessed → strengthen
- Stale memories → auto-evict
- Contradictions → detected & resolved

> **Nhận xét:** Đây là differentiator thực sự so với các tool đơn giản. Lifecycle memory management giống cách não người consolidate memory trong giấc ngủ.

---

## 🏆 Competitive Landscape

### agentmemory vs Competitors

| Tool | R@5 Score | Dataset | Notes |
|:---|:---|:---|:---|
| **agentmemory** | *Measured (hybrid)* | LongMemEval-S (500Q) | Reproducible |
| mem0 | Published LoCoMo | LoCoMo (different dataset) | Not head-to-head |
| Letta | Published LoCoMo | LoCoMo (different dataset) | Not head-to-head |
| supermemory | Vendor self-reported | Unknown | Not verified |

> ⚠️ **Critical note từ chính README:** *"The mem0 and Letta figures are their published LoCoMo numbers (a different dataset); the MemPalace, supermemory, and oracleagentmemory figures are vendor self-reported claims we have not independently reproduced."*
>
> **→ Benchmark comparison không phải apple-to-apple.** Claim "#1" chỉ có giá trị trong phạm vi LongMemEval-S với retrieval R@5 metric cụ thể.

### vs Built-in Agent Memory

```
CLAUDE.md / .cursorrules / notepads = Sticky notes (200 dòng, manual)
agentmemory                          = Searchable database (unlimited, automatic)
```

agentmemory **không cạnh tranh** với built-in memory — nó **bổ sung** bằng cách làm backend cho sticky notes.

---

## ✅ Điểm Mạnh (Strengths)

### 🔧 Kỹ Thuật
1. **Hybrid search architecture** (BM25 + Vector + Graph) — industry best practice
2. **53 MCP tools** — coverage rộng nhất trong category này
3. **Multi-provider embedding** — local (free, no API key) đến cloud (OpenAI, Voyage, Cohere)
4. **Privacy-first** — SHA-256 dedup + secret stripping built-in
5. **iii Engine (Rust)** — performant native binary thay vì pure JS

### 🌐 Ecosystem
6. **20+ agent integrations** — Claude Code, Cursor, Copilot CLI, Gemini CLI, Codex, Cline, Continue, Zed, Warp, OpenCode, Goose...
7. **15 Skills** (action + reference) — auto-teaches agents khi nào dùng tools
8. **Session Replay** — scrub timeline với play/pause, tool calls visible
9. **One-command deploy** — Fly, Railway, Render, Coolify
10. **Real-time Viewer** (`:3113`) — live memory build visualization

### 📚 Documentation & Community
11. **12 language READMEs** — internationalization tốt
12. **138 open issues + 150 PRs** — community active
13. **Benchmark reproducibility** — `eval/` folder với harness public
14. **Transparent limitations** — README thẳng thắn về benchmark caveats

---

## ⚠️ Điểm Yếu & Rủi ro (Weaknesses & Risks)

### 🔴 Critical Issues
1. **Dependency on `iii-engine` (Rust binary)** — external dependency không phổ biến, pinned tại `v0.11.2` (có breaking change ở v0.11.6). *Nếu `iii-hq/iii` abandoned hoặc thay đổi API → agentmemory bị ảnh hưởng nghiêm trọng.*
2. **"#1" claim misleading** — benchmark không phải apple-to-apple với competitors. Marketing aggressive hơn data thực sự.
3. **Codex Desktop hooks silent** ([issue #16430](https://github.com/openai/codex/issues/16430)) — hooks không dispatch trong Codex Desktop, chỉ MCP tools hoạt động.

### 🟡 Medium Risks
4. **Windows support incomplete** — `agentmemory connect` unsupported trên native Windows (chỉ WSL2). Manual setup 10-20 phút.
5. **Two-terminal requirement** — phải chạy server riêng trước khi dùng agent. DX không seamless.
6. **LLM compression cost** — mỗi observation phải LLM compress → API cost nếu dùng cloud models.
7. **Token budget tĩnh** — mặc định 2000 tokens inject vào context. Với complex projects, có thể không đủ.
8. **Sandbox MCP clients** — Flatpak/Snap containers cần workaround thêm env vars.

### 🟢 Low/Acceptable Risks
9. **npx version caching** — dễ fix với `npx -y @agentmemory/agentmemory@latest`
10. **JSONL cleanup** — Claude Code default 30 ngày cleanupPeriodDays xóa transcripts

---

## 📈 Đánh giá Tổng Quan

| Dimension | Score | Nhận xét |
|:---|:---:|:---|
| **Kỹ thuật Architecture** | 9/10 | Hybrid search + RRF + lifecycle mgmt = best-in-class |
| **DX (Developer Experience)** | 7/10 | One-command setup ngon, nhưng 2 terminals annoying |
| **Ecosystem Coverage** | 9/10 | 20+ agents, 53 MCP tools, 15 skills |
| **Benchmark Transparency** | 6/10 | Honest về caveats nhưng "#1" claim aggressive |
| **Windows Support** | 4/10 | WSL2 workaround không ideal |
| **Dependency Risk** | 6/10 | iii-engine external dep + pinned version là risk |
| **Community Health** | 8/10 | 22.5k stars, active issues/PRs |
| **Documentation Quality** | 9/10 | Rất comprehensive, 12 ngôn ngữ |
| **OVERALL** | **7.5/10** | **Solid production-ready tool với known caveats** |

---

## 🎯 Khuyến Nghị Ứng Dụng

### Nên dùng nếu:
- ✅ Bạn dùng **Claude Code, Cursor, hoặc Codex CLI** (macOS/Linux) — integrations tốt nhất
- ✅ Project **long-running** (>1 tuần) với nhiều sessions
- ✅ Team cần **shared memory** giữa nhiều agent/developer
- ✅ Muốn **semantic search** qua lịch sử code decisions
- ✅ Đã có pipeline CI/CD và muốn thêm memory layer

### Cân nhắc nếu:
- ⚠️ Windows native (không có WSL2) → manual setup phức tạp
- ⚠️ Môi trường sandboxed (Docker containers, Flatpak) → cần workaround thêm
- ⚠️ Budget API cost nhạy cảm → dùng local embedding (all-MiniLM-L6-v2, miễn phí)
- ⚠️ Bạn rely heavily vào Codex Desktop → hooks không hoạt động

### Quick Start cho team:
```bash
# 1. Install globally
npm install -g @agentmemory/agentmemory

# 2. Start server (giữ terminal này mở)
agentmemory

# 3. Wire với agent (ví dụ: Claude Code)
agentmemory connect claude-code

# 4. Install skills để agent biết khi nào dùng
npx skills add rohitg00/agentmemory -y

# 5. Verify
curl http://localhost:3111/agentmemory/health

# 6. View realtime memory build
open http://localhost:3113
```

---

## 🔗 Tài Nguyên

| Resource | Link |
|:---|:---|
| Repository | https://github.com/rohitg00/agentmemory |
| Benchmark (LongMemEval) | `benchmark/LONGMEMEVAL.md` |
| Benchmark Comparison | `benchmark/COMPARISON.md` |
| Eval Harness | `eval/README.md` |
| Deploy Guides | `deploy/` (Fly, Railway, Render, Coolify) |
| Python Examples | `examples/python/` |

---

*Phân tích bởi Antigravity AI — 2026-06-12*
