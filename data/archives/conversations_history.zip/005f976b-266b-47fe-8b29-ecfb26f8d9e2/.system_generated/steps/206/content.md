Title: GitHub - chopratejas/headroom: Compress tool outputs, logs, files, and RAG chunks before they reach the LLM. 60-95% fewer tokens, same answers. Library, proxy, MCP server. · GitHub

Description: Compress tool outputs, logs, files, and RAG chunks before they reach the LLM. 60-95% fewer tokens, same answers. Library, proxy, MCP server. - chopratejas/headroom

Source: https://github.com/chopratejas/headroom

---

[Skip to content](https://github.com/chopratejas/headroom#start-of-content)

[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fchopratejas%2Fheadroom)
- PlatformAI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryNewIntegrate external tools](https://github.com/mcp)DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)[View all features](https://github.com/features)
- AI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
- APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
- SolutionsBY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[View all industries](https://github.com/solutions/industry)[View all solutions](https://github.com/solutions)

- BY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)
- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
- BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
- BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[View all industries](https://github.com/solutions/industry)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)
- ResourcesEXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)[View all resources](https://github.com/resources)
- EXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
- EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
- SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)

- Open SourceCOMMUNITY[GitHub SponsorsFund open source developers](https://github.com/sponsors)PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[Accelerator](https://github.com/accelerator)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- COMMUNITY[GitHub SponsorsFund open source developers](https://github.com/sponsors)
- [GitHub SponsorsFund open source developers](https://github.com/sponsors)
- PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[Accelerator](https://github.com/accelerator)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [Accelerator](https://github.com/accelerator)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
- REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
- EnterpriseENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- ENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [Pricing](https://github.com/pricing)
- AI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
- APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)

- EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryNewIntegrate external tools](https://github.com/mcp)
[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
[MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
[ActionsAutomate any workflow](https://github.com/features/actions)
[CodespacesInstant dev environments](https://github.com/features/codespaces)
[IssuesPlan and track work](https://github.com/features/issues)
[Code ReviewManage code changes](https://github.com/features/code-review)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
[Why GitHub](https://github.com/why-github)
[Documentation](https://docs.github.com)
[Blog](https://github.blog)
[Changelog](https://github.blog/changelog)
[Marketplace](https://github.com/marketplace)
[View all features](https://github.com/features)
- BY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)
- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
- BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
- BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[View all industries](https://github.com/solutions/industry)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)

- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
[Enterprises](https://github.com/enterprise)
[Small and medium teams](https://github.com/team)
[Startups](https://github.com/enterprise/startups)
[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
[App Modernization](https://github.com/solutions/use-case/app-modernization)
[DevSecOps](https://github.com/solutions/use-case/devsecops)
[DevOps](https://github.com/solutions/use-case/devops)
[CI/CD](https://github.com/solutions/use-case/ci-cd)
[View all use cases](https://github.com/solutions/use-case)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)
[Healthcare](https://github.com/solutions/industry/healthcare)
[Financial services](https://github.com/solutions/industry/financial-services)
[Manufacturing](https://github.com/solutions/industry/manufacturing)
[Government](https://github.com/solutions/industry/government)
[View all industries](https://github.com/solutions/industry)
[View all solutions](https://github.com/solutions)
- EXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
- EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
- SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
[AI](https://github.com/resources/articles?topic=ai)
[Software Development](https://github.com/resources/articles?topic=software-development)
[DevOps](https://github.com/resources/articles?topic=devops)
[Security](https://github.com/resources/articles?topic=security)
[View all topics](https://github.com/resources/articles)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
[Customer stories](https://github.com/customer-stories)

[Events & webinars](https://github.com/resources/events)
[Ebooks & reports](https://github.com/resources/whitepapers)
[Business insights](https://github.com/solutions/executive-insights)
[GitHub Skills](https://skills.github.com)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)
[Documentation](https://docs.github.com)
[Customer support](https://support.github.com)
[Community forum](https://github.com/orgs/community/discussions)
[Trust center](https://github.com/trust-center)
[Partners](https://github.com/partners)
[View all resources](https://github.com/resources)
- COMMUNITY[GitHub SponsorsFund open source developers](https://github.com/sponsors)
- [GitHub SponsorsFund open source developers](https://github.com/sponsors)
- PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[Accelerator](https://github.com/accelerator)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [Accelerator](https://github.com/accelerator)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
- REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
- [GitHub SponsorsFund open source developers](https://github.com/sponsors)
[GitHub SponsorsFund open source developers](https://github.com/sponsors)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [Accelerator](https://github.com/accelerator)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
[Security Lab](https://securitylab.github.com)
[Maintainer Community](https://maintainers.github.com)
[Accelerator](https://github.com/accelerator)
[GitHub Stars](https://stars.github.com)
[Archive Program](https://archiveprogram.github.com)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
[Topics](https://github.com/topics)
[Trending](https://github.com/trending)
[Collections](https://github.com/collections)
- ENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
[Pricing](https://github.com/pricing)

# Search code, repositories, users, issues, pull requests...
[Search syntax tips](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax)

# Provide feedback
We read every piece of feedback, and take your input very seriously.

To see all available qualifiers, see our [documentation](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax).
[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fchopratejas%2Fheadroom)
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=header+logged+out&ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E&source=header-repo&source_repo=chopratejas%2Fheadroom)
[Reload](https://github.com/chopratejas/headroom)
[Reload](https://github.com/chopratejas/headroom)
[Reload](https://github.com/chopratejas/headroom)
[chopratejas](https://github.com/chopratejas)
[headroom](https://github.com/chopratejas/headroom)
- 








              Uh oh!

              There was an error while loading. [Please reload this page](https://github.com/chopratejas/headroom).






- 
            [Notifications](https://github.com/login?return_to=%2Fchopratejas%2Fheadroom)    You must be signed in to change notification settings


- 
          [Fork
    1.5k](https://github.com/login?return_to=%2Fchopratejas%2Fheadroom)

- 

        [Star
          23.9k](https://github.com/login?return_to=%2Fchopratejas%2Fheadroom)

There was an error while loading. [Please reload this page](https://github.com/chopratejas/headroom).
[Notifications](https://github.com/login?return_to=%2Fchopratejas%2Fheadroom)
[Fork
    1.5k](https://github.com/login?return_to=%2Fchopratejas%2Fheadroom)
[Star
          23.9k](https://github.com/login?return_to=%2Fchopratejas%2Fheadroom)
- 
  [Code](https://github.com/chopratejas/headroom)
- 
  [Issues
          153](https://github.com/chopratejas/headroom/issues)
- 
  [Pull requests
          86](https://github.com/chopratejas/headroom/pulls)
- 
  [Discussions](https://github.com/chopratejas/headroom/discussions)
- 
  [Actions](https://github.com/chopratejas/headroom/actions)
- 
  [Projects](https://github.com/chopratejas/headroom/projects)
- 
  [Security and quality
          0](https://github.com/chopratejas/headroom/security)
- 
  [Insights](https://github.com/chopratejas/headroom/pulse)
[Code](https://github.com/chopratejas/headroom)
[Issues
          153](https://github.com/chopratejas/headroom/issues)
[Pull requests
          86](https://github.com/chopratejas/headroom/pulls)
[Discussions](https://github.com/chopratejas/headroom/discussions)
[Actions](https://github.com/chopratejas/headroom/actions)
[Projects](https://github.com/chopratejas/headroom/projects)
[Security and quality
          0](https://github.com/chopratejas/headroom/security)
[Insights](https://github.com/chopratejas/headroom/pulse)
- 


    [Code](https://github.com/chopratejas/headroom)


- 


    [Issues](https://github.com/chopratejas/headroom/issues)


- 


    [Pull requests](https://github.com/chopratejas/headroom/pulls)


- 


    [Discussions](https://github.com/chopratejas/headroom/discussions)


- 


    [Actions](https://github.com/chopratejas/headroom/actions)


- 


    [Projects](https://github.com/chopratejas/headroom/projects)


- 


    [Security and quality](https://github.com/chopratejas/headroom/security)


- 


    [Insights](https://github.com/chopratejas/headroom/pulse)


[Code](https://github.com/chopratejas/headroom)
[Issues](https://github.com/chopratejas/headroom/issues)
[Pull requests](https://github.com/chopratejas/headroom/pulls)
[Discussions](https://github.com/chopratejas/headroom/discussions)
[Actions](https://github.com/chopratejas/headroom/actions)
[Projects](https://github.com/chopratejas/headroom/projects)
[Security and quality](https://github.com/chopratejas/headroom/security)
[Insights](https://github.com/chopratejas/headroom/pulse)

[Branches](https://github.com/chopratejas/headroom/branches)
[Tags](https://github.com/chopratejas/headroom/tags)

[1,552 Commits](https://github.com/chopratejas/headroom/commits/main/)
[.claude-plugin](https://github.com/chopratejas/headroom/tree/main/.claude-plugin)
[.claude-plugin](https://github.com/chopratejas/headroom/tree/main/.claude-plugin)
[.devcontainer](https://github.com/chopratejas/headroom/tree/main/.devcontainer)
[.devcontainer](https://github.com/chopratejas/headroom/tree/main/.devcontainer)
[.github](https://github.com/chopratejas/headroom/tree/main/.github)
[.github](https://github.com/chopratejas/headroom/tree/main/.github)
[REALIGNMENT](https://github.com/chopratejas/headroom/tree/main/REALIGNMENT)
[REALIGNMENT](https://github.com/chopratejas/headroom/tree/main/REALIGNMENT)
[benchmarks](https://github.com/chopratejas/headroom/tree/main/benchmarks)
[benchmarks](https://github.com/chopratejas/headroom/tree/main/benchmarks)
[crates](https://github.com/chopratejas/headroom/tree/main/crates)
[crates](https://github.com/chopratejas/headroom/tree/main/crates)
[docker](https://github.com/chopratejas/headroom/tree/main/docker)
[docker](https://github.com/chopratejas/headroom/tree/main/docker)
[docs](https://github.com/chopratejas/headroom/tree/main/docs)
[docs](https://github.com/chopratejas/headroom/tree/main/docs)
[e2e](https://github.com/chopratejas/headroom/tree/main/e2e)
[e2e](https://github.com/chopratejas/headroom/tree/main/e2e)
[examples](https://github.com/chopratejas/headroom/tree/main/examples)
[examples](https://github.com/chopratejas/headroom/tree/main/examples)
[headroom](https://github.com/chopratejas/headroom/tree/main/headroom)
[headroom](https://github.com/chopratejas/headroom/tree/main/headroom)
[plugins](https://github.com/chopratejas/headroom/tree/main/plugins)
[plugins](https://github.com/chopratejas/headroom/tree/main/plugins)
[scripts](https://github.com/chopratejas/headroom/tree/main/scripts)
[scripts](https://github.com/chopratejas/headroom/tree/main/scripts)
[sdk/typescript](https://github.com/chopratejas/headroom/tree/main/sdk/typescript)
[sdk/typescript](https://github.com/chopratejas/headroom/tree/main/sdk/typescript)
[sql](https://github.com/chopratejas/headroom/tree/main/sql)
[sql](https://github.com/chopratejas/headroom/tree/main/sql)
[tests](https://github.com/chopratejas/headroom/tree/main/tests)
[tests](https://github.com/chopratejas/headroom/tree/main/tests)
[wiki](https://github.com/chopratejas/headroom/tree/main/wiki)
[wiki](https://github.com/chopratejas/headroom/tree/main/wiki)
[.actrc](https://github.com/chopratejas/headroom/blob/main/.actrc)
[.actrc](https://github.com/chopratejas/headroom/blob/main/.actrc)
[.actrc.local.example](https://github.com/chopratejas/headroom/blob/main/.actrc.local.example)
[.actrc.local.example](https://github.com/chopratejas/headroom/blob/main/.actrc.local.example)
[.changelog.md](https://github.com/chopratejas/headroom/blob/main/.changelog.md)
[.changelog.md](https://github.com/chopratejas/headroom/blob/main/.changelog.md)
[.commitlintrc.json](https://github.com/chopratejas/headroom/blob/main/.commitlintrc.json)
[.commitlintrc.json](https://github.com/chopratejas/headroom/blob/main/.commitlintrc.json)
[.dockerignore](https://github.com/chopratejas/headroom/blob/main/.dockerignore)
[.dockerignore](https://github.com/chopratejas/headroom/blob/main/.dockerignore)
[.env.act.example](https://github.com/chopratejas/headroom/blob/main/.env.act.example)
[.env.act.example](https://github.com/chopratejas/headroom/blob/main/.env.act.example)
[.env.example](https://github.com/chopratejas/headroom/blob/main/.env.example)
[.env.example](https://github.com/chopratejas/headroom/blob/main/.env.example)
[.git-blame-ignore-revs](https://github.com/chopratejas/headroom/blob/main/.git-blame-ignore-revs)
[.git-blame-ignore-revs](https://github.com/chopratejas/headroom/blob/main/.git-blame-ignore-revs)
[.gitattributes](https://github.com/chopratejas/headroom/blob/main/.gitattributes)
[.gitattributes](https://github.com/chopratejas/headroom/blob/main/.gitattributes)
[.gitguardian.yaml](https://github.com/chopratejas/headroom/blob/main/.gitguardian.yaml)
[.gitguardian.yaml](https://github.com/chopratejas/headroom/blob/main/.gitguardian.yaml)
[.gitignore](https://github.com/chopratejas/headroom/blob/main/.gitignore)
[.gitignore](https://github.com/chopratejas/headroom/blob/main/.gitignore)
[.pre-commit-config.yaml](https://github.com/chopratejas/headroom/blob/main/.pre-commit-config.yaml)

[.pre-commit-config.yaml](https://github.com/chopratejas/headroom/blob/main/.pre-commit-config.yaml)
[.release-please-config.json](https://github.com/chopratejas/headroom/blob/main/.release-please-config.json)
[.release-please-config.json](https://github.com/chopratejas/headroom/blob/main/.release-please-config.json)
[.release-please-manifest.json](https://github.com/chopratejas/headroom/blob/main/.release-please-manifest.json)
[.release-please-manifest.json](https://github.com/chopratejas/headroom/blob/main/.release-please-manifest.json)
[CHANGELOG.md](https://github.com/chopratejas/headroom/blob/main/CHANGELOG.md)
[CHANGELOG.md](https://github.com/chopratejas/headroom/blob/main/CHANGELOG.md)
[CODE_OF_CONDUCT.md](https://github.com/chopratejas/headroom/blob/main/CODE_OF_CONDUCT.md)
[CODE_OF_CONDUCT.md](https://github.com/chopratejas/headroom/blob/main/CODE_OF_CONDUCT.md)
[CONTRIBUTING.md](https://github.com/chopratejas/headroom/blob/main/CONTRIBUTING.md)
[CONTRIBUTING.md](https://github.com/chopratejas/headroom/blob/main/CONTRIBUTING.md)
[Cargo.lock](https://github.com/chopratejas/headroom/blob/main/Cargo.lock)
[Cargo.lock](https://github.com/chopratejas/headroom/blob/main/Cargo.lock)
[Cargo.toml](https://github.com/chopratejas/headroom/blob/main/Cargo.toml)
[Cargo.toml](https://github.com/chopratejas/headroom/blob/main/Cargo.toml)
[Dockerfile](https://github.com/chopratejas/headroom/blob/main/Dockerfile)
[Dockerfile](https://github.com/chopratejas/headroom/blob/main/Dockerfile)
[ENTERPRISE.md](https://github.com/chopratejas/headroom/blob/main/ENTERPRISE.md)
[ENTERPRISE.md](https://github.com/chopratejas/headroom/blob/main/ENTERPRISE.md)
[Headroom-2.gif](https://github.com/chopratejas/headroom/blob/main/Headroom-2.gif)
[Headroom-2.gif](https://github.com/chopratejas/headroom/blob/main/Headroom-2.gif)
[HeadroomDemo-Fast.gif](https://github.com/chopratejas/headroom/blob/main/HeadroomDemo-Fast.gif)
[HeadroomDemo-Fast.gif](https://github.com/chopratejas/headroom/blob/main/HeadroomDemo-Fast.gif)
[LICENSE](https://github.com/chopratejas/headroom/blob/main/LICENSE)
[LICENSE](https://github.com/chopratejas/headroom/blob/main/LICENSE)
[Makefile](https://github.com/chopratejas/headroom/blob/main/Makefile)
[Makefile](https://github.com/chopratejas/headroom/blob/main/Makefile)
[NOTICE](https://github.com/chopratejas/headroom/blob/main/NOTICE)
[NOTICE](https://github.com/chopratejas/headroom/blob/main/NOTICE)
[PR.md](https://github.com/chopratejas/headroom/blob/main/PR.md)
[PR.md](https://github.com/chopratejas/headroom/blob/main/PR.md)
[README.md](https://github.com/chopratejas/headroom/blob/main/README.md)
[README.md](https://github.com/chopratejas/headroom/blob/main/README.md)
[RUST_DEV.md](https://github.com/chopratejas/headroom/blob/main/RUST_DEV.md)
[RUST_DEV.md](https://github.com/chopratejas/headroom/blob/main/RUST_DEV.md)
[SECURITY.md](https://github.com/chopratejas/headroom/blob/main/SECURITY.md)
[SECURITY.md](https://github.com/chopratejas/headroom/blob/main/SECURITY.md)
[TESTING-copilot-subscription.md](https://github.com/chopratejas/headroom/blob/main/TESTING-copilot-subscription.md)
[TESTING-copilot-subscription.md](https://github.com/chopratejas/headroom/blob/main/TESTING-copilot-subscription.md)
[claude_analysis_ttl.py](https://github.com/chopratejas/headroom/blob/main/claude_analysis_ttl.py)
[claude_analysis_ttl.py](https://github.com/chopratejas/headroom/blob/main/claude_analysis_ttl.py)
[codecov.yml](https://github.com/chopratejas/headroom/blob/main/codecov.yml)
[codecov.yml](https://github.com/chopratejas/headroom/blob/main/codecov.yml)
[deny.toml](https://github.com/chopratejas/headroom/blob/main/deny.toml)
[deny.toml](https://github.com/chopratejas/headroom/blob/main/deny.toml)
[docker-bake.hcl](https://github.com/chopratejas/headroom/blob/main/docker-bake.hcl)
[docker-bake.hcl](https://github.com/chopratejas/headroom/blob/main/docker-bake.hcl)
[docker-compose.yml](https://github.com/chopratejas/headroom/blob/main/docker-compose.yml)
[docker-compose.yml](https://github.com/chopratejas/headroom/blob/main/docker-compose.yml)
[headroom-savings.png](https://github.com/chopratejas/headroom/blob/main/headroom-savings.png)
[headroom-savings.png](https://github.com/chopratejas/headroom/blob/main/headroom-savings.png)
[headroom_learn.gif](https://github.com/chopratejas/headroom/blob/main/headroom_learn.gif)
[headroom_learn.gif](https://github.com/chopratejas/headroom/blob/main/headroom_learn.gif)

## History
[llms.txt](https://github.com/chopratejas/headroom/blob/main/llms.txt)
[llms.txt](https://github.com/chopratejas/headroom/blob/main/llms.txt)
[mkdocs.yml](https://github.com/chopratejas/headroom/blob/main/mkdocs.yml)
[mkdocs.yml](https://github.com/chopratejas/headroom/blob/main/mkdocs.yml)
[pyproject.toml](https://github.com/chopratejas/headroom/blob/main/pyproject.toml)
[pyproject.toml](https://github.com/chopratejas/headroom/blob/main/pyproject.toml)
[rust-toolchain.toml](https://github.com/chopratejas/headroom/blob/main/rust-toolchain.toml)
[rust-toolchain.toml](https://github.com/chopratejas/headroom/blob/main/rust-toolchain.toml)
[uv.lock](https://github.com/chopratejas/headroom/blob/main/uv.lock)
[uv.lock](https://github.com/chopratejas/headroom/blob/main/uv.lock)

## Repository files navigation
- [README](https://github.com/chopratejas/headroom)
- [Code of conduct](https://github.com/chopratejas/headroom)
- [Contributing](https://github.com/chopratejas/headroom)
- [Apache-2.0 license](https://github.com/chopratejas/headroom)
- [Security](https://github.com/chopratejas/headroom)
[README](https://github.com/chopratejas/headroom)
[Code of conduct](https://github.com/chopratejas/headroom)
[Contributing](https://github.com/chopratejas/headroom)
[Apache-2.0 license](https://github.com/chopratejas/headroom)
[Security](https://github.com/chopratejas/headroom)

```
██╗ ██╗███████╗ █████╗ ██████╗ ██████╗ ██████╗ ██████╗ ███╗ ███╗ ██║ ██║██╔════╝██╔══██╗██╔══██╗██╔══██╗██╔═══██╗██╔═══██╗████╗ ████║ ███████║█████╗ ███████║██║ ██║██████╔╝██║ ██║██║ ██║██╔████╔██║ ██╔══██║██╔══╝ ██╔══██║██║ ██║██╔══██╗██║ ██║██║ ██║██║╚██╔╝██║ ██║ ██║███████╗██║ ██║██████╔╝██║ ██║╚██████╔╝╚██████╔╝██║ ╚═╝ ██║ ╚═╝ ╚═╝╚══════╝╚═╝ ╚═╝╚═════╝ ╚═╝ ╚═╝ ╚═════╝ ╚═════╝ ╚═╝ ╚═╝ The context compression layer for AI agents
```

60–95% fewer tokens · library · proxy · MCP · 6 algorithms · local-first · reversible
[Docs](https://headroom-docs.vercel.app/docs) · [Install](https://github.com/chopratejas/headroom#get-started-60-seconds) · [Proof](https://github.com/chopratejas/headroom#proof) · [Agents](https://github.com/chopratejas/headroom#agent-compatibility-matrix) · [Discord](https://discord.gg/yRmaUNpsPJ) · [llms.txt](https://github.com/chopratejas/headroom/blob/main/llms.txt) · [Enterprise](https://github.com/chopratejas/headroom/blob/main/ENTERPRISE.md)
AI agents / LLMs: read [/llms.txt](https://github.com/chopratejas/headroom/blob/main/llms.txt) here, or fetch [the live index](https://headroom-docs.vercel.app/llms.txt) / [full docs blob](https://headroom-docs.vercel.app/llms-full.txt).

```
/llms.txt
```

Headroom compresses everything your AI agent reads — tool outputs, logs, RAG chunks, files, and conversation history — before it reaches the LLM. Same answers, fraction of the tokens.
https://github.com/chopratejas/headroom/blob/main/HeadroomDemo-Fast.gif Live: 10,144 → 1,260 tokens — same FATAL found.

## What it does
- Library — compress(messages) in Python or TypeScript, inline in any app
- Proxy — headroom proxy --port 8787, zero code changes, any language
- Agent wrap — headroom wrap claude|codex|cursor|aider|copilot in one command
- MCP server — headroom_compress, headroom_retrieve, headroom_stats for any MCP client
- Cross-agent memory — shared store across Claude, Codex, Gemini, auto-dedup
- headroom learn — mines failed sessions, writes corrections to CLAUDE.md / AGENTS.md
- Reversible (CCR) — originals are cached for retrieval on demand

```
compress(messages)
```


```
headroom proxy --port 8787
```


```
headroom wrap claude|codex|cursor|aider|copilot
```


```
headroom_compress
```


```
headroom_retrieve
```


```
headroom_stats
```


```
headroom learn
```


```
CLAUDE.md
```


```
AGENTS.md
```

## How it works (30 seconds)
```
Your agent / app (Claude Code, Cursor, Codex, LangChain, Agno, Strands, your own code…) │ prompts · tool outputs · logs · RAG results · files ▼ ┌────────────────────────────────────────────────────┐ │ Headroom (runs locally — your data stays here) │ │ ──────────────────────────────────────────────── │ │ CacheAligner → ContentRouter → CCR │ │ ├─ SmartCrusher (JSON) │ │ ├─ CodeCompressor (AST) │ │ └─ Kompress-base (text, HF) │ │ │ │ Cross-agent memory · headroom learn · MCP │ └────────────────────────────────────────────────────┘ │ compressed prompt + retrieval tool ▼ LLM provider (Anthropic · OpenAI · Bedrock · …)
```


```
Your agent / app (Claude Code, Cursor, Codex, LangChain, Agno, Strands, your own code…) │ prompts · tool outputs · logs · RAG results · files ▼ ┌────────────────────────────────────────────────────┐ │ Headroom (runs locally — your data stays here) │ │ ──────────────────────────────────────────────── │ │ CacheAligner → ContentRouter → CCR │ │ ├─ SmartCrusher (JSON) │ │ ├─ CodeCompressor (AST) │ │ └─ Kompress-base (text, HF) │ │ │ │ Cross-agent memory · headroom learn · MCP │ └────────────────────────────────────────────────────┘ │ compressed prompt + retrieval tool ▼ LLM provider (Anthropic · OpenAI · Bedrock · …)
```

- ContentRouter — detects content type, selects the right compressor
- SmartCrusher / CodeCompressor / Kompress-base — compress JSON, AST, or prose
- CacheAligner — stabilizes prefixes so provider KV caches actually hit
- CCR — stores originals locally; LLM calls headroom_retrieve if it needs them

```
headroom_retrieve
```

→ [Architecture](https://headroom-docs.vercel.app/docs/architecture) · [CCR reversible compression](https://headroom-docs.vercel.app/docs/ccr) · [Kompress-v2-base model card](https://huggingface.co/chopratejas/kompress-v2-base)

## Get started (60 seconds)
```
# 1 — Install pip install "headroom-ai[all]" # Python npm install headroom-ai # Node / TypeScript # 2 — Pick your mode headroom wrap claude # wrap a coding agent headroom proxy --port 8787 # drop-in proxy, zero code changes # or: from headroom import compress # inline library # 3 — See the savings headroom perf
```

Granular extras: [proxy], [mcp], [ml], [code], [memory], [relevance], [image], [agno], [langchain], [evals], [pytorch-mps] (Apple-GPU memory-embedder offload — set HEADROOM_EMBEDDER_RUNTIME=pytorch_mps). Requires Python 3.10+.

```
[proxy]
```


```
[mcp]
```


```
[ml]
```


```
[code]
```


```
[memory]
```


```
[relevance]
```


```
[image]
```


```
[agno]
```


```
[langchain]
```


```
[evals]
```


```
[pytorch-mps]
```


```
HEADROOM_EMBEDDER_RUNTIME=pytorch_mps
```

## Proof
Savings on real agent workloads:
Accuracy preserved on standard benchmarks:
Reproduce: python -m headroom.evals suite --tier 1 · [Full benchmarks & methodology](https://headroom-docs.vercel.app/docs/benchmarks)

```
python -m headroom.evals suite --tier 1
```

## Agent compatibility matrix
```
headroom wrap
```


```
--memory
```


```
--code-graph
```

Any OpenAI-compatible client works via headroom proxy. MCP-native: headroom mcp install.

```
headroom proxy
```


```
headroom mcp install
```

Headroom can route GitHub Copilot CLI subscription traffic through the local proxy:

```
headroom wrap copilot --subscription -- --model gpt-4o
```

This lets Headroom intercept OpenAI-compatible Copilot CLI requests and apply the same proxy compression pipeline before forwarding to GitHub Copilot's hosted API. The wrapper resolves the account-specific Copilot API endpoint and prints it as COPILOT_PROVIDER_API_URL=... during launch.

```
COPILOT_PROVIDER_API_URL=...
```

Platform support note: macOS auth reuse via Copilot CLI Keychain storage has been smoke-tested. Windows Credential Manager, Linux Secret Service / secret-tool, and Docker/CI token-injection paths are implemented or planned as auth-discovery paths, but still need real OS validation before they should be considered fully vetted. For Docker and CI, prefer passing an explicit GITHUB_COPILOT_TOKEN or GITHUB_COPILOT_GITHUB_TOKEN rather than relying on host keychain access.

```
secret-tool
```


```
GITHUB_COPILOT_TOKEN
```


```
GITHUB_COPILOT_GITHUB_TOKEN
```

## When to use · When to skip
Great fit if you…
- run AI coding agents daily and want savings without changing your code
- work across multiple agents and want shared memory
- need reversible compression — originals are retrievable via CCR within the configured TTL
Skip it if you…
- only use a single provider's native compaction and don't need cross-agent memory
- work in a sandboxed environment where local processes can't run

```
compress(messages, model=…)
```


```
await compress(messages, { model })
```


```
withHeadroom(new Anthropic())
```


```
withHeadroom(new OpenAI())
```


```
wrapLanguageModel({ model, middleware: headroomMiddleware() })
```


```
litellm.callbacks = [HeadroomCallback()]
```


```
HeadroomChatModel(your_llm)
```


```
HeadroomAgnoModel(your_model)
```

[Strands guide](https://headroom-docs.vercel.app/docs/strands)

```
app.add_middleware(CompressionMiddleware)
```


```
SharedContext().put / .get
```


```
headroom mcp install
```

- SmartCrusher — universal JSON: arrays of dicts, nested objects, mixed types.
- CodeCompressor — AST-aware for Python, JS, Go, Rust, Java, C++.
- Kompress-base — our HuggingFace model, trained on agentic traces.
- Image compression — 40–90% reduction via trained ML router.
- CacheAligner — stabilizes prefixes so Anthropic/OpenAI KV caches actually hit.
- IntelligentContext — score-based context fitting with learned importance.
- CCR — reversible compression; LLM retrieves originals on demand.
- Cross-agent memory — shared store, agent provenance, auto-dedup.
- SharedContext — compressed context passing across multi-agent workflows.
- headroom learn — plugin-based failure mining for Claude, Codex, Gemini.

```
headroom learn
```

Headroom exposes one stable request lifecycle across compress(), the SDK, and the proxy:

```
compress()
```

Setup → Pre-Start → Post-Start → Input Received → Input Cached → Input Routed → Input Compressed → Input Remembered → Pre-Send → Post-Send → Response Received

```
Setup
```


```
Pre-Start
```


```
Post-Start
```


```
Input Received
```


```
Input Cached
```


```
Input Routed
```


```
Input Compressed
```


```
Input Remembered
```


```
Pre-Send
```


```
Post-Send
```


```
Response Received
```

- Transforms do the work: CacheAligner, ContentRouter, SmartCrusher, CodeCompressor, Kompress-base, IntelligentContext / RollingWindow.
- Pipeline extensions observe or customize lifecycle stages via on_pipeline_event(...).
- Compression hooks sit alongside the canonical lifecycle as an additional extension seam.
- Proxy extensions remain the server/app integration seam for ASGI middleware, routes, and startup policy.

```
on_pipeline_event(...)
```

Provider and tool-specific behavior lives under headroom/providers/ so core orchestration stays focused on lifecycle, sequencing, and policy.

```
headroom/providers/
```

- CLI/tool slices: headroom/providers/claude, copilot, codex, openclaw
- Provider runtime slices: headroom/providers/claude, gemini, plus shared backend/runtime dispatch in headroom/providers/registry.py
- Core files stay orchestration-first: wrap.py, client.py, cli/proxy.py, and proxy/server.py delegate provider-specific env shaping, API target normalization, backend selection, and transport dispatch.

```
headroom/providers/claude
```


```
copilot
```


```
codex
```


```
openclaw
```


```
headroom/providers/claude
```


```
gemini
```


```
headroom/providers/registry.py
```


```
wrap.py
```


```
client.py
```


```
cli/proxy.py
```


```
proxy/server.py
```

## Install
```
pip install "headroom-ai[all]" # Python, everything npm install headroom-ai # TypeScript / Node docker pull ghcr.io/chopratejas/headroom:latest
```

Granular extras: [proxy], [mcp], [ml] (Kompress-base), [code], [memory], [relevance], [image], [agno], [langchain], [evals], [pytorch-mps] (Apple-GPU memory-embedder offload — set HEADROOM_EMBEDDER_RUNTIME=pytorch_mps). Requires Python 3.10+.

```
[proxy]
```


```
[mcp]
```


```
[ml]
```


```
[code]
```


```
[memory]
```


```
[relevance]
```


```
[image]
```


```
[agno]
```


```
[langchain]
```


```
[evals]
```


```
[pytorch-mps]
```


```
HEADROOM_EMBEDDER_RUNTIME=pytorch_mps
```

Using pipx? Choose a supported interpreter explicitly:

```
pipx
```


```
pipx install --python python3.13 "headroom-ai[all]"
```

→ [Installation guide](https://headroom-docs.vercel.app/docs/installation) — Docker tags, persistent service, PowerShell, devcontainers.

If pip install "headroom-ai[all]" fails with CERTIFICATE_VERIFY_FAILED (unable to get local issuer certificate), your network uses SSL inspection — a MITM proxy presenting a company-issued CA. The build backend (maturin) downloads rustup over a connection your TLS stack doesn't trust. Install Rust first so the build doesn't fetch it:

```
pip install "headroom-ai[all]"
```


```
CERTIFICATE_VERIFY_FAILED
```


```
unable to get local issuer certificate
```


```
maturin
```


```
rustup
```


```
# macOS / Linux curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh && rustup default stable # Windows winget install Rustlang.Rustup && rustup default stable
```

Restart your shell, then pip install "headroom-ai[all]". A prebuilt wheel avoids the Rust build entirely where available: pip install --only-binary headroom-ai headroom-ai.

```
pip install "headroom-ai[all]"
```


```
pip install --only-binary headroom-ai headroom-ai
```

Two runtime assets are fetched over TLS; if they are blocked, trust your corporate CA via REQUESTS_CA_BUNDLE / SSL_CERT_FILE / CURL_CA_BUNDLE:

```
REQUESTS_CA_BUNDLE
```


```
SSL_CERT_FILE
```


```
CURL_CA_BUNDLE
```

- cdn.pyke.io — the ONNX Runtime for the Rust core. Alternatively pre-provide it with
ORT_STRATEGY=system and ORT_LIB_LOCATION=/path/to/onnxruntime.
- huggingface.co — the kompress-base compression model. Pre-download it and run with
HF_HUB_OFFLINE=1, or set HF_ENDPOINT to a trusted mirror.

```
cdn.pyke.io
```


```
ORT_STRATEGY=system
```


```
ORT_LIB_LOCATION=/path/to/onnxruntime
```


```
huggingface.co
```


```
kompress-base
```


```
HF_HUB_OFFLINE=1
```


```
HF_ENDPOINT
```

Running with compression disabled (pure gateway) requires neither asset.

## headroom learn
headroom learn — mines failed sessions, writes corrections to CLAUDE.md / AGENTS.md / GEMINI.md.

```
headroom learn
```


```
CLAUDE.md
```


```
AGENTS.md
```


```
GEMINI.md
```

## Documentation
[Quickstart](https://headroom-docs.vercel.app/docs/quickstart)
[Architecture](https://headroom-docs.vercel.app/docs/architecture)
[Proxy](https://headroom-docs.vercel.app/docs/proxy)
[How compression works](https://headroom-docs.vercel.app/docs/how-compression-works)
[MCP tools](https://headroom-docs.vercel.app/docs/mcp)
[CCR — reversible compression](https://headroom-docs.vercel.app/docs/ccr)
[Memory](https://headroom-docs.vercel.app/docs/memory)
[Cache optimization](https://headroom-docs.vercel.app/docs/cache-optimization)
[Failure learning](https://headroom-docs.vercel.app/docs/failure-learning)
[Benchmarks](https://headroom-docs.vercel.app/docs/benchmarks)
[Configuration](https://headroom-docs.vercel.app/docs/configuration)
[Limitations](https://headroom-docs.vercel.app/docs/limitations)

## Compared to
Headroom runs locally, covers every content type, works with every major framework, and is reversible.
[RTK](https://github.com/rtk-ai/rtk)
[lean-ctx](https://github.com/yvgude/lean-ctx)
[Compresr](https://compresr.ai)
[Token Co.](https://thetokencompany.ai)
Attribution. Headroom ships with the excellent [RTK](https://github.com/rtk-ai/rtk) binary for shell-output rewriting — git show --short, scoped ls, summarized installers. Huge thanks to the RTK team; their tool is a first-class part of our stack, and Headroom compresses everything downstream of it. Headroom can also use [lean-ctx](https://github.com/yvgude/lean-ctx) as the selected CLI context tool; set HEADROOM_CONTEXT_TOOL=lean-ctx before running headroom wrap ....

```
git show --short
```


```
ls
```


```
HEADROOM_CONTEXT_TOOL=lean-ctx
```


```
headroom wrap ...
```

## Contributing
```
git clone https://github.com/chopratejas/headroom.git && cd headroom pip install -e ".[dev]" && pytest
```

Devcontainers in .devcontainer/ (default + memory-stack with Qdrant & Neo4j). See [CONTRIBUTING.md](https://github.com/chopratejas/headroom/blob/main/CONTRIBUTING.md).

```
.devcontainer/
```


```
memory-stack
```

## Community
- [Discord](https://discord.gg/yRmaUNpsPJ) — questions, feedback, war stories.
- [Kompress-v2-base on HuggingFace](https://huggingface.co/chopratejas/kompress-v2-base) — the model behind our text compression.
[Discord](https://discord.gg/yRmaUNpsPJ)
[Kompress-v2-base on HuggingFace](https://huggingface.co/chopratejas/kompress-v2-base)

## License
Apache 2.0 — see [LICENSE](https://github.com/chopratejas/headroom/blob/main/LICENSE).

## About
Compress tool outputs, logs, files, and RAG chunks before they reach the LLM. 60-95% fewer tokens, same answers. Library, proxy, MCP server.
[headroom-docs.vercel.app/docs](https://headroom-docs.vercel.app/docs)

### Topics
[python](https://github.com/topics/python)
[agent](https://github.com/topics/agent)
[typescript](https://github.com/topics/typescript)
[compression](https://github.com/topics/compression)
[ai](https://github.com/topics/ai)
[proxy](https://github.com/topics/proxy)
[mcp](https://github.com/topics/mcp)
[tokens](https://github.com/topics/tokens)
[openai](https://github.com/topics/openai)
[cursor](https://github.com/topics/cursor)
[rag](https://github.com/topics/rag)
[fastapi](https://github.com/topics/fastapi)
[llm](https://github.com/topics/llm)
[prompt-engineering](https://github.com/topics/prompt-engineering)
[langchain](https://github.com/topics/langchain)
[anthropic](https://github.com/topics/anthropic)
[context-window](https://github.com/topics/context-window)
[claude-code](https://github.com/topics/claude-code)
[token-optimization](https://github.com/topics/token-optimization)
[context-engineering](https://github.com/topics/context-engineering)

### Resources
[Readme](https://github.com/chopratejas/headroom#readme-ov-file)

### License
[Apache-2.0 license](https://github.com/chopratejas/headroom#Apache-2.0-1-ov-file)

### Code of conduct
[Code of conduct](https://github.com/chopratejas/headroom#coc-ov-file)

### Contributing
[Contributing](https://github.com/chopratejas/headroom#contributing-ov-file)

### Security policy
[Security policy](https://github.com/chopratejas/headroom#security-ov-file)

### Uh oh!
There was an error while loading. [Please reload this page](https://github.com/chopratejas/headroom).
[Activity](https://github.com/chopratejas/headroom/activity)

### Stars
[23.9k
        stars](https://github.com/chopratejas/headroom/stargazers)

### Watchers
[84
        watching](https://github.com/chopratejas/headroom/watchers)

### Forks
[1.5k
        forks](https://github.com/chopratejas/headroom/forks)
[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fchopratejas%2Fheadroom&report=chopratejas+%28user%29)

[Releases
      155](https://github.com/chopratejas/headroom/releases)
[Release v0.25.0

          Latest

      Jun 12, 2026](https://github.com/chopratejas/headroom/releases/tag/v0.25.0)
[+ 154 releases](https://github.com/chopratejas/headroom/releases)

There was an error while loading. [Please reload this page](https://github.com/chopratejas/headroom).

[Packages
      0](https://github.com/users/chopratejas/packages?repo_name=headroom)

### Uh oh!
There was an error while loading. [Please reload this page](https://github.com/chopratejas/headroom).

### Uh oh!
There was an error while loading. [Please reload this page](https://github.com/chopratejas/headroom).

[Contributors](https://github.com/chopratejas/headroom/graphs/contributors)

There was an error while loading. [Please reload this page](https://github.com/chopratejas/headroom).

- 
        [Python
          77.8%](https://github.com/chopratejas/headroom/search?l=python)

- 
        [Rust
          17.5%](https://github.com/chopratejas/headroom/search?l=rust)

- 
        [TypeScript
          2.6%](https://github.com/chopratejas/headroom/search?l=typescript)

- 
        [HTML
          1.0%](https://github.com/chopratejas/headroom/search?l=html)

- 
        [Shell
          0.4%](https://github.com/chopratejas/headroom/search?l=shell)

- 
        [PowerShell
          0.4%](https://github.com/chopratejas/headroom/search?l=powershell)

- 




        Other
        0.3%


[Python
          77.8%](https://github.com/chopratejas/headroom/search?l=python)
[Rust
          17.5%](https://github.com/chopratejas/headroom/search?l=rust)
[TypeScript
          2.6%](https://github.com/chopratejas/headroom/search?l=typescript)
[HTML
          1.0%](https://github.com/chopratejas/headroom/search?l=html)
[Shell
          0.4%](https://github.com/chopratejas/headroom/search?l=shell)
[PowerShell
          0.4%](https://github.com/chopratejas/headroom/search?l=powershell)

- 
            [Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)

- 
            [Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)

- 
            [Security](https://github.com/security)

- 
            [Status](https://www.githubstatus.com/)

- 
            [Community](https://github.community/)

- 
            [Docs](https://docs.github.com/)

- 
            [Contact](https://support.github.com?tags=dotcom-footer)

- 


       Manage cookies



- 


      Do not share my personal information



[Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)
[Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)
[Security](https://github.com/security)
[Status](https://www.githubstatus.com/)
[Community](https://github.community/)
[Docs](https://docs.github.com/)
[Contact](https://support.github.com?tags=dotcom-footer)

