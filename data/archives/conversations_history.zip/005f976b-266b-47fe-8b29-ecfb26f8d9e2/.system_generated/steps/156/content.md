Title: GitHub - colbymchenry/codegraph: Pre-indexed code knowledge graph for Claude Code, Codex, Gemini, Cursor, OpenCode, AntiGravity, Kiro, and Hermes Agent — fewer tokens, fewer tool calls, 100% local · GitHub

Description: Pre-indexed code knowledge graph for Claude Code, Codex, Gemini, Cursor, OpenCode, AntiGravity, Kiro, and Hermes Agent — fewer tokens, fewer tool calls, 100% local - colbymchenry/codegraph

Source: https://github.com/colbymchenry/codegraph

---

[Skip to content](https://github.com/colbymchenry/codegraph#start-of-content)

[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fcolbymchenry%2Fcodegraph)
- PlatformAI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryNewIntegrate external tools](https://github.com/mcp)DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)[View all features](https://github.com/features)
- AI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
- APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
- SolutionsBY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[View all industries](https://github.com/solutions/industry)[View all solutions](https://github.com/solutions)

- BY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)
- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
- BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
- BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[View all industries](https://github.com/solutions/industry)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)
- ResourcesEXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)[View all resources](https://github.com/resources)
- EXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
- EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
- SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)

- Open SourceCOMMUNITY[GitHub SponsorsFund open source developers](https://github.com/sponsors)PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[Accelerator](https://github.com/accelerator)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- COMMUNITY[GitHub SponsorsFund open source developers](https://github.com/sponsors)
- [GitHub SponsorsFund open source developers](https://github.com/sponsors)
- PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[Accelerator](https://github.com/accelerator)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [Accelerator](https://github.com/accelerator)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
- REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
- EnterpriseENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- ENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [Pricing](https://github.com/pricing)
- AI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
- APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)

- EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryNewIntegrate external tools](https://github.com/mcp)
[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
[MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
[ActionsAutomate any workflow](https://github.com/features/actions)
[CodespacesInstant dev environments](https://github.com/features/codespaces)
[IssuesPlan and track work](https://github.com/features/issues)
[Code ReviewManage code changes](https://github.com/features/code-review)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
[Why GitHub](https://github.com/why-github)
[Documentation](https://docs.github.com)
[Blog](https://github.blog)
[Changelog](https://github.blog/changelog)
[Marketplace](https://github.com/marketplace)
[View all features](https://github.com/features)
- BY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)
- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
- BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
- BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[View all industries](https://github.com/solutions/industry)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)

- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
[Enterprises](https://github.com/enterprise)
[Small and medium teams](https://github.com/team)
[Startups](https://github.com/enterprise/startups)
[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
[App Modernization](https://github.com/solutions/use-case/app-modernization)
[DevSecOps](https://github.com/solutions/use-case/devsecops)
[DevOps](https://github.com/solutions/use-case/devops)
[CI/CD](https://github.com/solutions/use-case/ci-cd)
[View all use cases](https://github.com/solutions/use-case)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)
[Healthcare](https://github.com/solutions/industry/healthcare)
[Financial services](https://github.com/solutions/industry/financial-services)
[Manufacturing](https://github.com/solutions/industry/manufacturing)
[Government](https://github.com/solutions/industry/government)
[View all industries](https://github.com/solutions/industry)
[View all solutions](https://github.com/solutions)
- EXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
- EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
- SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
[AI](https://github.com/resources/articles?topic=ai)
[Software Development](https://github.com/resources/articles?topic=software-development)
[DevOps](https://github.com/resources/articles?topic=devops)
[Security](https://github.com/resources/articles?topic=security)
[View all topics](https://github.com/resources/articles)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
[Customer stories](https://github.com/customer-stories)

[Events & webinars](https://github.com/resources/events)
[Ebooks & reports](https://github.com/resources/whitepapers)
[Business insights](https://github.com/solutions/executive-insights)
[GitHub Skills](https://skills.github.com)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)
[Documentation](https://docs.github.com)
[Customer support](https://support.github.com)
[Community forum](https://github.com/orgs/community/discussions)
[Trust center](https://github.com/trust-center)
[Partners](https://github.com/partners)
[View all resources](https://github.com/resources)
- COMMUNITY[GitHub SponsorsFund open source developers](https://github.com/sponsors)
- [GitHub SponsorsFund open source developers](https://github.com/sponsors)
- PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[Accelerator](https://github.com/accelerator)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [Accelerator](https://github.com/accelerator)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
- REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
- [GitHub SponsorsFund open source developers](https://github.com/sponsors)
[GitHub SponsorsFund open source developers](https://github.com/sponsors)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [Accelerator](https://github.com/accelerator)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
[Security Lab](https://securitylab.github.com)
[Maintainer Community](https://maintainers.github.com)
[Accelerator](https://github.com/accelerator)
[GitHub Stars](https://stars.github.com)
[Archive Program](https://archiveprogram.github.com)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
[Topics](https://github.com/topics)
[Trending](https://github.com/trending)
[Collections](https://github.com/collections)
- ENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
[Pricing](https://github.com/pricing)

# Search code, repositories, users, issues, pull requests...
[Search syntax tips](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax)

# Provide feedback
We read every piece of feedback, and take your input very seriously.

To see all available qualifiers, see our [documentation](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax).
[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fcolbymchenry%2Fcodegraph)
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=header+logged+out&ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E&source=header-repo&source_repo=colbymchenry%2Fcodegraph)
[Reload](https://github.com/colbymchenry/codegraph)
[Reload](https://github.com/colbymchenry/codegraph)
[Reload](https://github.com/colbymchenry/codegraph)
[colbymchenry](https://github.com/colbymchenry)
[codegraph](https://github.com/colbymchenry/codegraph)
- 
            [Notifications](https://github.com/login?return_to=%2Fcolbymchenry%2Fcodegraph)    You must be signed in to change notification settings


- 
          [Fork
    2.9k](https://github.com/login?return_to=%2Fcolbymchenry%2Fcodegraph)

- 

        [Star
          47.9k](https://github.com/login?return_to=%2Fcolbymchenry%2Fcodegraph)

[Notifications](https://github.com/login?return_to=%2Fcolbymchenry%2Fcodegraph)
[Fork
    2.9k](https://github.com/login?return_to=%2Fcolbymchenry%2Fcodegraph)
[Star
          47.9k](https://github.com/login?return_to=%2Fcolbymchenry%2Fcodegraph)
- 
  [Code](https://github.com/colbymchenry/codegraph)
- 
  [Issues
          69](https://github.com/colbymchenry/codegraph/issues)
- 
  [Pull requests
          151](https://github.com/colbymchenry/codegraph/pulls)
- 
  [Actions](https://github.com/colbymchenry/codegraph/actions)
- 
  [Projects](https://github.com/colbymchenry/codegraph/projects)
- 
  [Security and quality
          0](https://github.com/colbymchenry/codegraph/security)
- 
  [Insights](https://github.com/colbymchenry/codegraph/pulse)
[Code](https://github.com/colbymchenry/codegraph)
[Issues
          69](https://github.com/colbymchenry/codegraph/issues)
[Pull requests
          151](https://github.com/colbymchenry/codegraph/pulls)
[Actions](https://github.com/colbymchenry/codegraph/actions)
[Projects](https://github.com/colbymchenry/codegraph/projects)
[Security and quality
          0](https://github.com/colbymchenry/codegraph/security)
[Insights](https://github.com/colbymchenry/codegraph/pulse)
- 


    [Code](https://github.com/colbymchenry/codegraph)


- 


    [Issues](https://github.com/colbymchenry/codegraph/issues)


- 


    [Pull requests](https://github.com/colbymchenry/codegraph/pulls)


- 


    [Actions](https://github.com/colbymchenry/codegraph/actions)


- 


    [Projects](https://github.com/colbymchenry/codegraph/projects)


- 


    [Security and quality](https://github.com/colbymchenry/codegraph/security)


- 


    [Insights](https://github.com/colbymchenry/codegraph/pulse)


[Code](https://github.com/colbymchenry/codegraph)
[Issues](https://github.com/colbymchenry/codegraph/issues)
[Pull requests](https://github.com/colbymchenry/codegraph/pulls)
[Actions](https://github.com/colbymchenry/codegraph/actions)
[Projects](https://github.com/colbymchenry/codegraph/projects)
[Security and quality](https://github.com/colbymchenry/codegraph/security)
[Insights](https://github.com/colbymchenry/codegraph/pulse)

[Branches](https://github.com/colbymchenry/codegraph/branches)
[Tags](https://github.com/colbymchenry/codegraph/tags)

## History
[474 Commits](https://github.com/colbymchenry/codegraph/commits/main/)
[.claude](https://github.com/colbymchenry/codegraph/tree/main/.claude)
[.claude](https://github.com/colbymchenry/codegraph/tree/main/.claude)
[.cursor/rules](https://github.com/colbymchenry/codegraph/tree/main/.cursor/rules)
[.cursor/rules](https://github.com/colbymchenry/codegraph/tree/main/.cursor/rules)
[.github/workflows](https://github.com/colbymchenry/codegraph/tree/main/.github/workflows)
[.github/workflows](https://github.com/colbymchenry/codegraph/tree/main/.github/workflows)
[__tests__](https://github.com/colbymchenry/codegraph/tree/main/__tests__)
[__tests__](https://github.com/colbymchenry/codegraph/tree/main/__tests__)
[assets](https://github.com/colbymchenry/codegraph/tree/main/assets)
[assets](https://github.com/colbymchenry/codegraph/tree/main/assets)
[docs](https://github.com/colbymchenry/codegraph/tree/main/docs)
[docs](https://github.com/colbymchenry/codegraph/tree/main/docs)
[scripts](https://github.com/colbymchenry/codegraph/tree/main/scripts)
[scripts](https://github.com/colbymchenry/codegraph/tree/main/scripts)
[site](https://github.com/colbymchenry/codegraph/tree/main/site)
[site](https://github.com/colbymchenry/codegraph/tree/main/site)
[src](https://github.com/colbymchenry/codegraph/tree/main/src)
[src](https://github.com/colbymchenry/codegraph/tree/main/src)
[.gitignore](https://github.com/colbymchenry/codegraph/blob/main/.gitignore)
[.gitignore](https://github.com/colbymchenry/codegraph/blob/main/.gitignore)
[BUNDLING.md](https://github.com/colbymchenry/codegraph/blob/main/BUNDLING.md)
[BUNDLING.md](https://github.com/colbymchenry/codegraph/blob/main/BUNDLING.md)
[CHANGELOG.md](https://github.com/colbymchenry/codegraph/blob/main/CHANGELOG.md)
[CHANGELOG.md](https://github.com/colbymchenry/codegraph/blob/main/CHANGELOG.md)
[CLAUDE.md](https://github.com/colbymchenry/codegraph/blob/main/CLAUDE.md)
[CLAUDE.md](https://github.com/colbymchenry/codegraph/blob/main/CLAUDE.md)
[LICENSE](https://github.com/colbymchenry/codegraph/blob/main/LICENSE)
[LICENSE](https://github.com/colbymchenry/codegraph/blob/main/LICENSE)
[README.md](https://github.com/colbymchenry/codegraph/blob/main/README.md)
[README.md](https://github.com/colbymchenry/codegraph/blob/main/README.md)
[install.ps1](https://github.com/colbymchenry/codegraph/blob/main/install.ps1)
[install.ps1](https://github.com/colbymchenry/codegraph/blob/main/install.ps1)
[install.sh](https://github.com/colbymchenry/codegraph/blob/main/install.sh)
[install.sh](https://github.com/colbymchenry/codegraph/blob/main/install.sh)
[package-lock.json](https://github.com/colbymchenry/codegraph/blob/main/package-lock.json)
[package-lock.json](https://github.com/colbymchenry/codegraph/blob/main/package-lock.json)
[package.json](https://github.com/colbymchenry/codegraph/blob/main/package.json)
[package.json](https://github.com/colbymchenry/codegraph/blob/main/package.json)
[tsconfig.json](https://github.com/colbymchenry/codegraph/blob/main/tsconfig.json)
[tsconfig.json](https://github.com/colbymchenry/codegraph/blob/main/tsconfig.json)
[vitest.config.ts](https://github.com/colbymchenry/codegraph/blob/main/vitest.config.ts)
[vitest.config.ts](https://github.com/colbymchenry/codegraph/blob/main/vitest.config.ts)

## Repository files navigation
- [README](https://github.com/colbymchenry/codegraph)
- [MIT license](https://github.com/colbymchenry/codegraph)
[README](https://github.com/colbymchenry/codegraph)
[MIT license](https://github.com/colbymchenry/codegraph)

### Supercharge Claude Code, Cursor, Codex, OpenCode, Hermes Agent, Gemini, Antigravity, and Kiro with Semantic Code Intelligence
~16% cheaper · ~58% fewer tool calls · 100% local

### [Documentation & Website →](https://colbymchenry.github.io/codegraph/)
[Documentation & Website →](https://colbymchenry.github.io/codegraph/)
The CodeGraph platform is coming — for every PR, know exactly what to test, what could break, which flows are affected, and whether business logic is compromised.
Get early beta access to the hosted product · [getcodegraph.com](https://getcodegraph.com)

### 1. Install the CLI
No Node.js required — one command grabs the right build for your OS:

```
# macOS / Linux curl -fsSL https://raw.githubusercontent.com/colbymchenry/codegraph/main/install.sh | sh # Windows (PowerShell) irm https://raw.githubusercontent.com/colbymchenry/codegraph/main/install.ps1 | iex
```

Already have Node? Use npm instead (works on any version):

```
npm i -g @colbymchenry/codegraph
```

CodeGraph bundles its own runtime — nothing to compile, no native build, works the same everywhere. The installer puts codegraph on your PATH but doesn't change your current shell — open a new terminal before the next step so the command resolves.

```
codegraph
```

Upgrade any time with codegraph upgrade — it detects how you installed (bundle, npm, or npx) and updates in place. Add --check to see if an update is available, or codegraph upgrade <version> to pin one.

```
codegraph upgrade
```


```
--check
```


```
codegraph upgrade <version>
```

### 2. Wire up your agent(s)
In a new terminal, run the installer to connect CodeGraph to the agents you use:

```
codegraph install
```

Detects and auto-configures Claude Code, Cursor, Codex CLI, opencode, Hermes Agent, Gemini CLI, Antigravity IDE, and Kiro — wiring the CodeGraph MCP server into each. This is the step that connects CodeGraph to your agent; installing the CLI in step 1 does not do it on its own. (Shortcut: npx @colbymchenry/codegraph downloads and runs this in one go.)

```
npx @colbymchenry/codegraph
```

### 3. Initialize each project
```
cd your-project codegraph init -i
```

codegraph init just creates the local .codegraph/ index directory; adding -i (--index) also builds the initial graph in the same step. Without -i, run codegraph index afterwards to populate it.

```
codegraph init
```


```
.codegraph/
```


```
-i
```


```
--index
```


```
-i
```


```
codegraph index
```

### Uninstall
Changed your mind? One command removes CodeGraph from every agent it configured:

```
codegraph uninstall
```

Reverses the installer — strips CodeGraph's MCP server config, instructions, and permissions from each configured agent. Your project indexes (.codegraph/) are left untouched; remove those per-project with codegraph uninit. Use --target to remove from specific agents, or --yes to run non-interactively.

```
.codegraph/
```


```
codegraph uninit
```


```
--target
```


```
--yes
```

When Claude Code explores a codebase, it spawns Explore agents that scan files with grep, glob, and Read — consuming tokens on every tool call.
CodeGraph gives those agents a pre-indexed knowledge graph — symbol relationships, call graphs, and code structure. Agents query the graph instantly instead of scanning files.

Tested across 7 real-world open-source codebases spanning 7 languages, comparing an agent (Claude Code, headless) answering one architecture question with and without CodeGraph. Each cell is the savings at the median of 4 runs per arm. Re-validated on Opus 4.8 (2026-06-02), on the current build (codegraph_explore as the primary tool).

```
codegraph_explore
```

Average: 16% cheaper · 47% fewer tokens · 22% faster · 58% fewer tool calls
CodeGraph cuts tokens, tool calls, and wall-clock time on every repo — across small, medium, and large codebases — and answers them with near-zero file reads, while the no-CodeGraph agent spends its budget on grep/find/Read discovery. codegraph_explore shows the answer in full — the mechanism plus the exact methods you asked about, even when they're buried in a multi-thousand-line file — while collapsing redundant interchangeable implementations to signatures, so the response is sized to the answer rather than the file count. Cost stays flat-to-cheaper everywhere — largest on the small repos (Alamofire, OkHttp), roughly break-even on the most response-heavy ones (Excalidraw, Tokio), where CodeGraph trades the no-CodeGraph agent's many small grep/read round-trips for a few large, cache-heavy tool responses.

```
codegraph_explore
```

VS Code · ~10k files
Excalidraw · ~640 files
Django · ~3k files
Tokio · ~790 files
OkHttp · ~645 files
Gin · ~110 files
Alamofire · ~110 files
Methodology. Each arm is claude -p (Claude Opus 4.8) run headlessly against the repo with --strict-mcp-config: WITH = CodeGraph's MCP server enabled, WITHOUT = an empty MCP config. Built-in Read/Grep/Bash stay available to both. Same question per repo, 4 runs per arm, median reported. Cost = the run's total_cost_usd; Tokens = total tokens processed (input incl. cached + output); Time = wall-clock; Tool calls = every tool invocation, including those inside any sub-agents the model spawns. Repos cloned at --depth 1 and indexed by the same CodeGraph build that served them. Re-validated 2026-06-02 on the current build. These numbers are lower than the prior Opus 4.7 validation — not a CodeGraph regression but a stronger native baseline: Opus 4.8 greps/reads efficiently on the main thread instead of fanning out into large Explore-subagent sweeps, so the no-CodeGraph arm is leaner than it used to be. Per-repo numbers move run-to-run with how hard the without-arm thrashes (the median-of-4 smooths it, but tails remain — e.g. Django's without-arm hit $2.71/14m one batch).

```
claude -p
```


```
--strict-mcp-config
```


```
total_cost_usd
```


```
--depth 1
```

Queries:
Why CodeGraph wins: with the index available, the agent answers directly — usually one codegraph_explore returns the relevant source — and stops, usually with zero file reads. Without it, the agent spends most of its budget on discovery (find/ls/grep) before reading the right code. CodeGraph only helps when queried directly, so its instructions steer agents to answer directly rather than delegate exploration to file-reading sub-agents — otherwise a sub-agent reads files regardless and CodeGraph becomes overhead.

```
codegraph_explore
```

```
codegraph sync
```

When your agent (Claude Code, Cursor, Codex, opencode) launches codegraph serve --mcp, three layers keep the index in step with your code — and make sure the agent never gets a silent wrong answer in the brief window between an edit and the next sync:

```
codegraph serve --mcp
```

1. 
File watcher with debounced auto-sync. A native FSEvents / inotify / ReadDirectoryChangesW watcher captures every source-file create / modify / delete and triggers a re-index after a debounce window (default 2000ms, tunable via CODEGRAPH_WATCH_DEBOUNCE_MS, clamped to [100ms, 60s]). Bursts of edits collapse into a single sync.

2. 
Per-file staleness banner. During the brief debounce window, MCP tool responses that would reference a still-pending file prepend a ⚠️ banner naming it and telling the agent to Read it directly. Pending files NOT referenced by the response surface as a small footer instead. Either way, the agent gets an explicit signal — validated with Claude Code, where the agent literally says "Reading the file directly for the live content" before opening it.

3. 
Connect-time catch-up. When the MCP server (re)connects, codegraph runs a fast (size, mtime) + content-hash reconciliation against the working tree before answering the first query — so edits made while no MCP server was running (a git pull from the terminal, edits from another editor, a previous agent session that exited) get absorbed on the next session's first tool call.

File watcher with debounced auto-sync. A native FSEvents / inotify / ReadDirectoryChangesW watcher captures every source-file create / modify / delete and triggers a re-index after a debounce window (default 2000ms, tunable via CODEGRAPH_WATCH_DEBOUNCE_MS, clamped to [100ms, 60s]). Bursts of edits collapse into a single sync.

```
2000ms
```


```
CODEGRAPH_WATCH_DEBOUNCE_MS
```


```
[100ms, 60s]
```

Per-file staleness banner. During the brief debounce window, MCP tool responses that would reference a still-pending file prepend a ⚠️ banner naming it and telling the agent to Read it directly. Pending files NOT referenced by the response surface as a small footer instead. Either way, the agent gets an explicit signal — validated with Claude Code, where the agent literally says "Reading the file directly for the live content" before opening it.

```
⚠️
```


```
Read
```

Connect-time catch-up. When the MCP server (re)connects, codegraph runs a fast (size, mtime) + content-hash reconciliation against the working tree before answering the first query — so edits made while no MCP server was running (a git pull from the terminal, edits from another editor, a previous agent session that exited) get absorbed on the next session's first tool call.

```
(size, mtime)
```


```
git pull
```


```
agent writes src/Widget.ts → watcher fires (<100ms) → debounce (default 2s) → sync; Widget.ts is in the index → next agent query sees it
```


```
agent writes src/Widget.ts → watcher fires (<100ms) → debounce (default 2s) → sync; Widget.ts is in the index → next agent query sees it
```

Verify any time with codegraph_status (via MCP) or codegraph status (CLI). If anything is pending, you'll see a ### Pending sync: section naming the files and their edit age.

```
codegraph_status
```


```
codegraph status
```


```
### Pending sync:
```

The handful of cases where manual codegraph sync makes sense: the watcher is disabled (sandboxed environments, or CODEGRAPH_NO_DAEMON=1), or you're scripting against the index outside an agent session and want a pre-flight sync at the start of your script.

```
codegraph sync
```


```
CODEGRAPH_NO_DAEMON=1
```

→ Full deep-dive in [Guides → Indexing a Project](https://colbymchenry.github.io/codegraph/guides/indexing/#stay-fresh-automatically).

## Framework-aware Routes
CodeGraph detects web-framework routing files and emits route nodes linked by references edges to their handler classes or functions. Querying callers of a view/controller now surfaces the URL pattern that binds it.

```
route
```


```
references
```


```
path()
```


```
re_path()
```


```
url()
```


```
include()
```


```
urls.py
```


```
.as_view()
```


```
@app.route('/path', methods=[...])
```


```
@app.get(...)
```


```
@router.post(...)
```


```
app.get(...)
```


```
router.post(...)
```


```
@Controller
```


```
@Get/@Post/...
```


```
@Resolver
```


```
@Query/@Mutation
```


```
@MessagePattern
```


```
@EventPattern
```


```
@SubscribeMessage
```


```
Route::get()
```


```
Route::resource()
```


```
Controller@action
```


```
*.routing.yml
```


```
_controller
```


```
_form
```


```
hook_*
```


```
.module
```


```
.theme
```


```
.install
```


```
.inc
```


```
get '/x', to: 'users#index'
```


```
=>
```


```
@GetMapping
```


```
@PostMapping
```


```
@RequestMapping
```


```
GET
```


```
POST
```


```
conf/routes
```


```
Controller.method
```


```
r.GET(...)
```


```
router.HandleFunc(...)
```


```
.route("/x", get(handler))
```


```
[HttpGet("/x")]
```


```
app.get("x", use: handler)
```


```
pages/
```


```
server/api/
```


```
src/pages/
```


```
.astro
```


```
.ts
```


```
[param]
```


```
[...rest]
```

## Mixed iOS / React Native / Expo bridging
Real iOS and React Native codebases live across multiple languages — a Swift caller invokes an Objective-C selector that's been auto-bridged, a JS file calls into a native module via the React Native bridge, a JSX component delegates to a native view manager. Static tree-sitter extraction stops at each language boundary. CodeGraph bridges them so trace, callers, callees, and impact connect end-to-end across the gap.

```
trace
```


```
callers
```


```
callees
```


```
impact
```


```
obj.foo(bar:)
```


```
-fooWithBar:
```


```
@objc
```


```
With
```


```
For
```


```
By
```


```
In
```


```
On
```


```
At
```


```
[obj fooWithBar:]
```


```
@objc func foo(bar:)
```


```
@objc
```


```
NativeModules.X.fn(...)
```


```
RCT_EXPORT_METHOD
```


```
RCT_REMAP_METHOD
```


```
@ReactMethod
```


```
import M from './NativeM'; M.fn(...)
```


```
Native<X>.ts
```


```
new NativeEventEmitter(...).addListener('e', cb)
```


```
[self sendEventWithName:@"e" body:...]
```


```
sendEvent(withName: "e", ...)
```


```
.emit("e", ...)
```


```
requireNativeModule('X').fn(...)
```


```
Module { Name("X"); AsyncFunction("fn") { ... } }
```


```
<MyView prop={v}/>
```


```
component
```


```
View
```


```
ComponentView
```


```
Manager
```


```
ViewManager
```


```
<MyView prop={v}/>
```


```
RCT_EXPORT_VIEW_PROPERTY
```


```
@ReactProp
```


```
component
```


```
property
```

Validated on real codebases (small + medium + large for each bridge):
[Charts](https://github.com/danielgindi/Charts)
[realm-swift](https://github.com/realm/realm-swift)
[Wikipedia-iOS](https://github.com/wikimedia/wikipedia-ios)
[AsyncStorage](https://github.com/react-native-async-storage/async-storage)
[react-native-svg](https://github.com/software-mansion/react-native-svg)
[react-native-firebase](https://github.com/invertase/react-native-firebase)
[RNGeolocation](https://github.com/Agontuk/react-native-geolocation-service)
[react-native-segmented-control](https://github.com/react-native-segmented-control/segmented-control)
[react-native-screens](https://github.com/software-mansion/react-native-screens)
[react-native-skia](https://github.com/Shopify/react-native-skia)
Each bridge emits edges tagged provenance:'heuristic' with metadata.synthesizedBy: set to a stable channel name (e.g. swift-objc-bridge, rn-event-channel, fabric-native-impl, expo-module-extract), so the agent can tell at a glance how a hop got into the graph.

```
provenance:'heuristic'
```


```
metadata.synthesizedBy:
```


```
swift-objc-bridge
```


```
rn-event-channel
```


```
fabric-native-impl
```


```
expo-module-extract
```

### 1. Run the Installer
```
npx @colbymchenry/codegraph
```

The installer will:
- Ask which agent(s) to configure — auto-detects installed ones from: Claude Code, Cursor, Codex CLI, opencode, Hermes Agent, Gemini CLI, Antigravity IDE, Kiro
- Prompt to install codegraph on your PATH (so agents can launch the MCP server)
- Ask whether configs apply to all your projects or just this one
- Write each chosen agent's MCP server config, plus a small marker-fenced CodeGraph section in the agent's instructions file (CLAUDE.md / AGENTS.md / GEMINI.md) — that's how subagents and non-MCP agents learn the codegraph explore / codegraph node commands, since the MCP server's own guidance only reaches the main agent. Removed cleanly by codegraph uninstall.
- Set up auto-allow permissions when Claude Code is one of the targets
- Initialize your current project (local installs only)

```
codegraph
```


```
CLAUDE.md
```


```
AGENTS.md
```


```
GEMINI.md
```


```
codegraph explore
```


```
codegraph node
```


```
codegraph uninstall
```

Non-interactive (scripting / CI):

```
codegraph install --yes # auto-detect agents, install global codegraph install --target=cursor,claude --yes # explicit target list codegraph install --target=auto --location=local # detected agents, project-local codegraph install --print-config codex # print snippet, no file writes
```


```
--target
```


```
auto
```


```
all
```


```
none
```


```
claude,cursor,...
```


```
--location
```


```
global
```


```
local
```


```
--yes
```


```
--no-permissions
```


```
--print-config <id>
```

### 2. Restart Your Agent
Restart your agent (Claude Code / Cursor / Codex CLI / opencode / Hermes Agent / Gemini CLI / Antigravity IDE / Kiro) for the MCP server to load.

### 3. Initialize Projects
```
cd your-project codegraph init -i
```

Builds the per-project knowledge graph index. A single global codegraph install works in every project you open — no need to re-run the installer per project.

```
codegraph install
```

That's it — your agent will use CodeGraph tools automatically when a .codegraph/ directory exists.

```
.codegraph/
```

Install globally:

```
npm install -g @colbymchenry/codegraph
```

Add to ~/.claude.json:

```
~/.claude.json
```


```
{ "mcpServers": { "codegraph": { "type": "stdio", "command": "codegraph", "args": ["serve", "--mcp"] } } }
```

Add to ~/.claude/settings.json (optional, for auto-allow):

```
~/.claude/settings.json
```


```
{ "permissions": { "allow": [ "mcp__codegraph__codegraph_search", "mcp__codegraph__codegraph_explore", "mcp__codegraph__codegraph_callers", "mcp__codegraph__codegraph_callees", "mcp__codegraph__codegraph_impact", "mcp__codegraph__codegraph_node", "mcp__codegraph__codegraph_status", "mcp__codegraph__codegraph_files" ] } }
```

CodeGraph's MCP server delivers its usage guidance to your agent automatically, in the MCP initialize response. In short, it tells the agent to:

```
initialize
```

- Answer structural questions directly with CodeGraph — it is the pre-built index, so a grep/read loop just repeats work it already did. Treat the returned source as already read.
- Pick the tool by intent: codegraph_explore for almost anything — "how does X work", a flow/"how does X reach Y", or surveying an area (one call returns the relevant symbols' source grouped by file); codegraph_search to just locate a symbol; codegraph_callers for every call site (including callback registrations); codegraph_node for one symbol's full source + callers, or to read a file like the Read tool.
- Trust the results — don't re-verify with grep, and check the staleness banner after edits.
- In a workspace with no index, CodeGraph announces itself inactive and serves no tools — indexing stays your decision.

```
codegraph_explore
```


```
codegraph_search
```


```
codegraph_callers
```


```
codegraph_node
```

The exact text is src/mcp/server-instructions.ts — the single source of truth for the main agent. Because subagents and non-MCP harnesses never see the MCP guidance, the installer also writes a four-line marker-fenced section into the agent's instructions file pointing at the codegraph explore / codegraph node CLI equivalents.

```
src/mcp/server-instructions.ts
```


```
codegraph explore
```


```
codegraph node
```

```
┌───────────────────────────────────────────────────────────────────┐ │ Claude Code │ │ │ │ "How does a request reach the database?" │ │ calls CodeGraph tools directly — no Explore sub-agent │ │ │ │ └─────────────────────────────────┬─────────────────────────────────┘ │ ▼ ┌───────────────────────────────────────────────────────────────────┐ │ CodeGraph MCP Server │ │ │ │ explore · search · callers · callees · impact · node │ │ │ │ │ ▼ │ │ SQLite knowledge graph │ │ symbols · edges · files · FTS5 full-text search │ └───────────────────────────────────────────────────────────────────┘
```


```
┌───────────────────────────────────────────────────────────────────┐ │ Claude Code │ │ │ │ "How does a request reach the database?" │ │ calls CodeGraph tools directly — no Explore sub-agent │ │ │ │ └─────────────────────────────────┬─────────────────────────────────┘ │ ▼ ┌───────────────────────────────────────────────────────────────────┐ │ CodeGraph MCP Server │ │ │ │ explore · search · callers · callees · impact · node │ │ │ │ │ ▼ │ │ SQLite knowledge graph │ │ symbols · edges · files · FTS5 full-text search │ └───────────────────────────────────────────────────────────────────┘
```

1. 
Extraction — [tree-sitter](https://tree-sitter.github.io/) parses source code into ASTs. Language-specific queries extract nodes (functions, classes, methods) and edges (calls, imports, extends, implements).

2. 
Storage — Everything goes into a local SQLite database (.codegraph/codegraph.db) with FTS5 full-text search.

3. 
Resolution — After extraction, references are resolved: function calls → definitions, imports → source files, class inheritance, and framework-specific patterns.

4. 
Auto-Sync — The MCP server watches your project using native OS file events. Changes are debounced (2-second quiet window), filtered to source files only, and incrementally synced. The graph stays fresh as you code — no configuration needed.

Extraction — [tree-sitter](https://tree-sitter.github.io/) parses source code into ASTs. Language-specific queries extract nodes (functions, classes, methods) and edges (calls, imports, extends, implements).
Storage — Everything goes into a local SQLite database (.codegraph/codegraph.db) with FTS5 full-text search.

```
.codegraph/codegraph.db
```

Resolution — After extraction, references are resolved: function calls → definitions, imports → source files, class inheritance, and framework-specific patterns.
Auto-Sync — The MCP server watches your project using native OS file events. Changes are debounced (2-second quiet window), filtered to source files only, and incrementally synced. The graph stays fresh as you code — no configuration needed.

```
codegraph # Run interactive installer codegraph install # Run installer (explicit) codegraph uninstall # Remove CodeGraph from your agents (inverse of install) codegraph init [path] # Initialize in a project (--index to also index) codegraph uninit [path] # Remove CodeGraph from a project (--force to skip prompt) codegraph index [path] # Full index (--force to re-index, --quiet for less output) codegraph sync [path] # Incremental update codegraph status [path] # Show statistics codegraph query <search> # Search symbols (--kind, --limit, --json) codegraph explore <query> # Relevant symbols' source + call paths in one shot (same output as the codegraph_explore MCP tool) codegraph node <symbol|file> # One symbol's source + callers, or read a file with line numbers (same output as codegraph_node) codegraph files [path] # Show file structure (--format, --filter, --max-depth, --json) codegraph callers <symbol> # Find what calls a function/method (--limit, --json) codegraph callees <symbol> # Find what a function/method calls (--limit, --json) codegraph impact <symbol> # Analyze what code is affected by changing a symbol (--depth, --json) codegraph affected [files...] # Find test files affected by changes (see below) codegraph serve --mcp # Start MCP server codegraph upgrade [version] # Update to the latest release (--check, --force)
```

```
codegraph affected
```

Traces import dependencies transitively to find which test files are affected by changed source files.

```
codegraph affected src/utils.ts src/api.ts # Pass files as arguments git diff --name-only | codegraph affected --stdin # Pipe from git diff codegraph affected src/auth.ts --filter "e2e/*" # Custom test file pattern
```


```
--stdin
```


```
false
```


```
-d, --depth <n>
```


```
5
```


```
-f, --filter <glob>
```


```
-j, --json
```


```
false
```


```
-q, --quiet
```


```
false
```

CI/hook example:

```
#!/usr/bin/env bash AFFECTED=$(git diff --name-only HEAD | codegraph affected --stdin --quiet) if [ -n "$AFFECTED" ]; then npx vitest run $AFFECTED fi
```

## MCP Tools
When running as an MCP server, CodeGraph exposes a focused set of four tools — measured agent behavior showed a leaner list steers agents to the right tool and saves context every session:

```
codegraph_explore
```


```
codegraph_node
```


```
offset
```


```
limit
```


```
codegraph_search
```


```
codegraph_callers
```

Four more tools (codegraph_callees, codegraph_impact, codegraph_files, codegraph_status) stay fully functional but unlisted by default — measured across eval runs, agents never or rarely picked them, and their information already arrives inline on the four above (explore's blast-radius section, node's dependents note, a symbol's body as its callee list). Re-enable any of them with the CODEGRAPH_MCP_TOOLS environment variable (e.g. CODEGRAPH_MCP_TOOLS=explore,node,search,callers,impact), or use their CLI equivalents (codegraph callees / impact / files / status).

```
codegraph_callees
```


```
codegraph_impact
```


```
codegraph_files
```


```
codegraph_status
```


```
CODEGRAPH_MCP_TOOLS
```


```
CODEGRAPH_MCP_TOOLS=explore,node,search,callers,impact
```


```
codegraph callees
```


```
impact
```


```
files
```


```
status
```

In a workspace with no .codegraph/ index, the server announces itself inactive and lists no tools — agents work normally with their built-in tools, and indexing stays your decision.

```
.codegraph/
```

## Library Usage
CodeGraph can be embedded directly. The npm package re-exports its programmatic API, so both import and require resolve the CodeGraph class in your own process — handy for embedding it in an app (e.g. an Electron main process).

```
import
```


```
require
```


```
CodeGraph
```


```
import CodeGraph from '@colbymchenry/codegraph'; // CommonJS works too: // const { CodeGraph } = require('@colbymchenry/codegraph'); const cg = await CodeGraph.init('/path/to/project'); // Or: const cg = await CodeGraph.open('/path/to/project'); await cg.indexAll({ onProgress: (p) => console.log(`${p.phase}: ${p.current}/${p.total}`) }); const results = cg.searchNodes('UserService'); const callers = cg.getCallers(results[0].node.id); const context = await cg.buildContext('fix login bug', { maxNodes: 20, includeCode: true, format: 'markdown' }); const impact = cg.getImpactRadius(results[0].node.id, 2); cg.watch(); // auto-sync on file changes cg.unwatch(); // stop watching cg.close();
```

Lower-level building blocks are exported from the same entry point for callers that drive the graph directly: DatabaseConnection, QueryBuilder, getDatabasePath, initGrammars / loadGrammarsForLanguages, and FileLock.

```
DatabaseConnection
```


```
QueryBuilder
```


```
getDatabasePath
```


```
initGrammars
```


```
loadGrammarsForLanguages
```


```
FileLock
```

Embedding requirements
- Install from npm (npm i @colbymchenry/codegraph) so the matching
per-platform package — which carries the compiled library and its
dependencies — is fetched alongside the shim.
- The API runs on your runtime, so it needs Node 22.5+ for the built-in
node:sqlite (Electron qualifies when its bundled Node is 22.5+). The CLI and
MCP server are unaffected — they run on the self-contained bundled runtime.
- TypeScript types ship with the package. As with any Node-targeting library,
keep @types/node available and skipLibCheck: true (the common default).

```
npm i @colbymchenry/codegraph
```


```
node:sqlite
```


```
@types/node
```


```
skipLibCheck: true
```

## Configuration
There isn't any — CodeGraph is zero-config, with no config file to write or keep in sync. Language support is automatic from the file extension; there's nothing to wire up per language.
What it skips out of the box:
- Dependency, build, and cache directories — node_modules, vendor,
dist, build, target, .venv, Pods, .next, and the like across every
[supported stack](https://github.com/colbymchenry/codegraph#supported-languages) — so the graph is your code, not
third-party noise. This holds even with no .gitignore.
- Anything in your .gitignore — honored in git repos via git, and in
non-git projects by reading .gitignore directly (root and nested).
- Files larger than 1 MB — generated bundles, minified JS, vendored blobs.

```
node_modules
```


```
vendor
```


```
dist
```


```
build
```


```
target
```


```
.venv
```


```
Pods
```


```
.next
```

[supported stack](https://github.com/colbymchenry/codegraph#supported-languages)

```
.gitignore
```


```
.gitignore
```


```
.gitignore
```

To keep something else out, add it to .gitignore. To pull a default-excluded directory back in (say you really do want a vendored dependency indexed), add a negation — !vendor/. The defaults apply uniformly, so committing a dependency or build directory doesn't force it into the graph; the .gitignore negation is the explicit opt-in.

```
.gitignore
```


```
!vendor/
```


```
.gitignore
```

## Supported Platforms
Every release ships a self-contained build (bundled Node runtime — nothing to compile) for all three desktop OSes, on both Intel/AMD (x64) and ARM (arm64):
See [Get Started](https://github.com/colbymchenry/codegraph#get-started) for the one-line install commands.

## Supported Agents
The interactive installer auto-detects and configures each of these — wiring up the MCP server (which delivers its own usage guidance, so no instructions file is written):
- Claude Code
- Cursor
- Codex CLI
- opencode
- Hermes Agent
- Gemini CLI
- Antigravity IDE
- Kiro

## Supported Languages
```
.ts
```


```
.tsx
```


```
.js
```


```
.jsx
```


```
.mjs
```


```
.py
```


```
.go
```


```
.rs
```


```
.java
```


```
.cs
```


```
.php
```


```
.rb
```


```
.c
```


```
.h
```


```
.cpp
```


```
.hpp
```


```
.cc
```


```
.m
```


```
.mm
```


```
.h
```


```
@property
```


```
#import
```


```
.mm
```


```
.swift
```


```
.kt
```


```
.kts
```


```
.scala
```


```
.sc
```


```
.dart
```


```
.svelte
```


```
.vue
```


```
.astro
```


```
src/pages/
```


```
.liquid
```


```
.pas
```


```
.dpr
```


```
.dpk
```


```
.lpr
```


```
.lua
```


```
require
```


```
.luau
```


```
type
```


```
export type
```


```
require
```

## Measured cross-file coverage
Impact and blast-radius queries are only as good as the dependency graph behind them, so coverage is measured rather than asserted. Fair coverage = the share of symbol-bearing source files that have at least one resolved cross-file dependent — something that imports, calls, references, or (through a framework convention) routes to them — on a real-world benchmark repo per language. The residual is always a genuine static-analysis frontier (runtime dynamic dispatch, reflection / DI containers, framework-convention entry points, vendored third-party code), never hidden by gaming the denominator.
Framework routing is validated the same way, on a canonical app per framework: Express 100%, FastAPI 98%, Flask 100%, NestJS 96.8%, Gin 96.5%, Axum 100%, Rocket 93.8%, Vapor 100%, Laravel 92%, Rails 89.6%, React Router 100% — and the convention/reflection-heavy ones at their honest static-analysis ceiling: ASP.NET 83.9%, Spring 83.3%, Drupal 78.9%, Play 76.3%, Django 74.1%. SvelteKit, Vue/Nuxt, and Astro use file-based routing, so their page/endpoint coverage is the Svelte/SvelteKit (100%), Vue/Nuxt (93.5%), and Astro (93.0% — every src/pages/ file maps to a route node on the two validation repos) figures in the table above.

```
src/pages/
```

## Troubleshooting
"CodeGraph not initialized" — Run codegraph init in your project directory first.

```
codegraph init
```

Indexing is slow — Check that node_modules and other large directories are excluded. Use --quiet to reduce output overhead.

```
node_modules
```


```
--quiet
```

MCP hits database is locked — current builds shouldn't: CodeGraph bundles its own Node runtime and uses Node's built-in node:sqlite in WAL mode, where concurrent reads never block on a writer. If you still see it:

```
database is locked
```


```
node:sqlite
```

- You're on an old (pre-0.9) install. Reinstall to get the bundled runtime — curl -fsSL https://raw.githubusercontent.com/colbymchenry/codegraph/main/install.sh | sh (macOS/Linux), irm https://raw.githubusercontent.com/colbymchenry/codegraph/main/install.ps1 | iex (Windows), or npm i -g @colbymchenry/codegraph@latest.
- codegraph status shows Journal: other than wal — WAL couldn't be enabled on this filesystem (common on network shares and WSL2 /mnt), so reads can block on writes. Move the project (with its .codegraph/ folder) onto a local disk.

```
curl -fsSL https://raw.githubusercontent.com/colbymchenry/codegraph/main/install.sh | sh
```


```
irm https://raw.githubusercontent.com/colbymchenry/codegraph/main/install.ps1 | iex
```


```
npm i -g @colbymchenry/codegraph@latest
```


```
codegraph status
```


```
Journal:
```


```
wal
```


```
/mnt
```


```
.codegraph/
```

MCP server not connecting — Ensure the project is initialized/indexed, verify the path in your MCP config, and check that codegraph serve --mcp works from the command line.

```
codegraph serve --mcp
```

Missing symbols — The MCP server auto-syncs on save (wait a couple seconds). Run codegraph sync manually if needed. Check that the file's language is supported and isn't inside a .gitignored or default-excluded directory (e.g. node_modules, dist).

```
codegraph sync
```


```
.gitignore
```


```
node_modules
```


```
dist
```

Sharing one checkout between Windows and WSL — Don't point both at the same .codegraph/: the background-server lock and the SQLite index are tied to the OS that wrote them, and SQLite locking across the WSL2/Windows filesystem boundary is unreliable. Give each side its own index in the same tree by setting CODEGRAPH_DIR to a distinct name on one of them — e.g. CODEGRAPH_DIR=.codegraph-win on Windows, leaving WSL on the default .codegraph. CodeGraph skips any sibling .codegraph-* directory when indexing and watching, so the two never trip over each other.

```
.codegraph/
```


```
CODEGRAPH_DIR
```


```
CODEGRAPH_DIR=.codegraph-win
```


```
.codegraph
```


```
.codegraph-*
```

## License
MIT
Made for AI coding agents — Claude Code, Cursor, Codex CLI, opencode, Hermes Agent, Gemini CLI, Antigravity IDE, and Kiro
[Report Bug](https://github.com/colbymchenry/codegraph/issues) · [Request Feature](https://github.com/colbymchenry/codegraph/issues)

## About
Pre-indexed code knowledge graph for Claude Code, Codex, Gemini, Cursor, OpenCode, AntiGravity, Kiro, and Hermes Agent — fewer tokens, fewer tool calls, 100% local
[colbymchenry.github.io/codegraph/](https://colbymchenry.github.io/codegraph/)

### Resources
[Readme](https://github.com/colbymchenry/codegraph#readme-ov-file)

### License
[MIT license](https://github.com/colbymchenry/codegraph#MIT-1-ov-file)

### Uh oh!
There was an error while loading. [Please reload this page](https://github.com/colbymchenry/codegraph).
[Activity](https://github.com/colbymchenry/codegraph/activity)

### Stars
[47.9k
        stars](https://github.com/colbymchenry/codegraph/stargazers)

### Watchers
[115
        watching](https://github.com/colbymchenry/codegraph/watchers)

### Forks
[2.9k
        forks](https://github.com/colbymchenry/codegraph/forks)
[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fcolbymchenry%2Fcodegraph&report=colbymchenry+%28user%29)

## [Releases 15](https://github.com/colbymchenry/codegraph/releases)
[Releases
      15](https://github.com/colbymchenry/codegraph/releases)
[v0.9.9

          Latest

      Jun 2, 2026](https://github.com/colbymchenry/codegraph/releases/tag/v0.9.9)
[+ 14 releases](https://github.com/colbymchenry/codegraph/releases)

## [Packages 0](https://github.com/users/colbymchenry/packages?repo_name=codegraph)
[Packages
      0](https://github.com/users/colbymchenry/packages?repo_name=codegraph)

There was an error while loading. [Please reload this page](https://github.com/colbymchenry/codegraph).

[Contributors](https://github.com/colbymchenry/codegraph/graphs/contributors)

There was an error while loading. [Please reload this page](https://github.com/colbymchenry/codegraph).

- 
        [TypeScript
          92.5%](https://github.com/colbymchenry/codegraph/search?l=typescript)

- 
        [JavaScript
          4.6%](https://github.com/colbymchenry/codegraph/search?l=javascript)

- 
        [Shell
          2.1%](https://github.com/colbymchenry/codegraph/search?l=shell)

- 




        Other
        0.8%


[TypeScript
          92.5%](https://github.com/colbymchenry/codegraph/search?l=typescript)
[JavaScript
          4.6%](https://github.com/colbymchenry/codegraph/search?l=javascript)
[Shell
          2.1%](https://github.com/colbymchenry/codegraph/search?l=shell)

- 
            [Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)

- 
            [Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)

- 
            [Security](https://github.com/security)

- 
            [Status](https://www.githubstatus.com/)

- 
            [Community](https://github.community/)

- 
            [Docs](https://docs.github.com/)

- 
            [Contact](https://support.github.com?tags=dotcom-footer)

- 


       Manage cookies



- 


      Do not share my personal information



[Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)
[Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)
[Security](https://github.com/security)
[Status](https://www.githubstatus.com/)
[Community](https://github.community/)
[Docs](https://docs.github.com/)
[Contact](https://support.github.com?tags=dotcom-footer)

