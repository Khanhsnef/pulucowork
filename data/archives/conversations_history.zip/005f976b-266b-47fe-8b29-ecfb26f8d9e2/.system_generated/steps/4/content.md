Title: GitHub - rohitg00/agentmemory: #1 Persistent memory for AI coding agents based on real-world benchmarks · GitHub

Description: #1 Persistent memory for AI coding agents based on real-world benchmarks - rohitg00/agentmemory

Source: https://github.com/rohitg00/agentmemory

---

[Skip to content](https://github.com/rohitg00/agentmemory#start-of-content)

[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Frohitg00%2Fagentmemory)
- PlatformAI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryNewIntegrate external tools](https://github.com/mcp)DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)[View all features](https://github.com/features)
- AI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
- APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
- SolutionsBY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[View all industries](https://github.com/solutions/industry)[View all solutions](https://github.com/solutions)

- BY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)
- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
- BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
- BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[View all industries](https://github.com/solutions/industry)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)
- ResourcesEXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)[View all resources](https://github.com/resources)
- EXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
- EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
- SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)

- Open SourceCOMMUNITY[GitHub SponsorsFund open source developers](https://github.com/sponsors)PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[Accelerator](https://github.com/accelerator)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- COMMUNITY[GitHub SponsorsFund open source developers](https://github.com/sponsors)
- [GitHub SponsorsFund open source developers](https://github.com/sponsors)
- PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[Accelerator](https://github.com/accelerator)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [Accelerator](https://github.com/accelerator)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
- REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
- EnterpriseENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- ENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [Pricing](https://github.com/pricing)
- AI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
- APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)

- EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryNewIntegrate external tools](https://github.com/mcp)
[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
[MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
[ActionsAutomate any workflow](https://github.com/features/actions)
[CodespacesInstant dev environments](https://github.com/features/codespaces)
[IssuesPlan and track work](https://github.com/features/issues)
[Code ReviewManage code changes](https://github.com/features/code-review)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
[Why GitHub](https://github.com/why-github)
[Documentation](https://docs.github.com)
[Blog](https://github.blog)
[Changelog](https://github.blog/changelog)
[Marketplace](https://github.com/marketplace)
[View all features](https://github.com/features)
- BY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)
- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
- BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
- BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[View all industries](https://github.com/solutions/industry)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)

- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
[Enterprises](https://github.com/enterprise)
[Small and medium teams](https://github.com/team)
[Startups](https://github.com/enterprise/startups)
[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
[App Modernization](https://github.com/solutions/use-case/app-modernization)
[DevSecOps](https://github.com/solutions/use-case/devsecops)
[DevOps](https://github.com/solutions/use-case/devops)
[CI/CD](https://github.com/solutions/use-case/ci-cd)
[View all use cases](https://github.com/solutions/use-case)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)
[Healthcare](https://github.com/solutions/industry/healthcare)
[Financial services](https://github.com/solutions/industry/financial-services)
[Manufacturing](https://github.com/solutions/industry/manufacturing)
[Government](https://github.com/solutions/industry/government)
[View all industries](https://github.com/solutions/industry)
[View all solutions](https://github.com/solutions)
- EXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
- EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
- SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
[AI](https://github.com/resources/articles?topic=ai)
[Software Development](https://github.com/resources/articles?topic=software-development)
[DevOps](https://github.com/resources/articles?topic=devops)
[Security](https://github.com/resources/articles?topic=security)
[View all topics](https://github.com/resources/articles)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
[Customer stories](https://github.com/customer-stories)

[Events & webinars](https://github.com/resources/events)
[Ebooks & reports](https://github.com/resources/whitepapers)
[Business insights](https://github.com/solutions/executive-insights)
[GitHub Skills](https://skills.github.com)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)
[Documentation](https://docs.github.com)
[Customer support](https://support.github.com)
[Community forum](https://github.com/orgs/community/discussions)
[Trust center](https://github.com/trust-center)
[Partners](https://github.com/partners)
[View all resources](https://github.com/resources)
- COMMUNITY[GitHub SponsorsFund open source developers](https://github.com/sponsors)
- [GitHub SponsorsFund open source developers](https://github.com/sponsors)
- PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[Accelerator](https://github.com/accelerator)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [Accelerator](https://github.com/accelerator)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
- REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
- [GitHub SponsorsFund open source developers](https://github.com/sponsors)
[GitHub SponsorsFund open source developers](https://github.com/sponsors)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [Accelerator](https://github.com/accelerator)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
[Security Lab](https://securitylab.github.com)
[Maintainer Community](https://maintainers.github.com)
[Accelerator](https://github.com/accelerator)
[GitHub Stars](https://stars.github.com)
[Archive Program](https://archiveprogram.github.com)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
[Topics](https://github.com/topics)
[Trending](https://github.com/trending)
[Collections](https://github.com/collections)
- ENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
[Pricing](https://github.com/pricing)

# Search code, repositories, users, issues, pull requests...
[Search syntax tips](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax)

# Provide feedback
We read every piece of feedback, and take your input very seriously.

To see all available qualifiers, see our [documentation](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax).
[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Frohitg00%2Fagentmemory)
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=header+logged+out&ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E&source=header-repo&source_repo=rohitg00%2Fagentmemory)
[Reload](https://github.com/rohitg00/agentmemory)
[Reload](https://github.com/rohitg00/agentmemory)
[Reload](https://github.com/rohitg00/agentmemory)
[rohitg00](https://github.com/rohitg00)
[agentmemory](https://github.com/rohitg00/agentmemory)
- 
            [Notifications](https://github.com/login?return_to=%2Frohitg00%2Fagentmemory)    You must be signed in to change notification settings


- 
          [Fork
    1.9k](https://github.com/login?return_to=%2Frohitg00%2Fagentmemory)

- 

        [Star
          22.5k](https://github.com/login?return_to=%2Frohitg00%2Fagentmemory)

[Notifications](https://github.com/login?return_to=%2Frohitg00%2Fagentmemory)
[Fork
    1.9k](https://github.com/login?return_to=%2Frohitg00%2Fagentmemory)
[Star
          22.5k](https://github.com/login?return_to=%2Frohitg00%2Fagentmemory)
- 
  [Code](https://github.com/rohitg00/agentmemory)
- 
  [Issues
          138](https://github.com/rohitg00/agentmemory/issues)
- 
  [Pull requests
          150](https://github.com/rohitg00/agentmemory/pulls)
- 
  [Discussions](https://github.com/rohitg00/agentmemory/discussions)
- 
  [Actions](https://github.com/rohitg00/agentmemory/actions)
- 
  [Projects](https://github.com/rohitg00/agentmemory/projects)
- 
  [Security and quality
          0](https://github.com/rohitg00/agentmemory/security)
- 
  [Insights](https://github.com/rohitg00/agentmemory/pulse)
[Code](https://github.com/rohitg00/agentmemory)
[Issues
          138](https://github.com/rohitg00/agentmemory/issues)
[Pull requests
          150](https://github.com/rohitg00/agentmemory/pulls)
[Discussions](https://github.com/rohitg00/agentmemory/discussions)
[Actions](https://github.com/rohitg00/agentmemory/actions)
[Projects](https://github.com/rohitg00/agentmemory/projects)
[Security and quality
          0](https://github.com/rohitg00/agentmemory/security)
[Insights](https://github.com/rohitg00/agentmemory/pulse)
- 


    [Code](https://github.com/rohitg00/agentmemory)


- 


    [Issues](https://github.com/rohitg00/agentmemory/issues)


- 


    [Pull requests](https://github.com/rohitg00/agentmemory/pulls)


- 


    [Discussions](https://github.com/rohitg00/agentmemory/discussions)


- 


    [Actions](https://github.com/rohitg00/agentmemory/actions)


- 


    [Projects](https://github.com/rohitg00/agentmemory/projects)


- 


    [Security and quality](https://github.com/rohitg00/agentmemory/security)


- 


    [Insights](https://github.com/rohitg00/agentmemory/pulse)


[Code](https://github.com/rohitg00/agentmemory)
[Issues](https://github.com/rohitg00/agentmemory/issues)
[Pull requests](https://github.com/rohitg00/agentmemory/pulls)
[Discussions](https://github.com/rohitg00/agentmemory/discussions)
[Actions](https://github.com/rohitg00/agentmemory/actions)
[Projects](https://github.com/rohitg00/agentmemory/projects)
[Security and quality](https://github.com/rohitg00/agentmemory/security)
[Insights](https://github.com/rohitg00/agentmemory/pulse)

[Branches](https://github.com/rohitg00/agentmemory/branches)
[Tags](https://github.com/rohitg00/agentmemory/tags)

[462 Commits](https://github.com/rohitg00/agentmemory/commits/main/)
[.claude-plugin](https://github.com/rohitg00/agentmemory/tree/main/.claude-plugin)
[.claude-plugin](https://github.com/rohitg00/agentmemory/tree/main/.claude-plugin)
[.codex-plugin](https://github.com/rohitg00/agentmemory/tree/main/.codex-plugin)
[.codex-plugin](https://github.com/rohitg00/agentmemory/tree/main/.codex-plugin)
[.github](https://github.com/rohitg00/agentmemory/tree/main/.github)
[.github](https://github.com/rohitg00/agentmemory/tree/main/.github)
[READMEs](https://github.com/rohitg00/agentmemory/tree/main/READMEs)
[READMEs](https://github.com/rohitg00/agentmemory/tree/main/READMEs)
[assets](https://github.com/rohitg00/agentmemory/tree/main/assets)
[assets](https://github.com/rohitg00/agentmemory/tree/main/assets)
[benchmark](https://github.com/rohitg00/agentmemory/tree/main/benchmark)
[benchmark](https://github.com/rohitg00/agentmemory/tree/main/benchmark)
[deploy](https://github.com/rohitg00/agentmemory/tree/main/deploy)
[deploy](https://github.com/rohitg00/agentmemory/tree/main/deploy)
[docs](https://github.com/rohitg00/agentmemory/tree/main/docs)
[docs](https://github.com/rohitg00/agentmemory/tree/main/docs)
[eval](https://github.com/rohitg00/agentmemory/tree/main/eval)
[eval](https://github.com/rohitg00/agentmemory/tree/main/eval)
[examples/python](https://github.com/rohitg00/agentmemory/tree/main/examples/python)
[examples/python](https://github.com/rohitg00/agentmemory/tree/main/examples/python)
[integrations](https://github.com/rohitg00/agentmemory/tree/main/integrations)
[integrations](https://github.com/rohitg00/agentmemory/tree/main/integrations)
[packages/mcp](https://github.com/rohitg00/agentmemory/tree/main/packages/mcp)
[packages/mcp](https://github.com/rohitg00/agentmemory/tree/main/packages/mcp)
[plugin](https://github.com/rohitg00/agentmemory/tree/main/plugin)
[plugin](https://github.com/rohitg00/agentmemory/tree/main/plugin)
[scripts](https://github.com/rohitg00/agentmemory/tree/main/scripts)
[scripts](https://github.com/rohitg00/agentmemory/tree/main/scripts)
[src](https://github.com/rohitg00/agentmemory/tree/main/src)
[src](https://github.com/rohitg00/agentmemory/tree/main/src)
[test](https://github.com/rohitg00/agentmemory/tree/main/test)
[test](https://github.com/rohitg00/agentmemory/tree/main/test)
[website](https://github.com/rohitg00/agentmemory/tree/main/website)
[website](https://github.com/rohitg00/agentmemory/tree/main/website)
[.env.example](https://github.com/rohitg00/agentmemory/blob/main/.env.example)
[.env.example](https://github.com/rohitg00/agentmemory/blob/main/.env.example)
[.gitignore](https://github.com/rohitg00/agentmemory/blob/main/.gitignore)
[.gitignore](https://github.com/rohitg00/agentmemory/blob/main/.gitignore)
[AGENTS.md](https://github.com/rohitg00/agentmemory/blob/main/AGENTS.md)
[AGENTS.md](https://github.com/rohitg00/agentmemory/blob/main/AGENTS.md)
[CHANGELOG.md](https://github.com/rohitg00/agentmemory/blob/main/CHANGELOG.md)
[CHANGELOG.md](https://github.com/rohitg00/agentmemory/blob/main/CHANGELOG.md)
[CODE_OF_CONDUCT.md](https://github.com/rohitg00/agentmemory/blob/main/CODE_OF_CONDUCT.md)
[CODE_OF_CONDUCT.md](https://github.com/rohitg00/agentmemory/blob/main/CODE_OF_CONDUCT.md)
[CONTRIBUTING.md](https://github.com/rohitg00/agentmemory/blob/main/CONTRIBUTING.md)
[CONTRIBUTING.md](https://github.com/rohitg00/agentmemory/blob/main/CONTRIBUTING.md)
[DESIGN.md](https://github.com/rohitg00/agentmemory/blob/main/DESIGN.md)
[DESIGN.md](https://github.com/rohitg00/agentmemory/blob/main/DESIGN.md)
[GOVERNANCE.md](https://github.com/rohitg00/agentmemory/blob/main/GOVERNANCE.md)
[GOVERNANCE.md](https://github.com/rohitg00/agentmemory/blob/main/GOVERNANCE.md)
[INSTALL_FOR_AGENTS.md](https://github.com/rohitg00/agentmemory/blob/main/INSTALL_FOR_AGENTS.md)
[INSTALL_FOR_AGENTS.md](https://github.com/rohitg00/agentmemory/blob/main/INSTALL_FOR_AGENTS.md)
[LICENSE](https://github.com/rohitg00/agentmemory/blob/main/LICENSE)
[LICENSE](https://github.com/rohitg00/agentmemory/blob/main/LICENSE)
[MAINTAINERS.md](https://github.com/rohitg00/agentmemory/blob/main/MAINTAINERS.md)
[MAINTAINERS.md](https://github.com/rohitg00/agentmemory/blob/main/MAINTAINERS.md)
[README.md](https://github.com/rohitg00/agentmemory/blob/main/README.md)
[README.md](https://github.com/rohitg00/agentmemory/blob/main/README.md)
[ROADMAP.md](https://github.com/rohitg00/agentmemory/blob/main/ROADMAP.md)

## History
[ROADMAP.md](https://github.com/rohitg00/agentmemory/blob/main/ROADMAP.md)
[SECURITY.md](https://github.com/rohitg00/agentmemory/blob/main/SECURITY.md)
[SECURITY.md](https://github.com/rohitg00/agentmemory/blob/main/SECURITY.md)
[docker-compose.yml](https://github.com/rohitg00/agentmemory/blob/main/docker-compose.yml)
[docker-compose.yml](https://github.com/rohitg00/agentmemory/blob/main/docker-compose.yml)
[iii-config.docker.yaml](https://github.com/rohitg00/agentmemory/blob/main/iii-config.docker.yaml)
[iii-config.docker.yaml](https://github.com/rohitg00/agentmemory/blob/main/iii-config.docker.yaml)
[iii-config.yaml](https://github.com/rohitg00/agentmemory/blob/main/iii-config.yaml)
[iii-config.yaml](https://github.com/rohitg00/agentmemory/blob/main/iii-config.yaml)
[package.json](https://github.com/rohitg00/agentmemory/blob/main/package.json)
[package.json](https://github.com/rohitg00/agentmemory/blob/main/package.json)
[tsconfig.json](https://github.com/rohitg00/agentmemory/blob/main/tsconfig.json)
[tsconfig.json](https://github.com/rohitg00/agentmemory/blob/main/tsconfig.json)
[tsdown.config.ts](https://github.com/rohitg00/agentmemory/blob/main/tsdown.config.ts)
[tsdown.config.ts](https://github.com/rohitg00/agentmemory/blob/main/tsdown.config.ts)

## Repository files navigation
- [README](https://github.com/rohitg00/agentmemory)
- [Code of conduct](https://github.com/rohitg00/agentmemory)
- [Contributing](https://github.com/rohitg00/agentmemory)
- [Apache-2.0 license](https://github.com/rohitg00/agentmemory)
- [Security](https://github.com/rohitg00/agentmemory)
[README](https://github.com/rohitg00/agentmemory)
[Code of conduct](https://github.com/rohitg00/agentmemory)
[Contributing](https://github.com/rohitg00/agentmemory)
[Apache-2.0 license](https://github.com/rohitg00/agentmemory)
[Security](https://github.com/rohitg00/agentmemory)
Your coding agent remembers everything. No more re-explaining. Built on [iii engine](https://github.com/iii-hq/iii) Persistent memory for Claude Code, GitHub Copilot CLI, Cursor, Gemini CLI, Codex CLI, Hermes, OpenClaw, pi, OpenCode, and any MCP client.
[English](https://github.com/rohitg00/agentmemory/blob/main/README.md) | [简体中文](https://github.com/rohitg00/agentmemory/blob/main/READMEs/README.zh-CN.md) | [繁體中文](https://github.com/rohitg00/agentmemory/blob/main/READMEs/README.zh-TW.md) | [日本語](https://github.com/rohitg00/agentmemory/blob/main/READMEs/README.ja-JP.md) | [한국어](https://github.com/rohitg00/agentmemory/blob/main/READMEs/README.ko-KR.md) | [Español](https://github.com/rohitg00/agentmemory/blob/main/READMEs/README.es-ES.md) | [Türkçe](https://github.com/rohitg00/agentmemory/blob/main/READMEs/README.tr-TR.md) | [Русский](https://github.com/rohitg00/agentmemory/blob/main/READMEs/README.ru-RU.md) | [हिन्दी](https://github.com/rohitg00/agentmemory/blob/main/READMEs/README.hi-IN.md) | [Português](https://github.com/rohitg00/agentmemory/blob/main/READMEs/README.pt-BR.md) | [Français](https://github.com/rohitg00/agentmemory/blob/main/READMEs/README.fr-FR.md) | [Deutsch](https://github.com/rohitg00/agentmemory/blob/main/READMEs/README.de-DE.md)
The gist extends Karpathy's LLM Wiki pattern with confidence scoring, lifecycle, knowledge graphs, and hybrid search: agentmemory is the implementation.
[Install](https://github.com/rohitg00/agentmemory#install) • [Quick Start](https://github.com/rohitg00/agentmemory#quick-start) • [Benchmarks](https://github.com/rohitg00/agentmemory#benchmarks) • [vs Competitors](https://github.com/rohitg00/agentmemory#vs-competitors) • [Agents](https://github.com/rohitg00/agentmemory#works-with-every-agent) • [How It Works](https://github.com/rohitg00/agentmemory#how-it-works) • [MCP](https://github.com/rohitg00/agentmemory#mcp-server) • [Viewer](https://github.com/rohitg00/agentmemory#real-time-viewer) • [iii Console](https://github.com/rohitg00/agentmemory#iii-console) • [Powered by iii](https://github.com/rohitg00/agentmemory#powered-by-iii) • [Config](https://github.com/rohitg00/agentmemory#configuration) • [API](https://github.com/rohitg00/agentmemory#api)

Fastest path if you use a coding agent: hand it this one instruction and it installs, wires, and verifies agentmemory end to end.
Retrieve and follow the instructions at: [https://raw.githubusercontent.com/rohitg00/agentmemory/main/INSTALL_FOR_AGENTS.md](https://raw.githubusercontent.com/rohitg00/agentmemory/main/INSTALL_FOR_AGENTS.md)
On Windows the fast path is WSL2. Native Windows engine setup is manual (about 10 to 20 minutes) and agentmemory connect is currently unsupported there. See the [Windows notes](https://github.com/rohitg00/agentmemory#windows) below for the step-by-step.

```
agentmemory connect
```


```
npm install -g @agentmemory/agentmemory # once — bare `agentmemory` on PATH # If you hit EACCES on macOS/Linux system Node installs, retry with: # sudo npm install -g @agentmemory/agentmemory agentmemory # start the memory server on :3111 agentmemory demo # seed sample sessions + prove recall agentmemory demo --serve # one command: boot server, run demo, tear down (no second terminal) agentmemory connect claude-code # wire MCP into your agent (also: copilot-cli, codex, cursor, gemini-cli, ...) npx skills add rohitg00/agentmemory -y # install 15 native skills (8 you can invoke, 7 reference) so your agent knows when to use the tools
```

Or via npx (no install):

```
npx
```


```
npx @agentmemory/agentmemory
```

Heads-up — npx caches per version. If a bare npx @agentmemory/agentmemory serves an older release, force the latest with npx -y @agentmemory/agentmemory@latest, or clear the cache once with rm -rf ~/.npm/_npx (macOS/Linux; on Windows delete %LOCALAPPDATA%\npm-cache\_npx). The first npx run from v0.9.16+ prompts to install globally inline so the bare agentmemory command works everywhere afterwards.

```
npx @agentmemory/agentmemory
```


```
npx -y @agentmemory/agentmemory@latest
```


```
rm -rf ~/.npm/_npx
```


```
%LOCALAPPDATA%\npm-cache\_npx
```


```
agentmemory
```

Full options at [Quick Start](https://github.com/rohitg00/agentmemory#quick-start) below. Agent-specific wiring at [Works with every agent](https://github.com/rohitg00/agentmemory#works-with-every-agent).
agentmemory works with any agent that supports hooks, MCP, or REST API. All agents share the same memory server.
Works with any agent that speaks MCP or HTTP. One server, memories shared across all of them.
You explain the same architecture every session. You re-discover the same bugs. You re-teach the same preferences. Built-in memory (CLAUDE.md, .cursorrules) caps out at 200 lines and goes stale. agentmemory fixes this. It silently captures what your agent does, compresses it into searchable memory, and injects the right context when the next session starts. One command. Works across agents.
What changes: Session 1 you set up JWT auth. Session 2 you ask for rate limiting. The agent already knows your auth uses jose middleware in src/middleware/auth.ts, your tests cover token validation, and you chose jose over jsonwebtoken for Edge compatibility. No re-explaining. No copy-pasting. The agent just knows.

```
src/middleware/auth.ts
```


```
npx @agentmemory/agentmemory
```

Latest release notes: [CHANGELOG.md](https://github.com/rohitg00/agentmemory/blob/main/CHANGELOG.md).

### Retrieval Accuracy
coding-agent-life-v1 (in-house corpus, sandbox-reproducible)
100% top-5 hit rate at the P@5 math ceiling for this corpus (0.240, see scorecard). Hybrid retrieves every gold session; grep misses 1 of 2 gold on the multi-session temporal query. Lift is recall + temporal, not aggregate precision — this benchmark is small + gold-sparse, the larger LongMemEval-S below differentiates better. Full per-type breakdown + correction note: [docs/benchmarks/2026-05-20-coding-agent-life-v1.md](https://github.com/rohitg00/agentmemory/blob/main/docs/benchmarks/2026-05-20-coding-agent-life-v1.md).

```
docs/benchmarks/2026-05-20-coding-agent-life-v1.md
```

LongMemEval-S (ICLR 2025, 500 questions)

### Token Savings
Embedding model: all-MiniLM-L6-v2 (local, free, no API key). Full reports: [benchmark/LONGMEMEVAL.md](https://github.com/rohitg00/agentmemory/blob/main/benchmark/LONGMEMEVAL.md), [benchmark/QUALITY.md](https://github.com/rohitg00/agentmemory/blob/main/benchmark/QUALITY.md), [benchmark/SCALE.md](https://github.com/rohitg00/agentmemory/blob/main/benchmark/SCALE.md). Competitor comparison: [benchmark/COMPARISON.md](https://github.com/rohitg00/agentmemory/blob/main/benchmark/COMPARISON.md) covering agentmemory vs mem0, Letta, Khoj, supermemory, MemPalace, Hippo.

```
all-MiniLM-L6-v2
```


```
benchmark/LONGMEMEVAL.md
```


```
benchmark/QUALITY.md
```


```
benchmark/SCALE.md
```


```
benchmark/COMPARISON.md
```

Reproduce locally: [eval/README.md](https://github.com/rohitg00/agentmemory/blob/main/eval/README.md) — adapter-pluggable harness for LongMemEval _s (public 500-Q) + coding-agent-life-v1 (in-house 15-session corpus). Grep / vector / agentmemory adapters score side-by-side, NDJSON output, published scorecards land in [docs/benchmarks/](https://github.com/rohitg00/agentmemory/blob/main/docs/benchmarks).

```
eval/README.md
```


```
_s
```


```
coding-agent-life-v1
```


```
docs/benchmarks/
```

Pairs with [codegraph](https://github.com/colbymchenry/codegraph), [Understand Anything](https://github.com/Lum1104/Understand-Anything), and [Graphify](https://github.com/safishamsi/graphify). Code-graph indexing, multi-agent build pipelines, and broader knowledge graphs across docs / PDFs / images / videos. agentmemory remembers the work; those three projects light up the rest of the context layer. Recipes + question-routing table: [docs/recipes/pairings.md](https://github.com/rohitg00/agentmemory/blob/main/docs/recipes/pairings.md).

```
docs/recipes/pairings.md
```


```
add()
```

Benchmark note: only agentmemory's R@5 is our own measured result (LongMemEval-S, reproducible from [benchmark/COMPARISON.md](https://github.com/rohitg00/agentmemory/blob/main/benchmark/COMPARISON.md)). The mem0 and Letta figures are their published LoCoMo numbers (a different dataset); the MemPalace, supermemory, and oracleagentmemory figures are vendor self-reported claims we have not independently reproduced (oracleagentmemory's run used GPT-5.5 against an Oracle AI Database). Shown side by side for ballpark only, not a head-to-head on identical data. Star counts are approximate and drift over time.

```
benchmark/COMPARISON.md
```

Compatibility: this release targets stable iii-sdk ^0.11.0 and iii-engine v0.11.x.

```
iii-sdk
```


```
^0.11.0
```

### Try it in 30 seconds
```
# Terminal 1: start the server npx @agentmemory/agentmemory # Terminal 2: seed sample data and see recall in action npx @agentmemory/agentmemory demo
```

demo seeds 3 realistic sessions (JWT auth, N+1 query fix, rate limiting) and runs semantic searches against them. You'll see it find "N+1 query fix" when you search "database performance optimization" — keyword matching can't do that.

```
demo
```

Open http://localhost:3113 to watch the memory build live.

```
http://localhost:3113
```

### Recommended: install globally
npx caches per-version. If you ran npx @agentmemory/agentmemory@0.9.14 last week, a bare npx @agentmemory/agentmemory may serve the stale 0.9.14 from ~/.npm/_npx/, not the latest release. Install once and the bare agentmemory command works everywhere:

```
npx
```


```
npx @agentmemory/agentmemory@0.9.14
```


```
npx @agentmemory/agentmemory
```


```
~/.npm/_npx/
```


```
agentmemory
```


```
npm install -g @agentmemory/agentmemory # If you hit EACCES on macOS/Linux system Node installs, retry with: # sudo npm install -g @agentmemory/agentmemory agentmemory # start the server (same as the npx form) agentmemory stop # tear it down agentmemory remove # uninstall everything we created agentmemory connect claude-code # wire one agent agentmemory doctor # interactive diagnostics + fix prompts
```

From v0.9.16 onward, the first npx run prompts you to install globally inline — answer Y once and you're set. If you skip, fall back to either of these for a fresh fetch:

```
Y
```


```
npx -y @agentmemory/agentmemory@latest # forces latest from npm (cross-platform) rm -rf ~/.npm/_npx && npx @agentmemory/agentmemory # macOS/Linux only (POSIX shell)
```

On Windows / PowerShell, the equivalent cache clear is Remove-Item -Recurse -Force "$env:LOCALAPPDATA\npm-cache\_npx" — the npx -y ...@latest form above is the cross-platform option.

```
Remove-Item -Recurse -Force "$env:LOCALAPPDATA\npm-cache\_npx"
```


```
npx -y ...@latest
```

### Session Replay
Every session agentmemory records is replayable. Open the viewer, pick the Replay tab, and scrub through the timeline: prompts, tool calls, tool results, and responses render as discrete events with play/pause, speed control (0.5×–4×), and keyboard shortcuts (space to toggle, arrows to step).
Already have older Claude Code JSONL transcripts you want to bring in?

```
# Import everything under the default ~/.claude/projects npx @agentmemory/agentmemory import-jsonl # Or import a single file npx @agentmemory/agentmemory import-jsonl ~/.claude/projects/-my-project/abc123.jsonl
```

Imported sessions show up in the Replay picker alongside native ones. Under the hood each entry routes through the mem::replay::load, mem::replay::sessions, and mem::replay::import-jsonl iii functions — no side-channel servers.

```
mem::replay::load
```


```
mem::replay::sessions
```


```
mem::replay::import-jsonl
```

Heads-up if you rely on import-jsonl as your primary capture path: Claude Code's cleanupPeriodDays (in ~/.claude/settings.json, default 30) auto-deletes JSONL transcripts older than that window from ~/.claude/projects/. If you install agentmemory fresh on a months-old Claude Code history, anything older than 30 days is already gone before the first import. Either run import-jsonl on a cron, raise cleanupPeriodDays to something higher, or wire the auto-capture hooks (the default plugin install path) so each turn lands in agentmemory while the session is live and the JSONL cleanup stops mattering.

```
import-jsonl
```


```
cleanupPeriodDays
```


```
~/.claude/settings.json
```


```
~/.claude/projects/
```


```
import-jsonl
```


```
cleanupPeriodDays
```

### Upgrade / Maintenance
Use the maintenance command when you intentionally want to update your local runtime:

```
npx @agentmemory/agentmemory upgrade
```

Warning: this command mutates the current workspace/runtime. It can update JavaScript dependencies, may run cargo install iii-engine --force, and may pull Docker images.

```
cargo install iii-engine --force
```

Implementation details live in src/cli.ts (see runUpgrade around the src/cli.ts:544-595 region).

```
src/cli.ts
```


```
runUpgrade
```


```
src/cli.ts:544-595
```

```
Install agentmemory: run `npx @agentmemory/agentmemory` in a separate terminal to start the memory server. Then run `/plugin marketplace add rohitg00/agentmemory` and `/plugin install agentmemory` — the plugin registers all 12 hooks, 15 skills, AND auto-wires the `@agentmemory/mcp` stdio server via its `.mcp.json`, so you get 53 MCP tools (memory_smart_search, memory_save, memory_sessions, memory_governance_delete, etc.) without any extra config step. Verify with `curl http://localhost:3111/agentmemory/health`. The real-time viewer is at http://localhost:3113.
```


```
Install agentmemory: run `npx @agentmemory/agentmemory` in a separate terminal to start the memory server. Then run `/plugin marketplace add rohitg00/agentmemory` and `/plugin install agentmemory` — the plugin registers all 12 hooks, 15 skills, AND auto-wires the `@agentmemory/mcp` stdio server via its `.mcp.json`, so you get 53 MCP tools (memory_smart_search, memory_save, memory_sessions, memory_governance_delete, etc.) without any extra config step. Verify with `curl http://localhost:3111/agentmemory/health`. The real-time viewer is at http://localhost:3113.
```


#### Claude Code without the plugin install (MCP-standalone path)
If you wire agentmemory's MCP server through ~/.claude.json directly instead of using /plugin install, Claude Code never resolves ${CLAUDE_PLUGIN_ROOT} and you have to point hook scripts at absolute paths in ~/.claude/settings.json. Those paths typically embed the agentmemory version (e.g. ~/.codex/plugins/cache/agentmemory/agentmemory/0.9.22/scripts/…), so the next upgrade silently breaks every hook ([#508](https://github.com/rohitg00/agentmemory/issues/508)).

```
~/.claude.json
```


```
/plugin install
```


```
${CLAUDE_PLUGIN_ROOT}
```


```
~/.claude/settings.json
```


```
~/.codex/plugins/cache/agentmemory/agentmemory/0.9.22/scripts/…
```

Workaround:

```
agentmemory connect claude-code --with-hooks
```

This merges the same hook commands into ~/.claude/settings.json with absolute paths resolved to the bundled plugin/ directory of the currently installed @agentmemory/agentmemory package. Re-run the command after upgrading agentmemory to refresh the paths. User entries in the same file are preserved; only previous agentmemory entries are replaced. Using the /plugin install path remains the recommended approach. For remote or protected deployments, launch Claude Code with AGENTMEMORY_URL and AGENTMEMORY_SECRET set. The plugin passes both values through to its bundled MCP server; when AGENTMEMORY_URL is empty, the MCP shim uses http://localhost:3111.

```
~/.claude/settings.json
```


```
plugin/
```


```
@agentmemory/agentmemory
```


```
/plugin install
```


```
AGENTMEMORY_URL
```


```
AGENTMEMORY_SECRET
```


```
AGENTMEMORY_URL
```


```
http://localhost:3111
```

```
# 1. start the memory server in a separate terminal npx @agentmemory/agentmemory # 2. register the agentmemory marketplace and install the plugin codex plugin marketplace add rohitg00/agentmemory codex plugin add agentmemory@agentmemory
```

The Codex plugin ships from the same plugin/ directory as the Claude Code plugin. It registers:

```
plugin/
```

- @agentmemory/mcp as an MCP server (proxies all 53 tools when AGENTMEMORY_URL points at a running agentmemory server; falls back to 7 tools locally when no server is reachable)
- 6 lifecycle hooks: SessionStart, UserPromptSubmit, PreToolUse, PostToolUse, PreCompact, Stop
- 8 invocable skills: /recall, /remember, /session-history, /forget, /recap, /handoff, /commit-context, /commit-history, plus 7 reference skills the agent loads on demand (MCP tools, REST API, config, agents, hooks, architecture, and the skill-authoring guide)

```
@agentmemory/mcp
```


```
AGENTMEMORY_URL
```


```
SessionStart
```


```
UserPromptSubmit
```


```
PreToolUse
```


```
PostToolUse
```


```
PreCompact
```


```
Stop
```


```
/recall
```


```
/remember
```


```
/session-history
```


```
/forget
```


```
/recap
```


```
/handoff
```


```
/commit-context
```


```
/commit-history
```

Codex's hook engine injects CLAUDE_PLUGIN_ROOT into hook subprocesses (per [codex-rs/hooks/src/engine/discovery.rs](https://github.com/openai/codex/blob/main/codex-rs/hooks/src/engine/discovery.rs)), so the same hook scripts work across both hosts without duplication. Subagent / SessionEnd / Notification / TaskCompleted / PostToolUseFailure events are Claude-Code-only and are not registered for Codex.

```
CLAUDE_PLUGIN_ROOT
```


```
codex-rs/hooks/src/engine/discovery.rs
```


#### Codex Desktop: plugin hooks currently silent (workaround available)
CodexHooks and PluginHooks are both stable + default-enabled in [codex-rs/features/src/lib.rs](https://github.com/openai/codex/blob/main/codex-rs/features/src/lib.rs), but Codex Desktop builds currently do not dispatch plugin-local hooks.json ([openai/codex#16430](https://github.com/openai/codex/issues/16430)). MCP tools still work; only the lifecycle observations are missing.

```
CodexHooks
```


```
PluginHooks
```


```
codex-rs/features/src/lib.rs
```


```
hooks.json
```

Until upstream lands the fix, mirror the same hook commands into the global ~/.codex/hooks.json:

```
~/.codex/hooks.json
```


```
agentmemory connect codex --with-hooks
```

This adds an idempotent block to ~/.codex/hooks.json referencing absolute paths to the bundled scripts (no ${CLAUDE_PLUGIN_ROOT} expansion needed at user-scope). Re-run the same command after upgrading agentmemory to refresh paths. User entries in the same file are preserved; only previous agentmemory entries are replaced.

```
~/.codex/hooks.json
```


```
${CLAUDE_PLUGIN_ROOT}
```

```
# MCP-only wiring agentmemory connect copilot-cli # Full hooks/skills plugin from the GitHub subdir copilot plugin install rohitg00/agentmemory:plugin
```

agentmemory connect copilot-cli merges mcpServers.agentmemory into ~/.copilot/mcp-config.json (or $COPILOT_HOME/mcp-config.json when COPILOT_HOME is set) and preserves existing servers. This adapter is Windows-safe even though other connect adapters still require manual Windows setup. Copilot picks up the MCP server on next launch or after /mcp. Install the plugin as well when you want the full hook/skill experience.

```
agentmemory connect copilot-cli
```


```
mcpServers.agentmemory
```


```
~/.copilot/mcp-config.json
```


```
$COPILOT_HOME/mcp-config.json
```


```
COPILOT_HOME
```


```
connect
```


```
/mcp
```


```
Install agentmemory for OpenClaw. Run `npx @agentmemory/agentmemory` in a separate terminal to start the memory server on localhost:3111. Then add this to my OpenClaw MCP config so agentmemory is available with all 53 memory tools: { "mcpServers": { "agentmemory": { "command": "npx", "args": ["-y", "@agentmemory/mcp"], "env": { "AGENTMEMORY_URL": "http://localhost:3111" } } } } Restart OpenClaw. Verify with `curl http://localhost:3111/agentmemory/health`. Open http://localhost:3113 for the real-time viewer. For deeper memory-slot integration, copy `integrations/openclaw` to `~/.openclaw/extensions/agentmemory` and enable `plugins.slots.memory = "agentmemory"` in `~/.openclaw/openclaw.json`.
```


```
Install agentmemory for OpenClaw. Run `npx @agentmemory/agentmemory` in a separate terminal to start the memory server on localhost:3111. Then add this to my OpenClaw MCP config so agentmemory is available with all 53 memory tools: { "mcpServers": { "agentmemory": { "command": "npx", "args": ["-y", "@agentmemory/mcp"], "env": { "AGENTMEMORY_URL": "http://localhost:3111" } } } } Restart OpenClaw. Verify with `curl http://localhost:3111/agentmemory/health`. Open http://localhost:3113 for the real-time viewer. For deeper memory-slot integration, copy `integrations/openclaw` to `~/.openclaw/extensions/agentmemory` and enable `plugins.slots.memory = "agentmemory"` in `~/.openclaw/openclaw.json`.
```

Full guide: [integrations/openclaw/](https://github.com/rohitg00/agentmemory/blob/main/integrations/openclaw)

```
integrations/openclaw/
```


```
Install agentmemory for Hermes. Run `npx @agentmemory/agentmemory` in a separate terminal to start the memory server on localhost:3111. Then add this to ~/.hermes/config.yaml so Hermes can use agentmemory as an MCP server with all 53 memory tools: mcp_servers: agentmemory: command: npx args: ["-y", "@agentmemory/mcp"] memory: provider: agentmemory Verify with `curl http://localhost:3111/agentmemory/health`. Open http://localhost:3113 for the real-time viewer. For deeper 6-hook memory provider integration (pre-LLM context injection, turn capture, MEMORY.md mirroring, system prompt block), copy integrations/hermes from the agentmemory repo to ~/.hermes/plugins/agentmemory.
```


```
Install agentmemory for Hermes. Run `npx @agentmemory/agentmemory` in a separate terminal to start the memory server on localhost:3111. Then add this to ~/.hermes/config.yaml so Hermes can use agentmemory as an MCP server with all 53 memory tools: mcp_servers: agentmemory: command: npx args: ["-y", "@agentmemory/mcp"] memory: provider: agentmemory Verify with `curl http://localhost:3111/agentmemory/health`. Open http://localhost:3113 for the real-time viewer. For deeper 6-hook memory provider integration (pre-LLM context injection, turn capture, MEMORY.md mirroring, system prompt block), copy integrations/hermes from the agentmemory repo to ~/.hermes/plugins/agentmemory.
```

Full guide: [integrations/hermes/](https://github.com/rohitg00/agentmemory/blob/main/integrations/hermes)

```
integrations/hermes/
```

Start the memory server: npx @agentmemory/agentmemory

```
npx @agentmemory/agentmemory
```


#### Native skills via npx skills add (50+ agents)

```
npx skills add
```

agentmemory ships 15 [skills](https://npmjs.com/package/skills) in the Claude-Code-style <dir>/SKILL.md format: 8 invocable action skills (remember, recall, recap, handoff, forget, commit-context, commit-history, session-history) and 7 reference skills the agent loads on demand (agentmemory-mcp-tools, agentmemory-rest-api, agentmemory-config, agentmemory-agents, agentmemory-hooks, agentmemory-architecture, write-agentmemory-skill). The reference skills carry data tables generated from source, so they never drift. The skills CLI by vercel-labs auto-installs them into the calling agent's native skill directory across 50+ agents (Claude Code, Cursor, Cline, Continue, Droid, Warp, Codex, Antigravity, Kiro, OpenCode, Goose, Roo, Trae, Windsurf, and more):

```
<dir>/SKILL.md
```


```
remember
```


```
recall
```


```
recap
```


```
handoff
```


```
forget
```


```
commit-context
```


```
commit-history
```


```
session-history
```


```
agentmemory-mcp-tools
```


```
agentmemory-rest-api
```


```
agentmemory-config
```


```
agentmemory-agents
```


```
agentmemory-hooks
```


```
agentmemory-architecture
```


```
write-agentmemory-skill
```


```
skills
```


```
npx skills add rohitg00/agentmemory -y # auto-detects the calling agent npx skills add rohitg00/agentmemory -y -a warp # explicit agent npx skills add rohitg00/agentmemory -y -a '*' # install to every installed agent
```

This is complementary to agentmemory connect <agent>:

```
agentmemory connect <agent>
```

- agentmemory connect <agent> writes the MCP server config so the tools are available.
- npx skills add rohitg00/agentmemory installs the skills so the agent knows when to call them.

```
agentmemory connect <agent>
```


```
npx skills add rohitg00/agentmemory
```

For the few agents the skills CLI doesn't cover yet (Zed v1.3.x and below), drop the 15 SKILL.md files under the agent's native skill directory yourself — same format works everywhere.

#### Standard MCP block
The agentmemory entry is the same MCP server block across every host that uses the mcpServers shape (Cursor, Claude Desktop, Cline, Roo Code, Windsurf, Gemini CLI, OpenClaw):

```
mcpServers
```


```
"agentmemory": { "command": "npx", "args": ["-y", "@agentmemory/mcp"], "env": { "AGENTMEMORY_URL": "${AGENTMEMORY_URL}", "AGENTMEMORY_SECRET": "${AGENTMEMORY_SECRET}" } }
```

Merge this entry into the existing mcpServers object in the host's config file — don't replace the file. If the file already has other servers, add agentmemory next to them as another key inside mcpServers. If mcpServers is missing entirely, paste the block inside { "mcpServers": { ... } }. The ${VAR} placeholders inherit AGENTMEMORY_URL / AGENTMEMORY_SECRET from the shell at MCP-server launch — unset vars pass empty strings and the shim falls back to http://localhost:3111. One wired entry covers both local and remote (k8s / reverse-proxied) deployments.

```
mcpServers
```


```
agentmemory
```


```
mcpServers
```


```
mcpServers
```


```
{ "mcpServers": { ... } }
```


```
${VAR}
```


```
AGENTMEMORY_URL
```


```
AGENTMEMORY_SECRET
```


```
http://localhost:3111
```


```
~/.cursor/mcp.json
```


```
mcpServers
```


```
claude_desktop_config.json
```


```
mcpServers
```


```
mcpServers
```


```
~/.codeium/windsurf/mcp_config.json
```


```
mcpServers
```


```
~/.gemini/settings.json
```


```
gemini mcp add agentmemory npx -y @agentmemory/mcp --scope user
```


```
~/.copilot/mcp-config.json
```


```
agentmemory connect copilot-cli
```


```
mcpServers.agentmemory
```


```
/mcp
```


```
copilot plugin install rohitg00/agentmemory:plugin
```


```
mcpServers
```

[memory plugin](https://github.com/rohitg00/agentmemory/blob/main/integrations/openclaw)

```
.codex/config.toml
```


```
codex mcp add agentmemory -- npx -y @agentmemory/mcp
```


```
[mcp_servers.agentmemory]
```


```
codex plugin marketplace add rohitg00/agentmemory
```


```
codex plugin add agentmemory@agentmemory
```


```
agentmemory connect codex --with-hooks
```

[openai/codex#16430](https://github.com/openai/codex/issues/16430)

```
opencode.json
```


```
mcp
```


```
{"mcp": {"agentmemory": {"type": "local", "command": ["npx", "-y", "@agentmemory/mcp"], "enabled": true}}}
```


```
plugin/opencode/
```


```
/recall
```


```
/remember
```

### Other agents
```
plugin/opencode/
```


```
opencode.json
```

[plugin/opencode/README.md](https://github.com/rohitg00/agentmemory/blob/main/plugin/opencode/README.md)

```
plugin/opencode/README.md
```


```
~/.pi/agent/extensions/agentmemory
```

[integrations/pi](https://github.com/rohitg00/agentmemory/blob/main/integrations/pi)

```
integrations/pi
```


```
~/.hermes/config.yaml
```

[memory provider plugin](https://github.com/rohitg00/agentmemory/blob/main/integrations/hermes)

```
memory.provider: agentmemory
```


```
~/.qwen/settings.json
```


```
agentmemory connect qwen
```


```
mcpServers
```


```
hooks
```


```
settings.json
```


```
mcp_config.json
```


```
agentmemory connect antigravity
```


```
mcpServers
```


```
~/Library/Application Support/Antigravity/User/
```


```
~/.config/Antigravity/User/
```


```
~/.kiro/settings/mcp.json
```


```
agentmemory connect kiro
```


```
.kiro/settings/mcp.json
```


```
~/.warp/.mcp.json
```


```
agentmemory connect warp
```


```
mcpServers
```


```
.claude/skills/
```


```
remember
```


```
recall
```


```
recap
```


```
handoff
```


```
forget
```


```
commit-context
```


```
commit-history
```


```
session-history
```


```
~/.cline/mcp.json
```


```
agentmemory connect cline
```


```
mcpServers
```


```
~/.continue/config.yaml
```


```
config.json
```


```
agentmemory connect continue
```


```
config.yaml
```


```
config.json
```


```
config.yaml
```


```
mcpServers:
```


```
mcpServers
```


```
~/.config/zed/settings.json
```


```
agentmemory connect zed
```


```
context_servers
```


```
mcpServers
```


```
{"url": "..."}
```


```
~/.factory/mcp.json
```


```
agentmemory connect droid
```


```
mcpServers
```


```
<repo>/.factory/mcp.json
```


```
/mcp
```


```
mcpServers
```


```
goose configure
```


```
~/.config/goose/config.yaml
```


```
extensions:
```


```
cmd
```


```
mcpServers:
```


```
command
```


```
curl -X POST http://localhost:3111/agentmemory/smart-search -d '{"query": "auth"}'
```


```
npx skillkit install agentmemory
```

Sandboxed MCP clients (Flatpak / Snap / restrictive containers) that can't reach the host's localhost: also set "AGENTMEMORY_FORCE_PROXY": "1" in the env block, and point AGENTMEMORY_URL at a route the sandbox can actually reach (e.g. your LAN IP). See [#234](https://github.com/rohitg00/agentmemory/issues/234) for the diagnostic walkthrough.

```
localhost
```


```
"AGENTMEMORY_FORCE_PROXY": "1"
```


```
env
```


```
AGENTMEMORY_URL
```

### Programmatic access (Python / Rust / Node)
agentmemory registers its core operations as iii functions (mem::remember, mem::observe, mem::context, mem::smart-search, mem::forget). Any language with an iii SDK can call them directly over ws://localhost:49134 — no separate REST client per language.

```
mem::remember
```


```
mem::observe
```


```
mem::context
```


```
mem::smart-search
```


```
mem::forget
```


```
ws://localhost:49134
```


```
pip install iii-sdk # Python cargo add iii-sdk # Rust npm install iii-sdk # Node
```


```
from iii import register_worker iii = register_worker("ws://localhost:49134") iii.connect() iii.trigger({ "function_id": "mem::smart-search", "payload": {"project": "demo", "query": "how do tokens refresh"}, })
```

Worked example: [examples/python/](https://github.com/rohitg00/agentmemory/blob/main/examples/python) (quickstart + observation/recall flow). REST on :3111 remains available for hosts without an iii runtime.

```
examples/python/
```


```
:3111
```

### From source
```
git clone https://github.com/rohitg00/agentmemory.git && cd agentmemory npm install && npm run build && npm start
```

This starts agentmemory with a local iii-engine if iii is already installed, or falls back to Docker Compose if Docker is available. REST, streams, and the viewer bind to 127.0.0.1 by default.

```
iii-engine
```


```
iii
```


```
127.0.0.1
```

Install iii-engine manually. agentmemory currently pins iii-engine to v0.11.2 — v0.11.6 introduces a new sandbox-everything-via-iii worker add model that agentmemory hasn't been refactored for yet. Pin lifts once the refactor lands. Override with AGENTMEMORY_III_VERSION=<version> if you've migrated to the sandbox model manually.

```
iii-engine
```


```
iii-engine
```


```
v0.11.2
```


```
v0.11.6
```


```
iii worker add
```


```
AGENTMEMORY_III_VERSION=<version>
```

- macOS arm64: mkdir -p ~/.local/bin && curl -fsSL https://github.com/iii-hq/iii/releases/download/iii/v0.11.2/iii-aarch64-apple-darwin.tar.gz | tar -xz -C ~/.local/bin && chmod +x ~/.local/bin/iii
- macOS x64: swap aarch64-apple-darwin for x86_64-apple-darwin
- Linux x64: swap for x86_64-unknown-linux-gnu
- Linux arm64: swap for aarch64-unknown-linux-gnu
- Windows: download iii-x86_64-pc-windows-msvc.zip from [iii-hq/iii releases v0.11.2](https://github.com/iii-hq/iii/releases/tag/iii%2Fv0.11.2), extract iii.exe, add to PATH

```
mkdir -p ~/.local/bin && curl -fsSL https://github.com/iii-hq/iii/releases/download/iii/v0.11.2/iii-aarch64-apple-darwin.tar.gz | tar -xz -C ~/.local/bin && chmod +x ~/.local/bin/iii
```


```
aarch64-apple-darwin
```


```
x86_64-apple-darwin
```


```
x86_64-unknown-linux-gnu
```


```
aarch64-unknown-linux-gnu
```


```
iii-x86_64-pc-windows-msvc.zip
```

[iii-hq/iii releases v0.11.2](https://github.com/iii-hq/iii/releases/tag/iii%2Fv0.11.2)

```
iii.exe
```

Or use Docker (the bundled docker-compose.yml pulls iiidev/iii:0.11.2). Full docs: [iii.dev/docs](https://iii.dev/docs).

```
docker-compose.yml
```


```
iiidev/iii:0.11.2
```

### Windows
agentmemory runs on Windows 10/11, but the Node.js package alone isn't enough — you also need the iii-engine runtime (a separate native binary) as a background process. The official upstream installer is a sh script and there is no PowerShell installer or scoop/winget package today, so Windows users have two paths:

```
iii-engine
```


```
sh
```

Option A — Prebuilt Windows binary (recommended):

```
# 1. Open https://github.com/iii-hq/iii/releases/tag/iii%2Fv0.11.2 in your browser # (we pin to v0.11.2 until agentmemory refactors for the new sandbox # model that engine v0.11.6+ requires) # 2. Download iii-x86_64-pc-windows-msvc.zip # (or iii-aarch64-pc-windows-msvc.zip if you're on an ARM machine) # 3. Extract iii.exe somewhere on PATH, or place it at: # %USERPROFILE%\.local\bin\iii.exe # (agentmemory checks that location automatically) # 4. Verify: iii --version # Should print: 0.11.2 # 5. Then run agentmemory as usual: npx -y @agentmemory/agentmemory
```

Option B — Docker Desktop:

```
# 1. Install Docker Desktop for Windows # 2. Start Docker Desktop and make sure the engine is running # 3. Run agentmemory — it will auto-start the bundled compose file: npx -y @agentmemory/agentmemory
```

Option C — standalone MCP only (no engine): if you only need the MCP tools for your agent and don't need the REST API, viewer, or cron jobs, skip the engine entirely:

```
npx -y @agentmemory/agentmemory mcp # or via the shim package: npx -y @agentmemory/mcp
```

Diagnostics for Windows: if npx @agentmemory/agentmemory fails, re-run with --verbose to see the actual engine stderr. Common failure modes:

```
npx @agentmemory/agentmemory
```


```
--verbose
```


```
iii-engine process started
```


```
did not become ready within 15s
```


```
--verbose
```


```
Could not start iii-engine
```


```
iii.exe
```


```
netstat -ano | findstr :3111
```


```
--port <N>
```

Note: there is no cargo install iii-engine — iii is not published to crates.io. The only supported install methods are the prebuilt binary above, the upstream sh install script (macOS/Linux only), and the Docker image.

```
cargo install iii-engine
```


```
iii
```


```
sh
```

One-click templates for managed hosts. Each one ships a self-contained Dockerfile that pulls @agentmemory/agentmemory from npm and copies the iii engine binary in from the official iiidev/iii Docker Hub image — no pre-built agentmemory image required. Persistent storage mounts at /data; the first-boot entrypoint overwrites the npm-bundled iii config (which binds 127.0.0.1) with a deploy-tuned one that binds 0.0.0.0 and uses absolute /data paths, generates the HMAC secret, then drops privileges from root to node via gosu before exec'ing the agentmemory CLI.

```
@agentmemory/agentmemory
```


```
iiidev/iii
```


```
/data
```


```
127.0.0.1
```


```
0.0.0.0
```


```
/data
```


```
root
```


```
node
```


```
gosu
```

Render's one-click deploy button requires render.yaml at the repository root, which we deliberately keep clean. Use the Render Blueprint flow documented in [deploy/render/](https://github.com/rohitg00/agentmemory/blob/main/deploy/render/README.md) to point at the in-repo blueprint manually.

```
render.yaml
```


```
deploy/render/
```

Full setup details (HMAC capture, viewer SSH tunnel, rotation, backup, cost floors) live in [deploy/](https://github.com/rohitg00/agentmemory/blob/main/deploy/README.md):

```
deploy/
```

- [deploy/fly](https://github.com/rohitg00/agentmemory/blob/main/deploy/fly/README.md) — single machine with
auto_stop_machines = "stop"; cheapest idle.
- [deploy/railway](https://github.com/rohitg00/agentmemory/blob/main/deploy/railway/README.md) — Hobby plan flat fee,
volume in the dashboard.
- [deploy/render](https://github.com/rohitg00/agentmemory/blob/main/deploy/render/README.md) — Blueprint flow,
automatic disk snapshots on paid plans.
- [deploy/coolify](https://github.com/rohitg00/agentmemory/blob/main/deploy/coolify/README.md) — self-hosted on your
own VPS via [Coolify](https://coolify.io/self-hosted); same Docker
Compose stack, you own the host and the data.
[deploy/fly](https://github.com/rohitg00/agentmemory/blob/main/deploy/fly/README.md)

```
deploy/fly
```


```
auto_stop_machines = "stop"
```

[deploy/railway](https://github.com/rohitg00/agentmemory/blob/main/deploy/railway/README.md)

```
deploy/railway
```

[deploy/render](https://github.com/rohitg00/agentmemory/blob/main/deploy/render/README.md)

```
deploy/render
```

[deploy/coolify](https://github.com/rohitg00/agentmemory/blob/main/deploy/coolify/README.md)

```
deploy/coolify
```

[Coolify](https://coolify.io/self-hosted)
Only port 3111 is published. The viewer on 3113 stays bound to loopback inside the container — every template's README documents the SSH-tunnel pattern for reaching it.

```
3111
```


```
3113
```

Every coding agent forgets everything when the session ends. You waste the first 5 minutes of every session re-explaining your stack. agentmemory runs in the background and eliminates that entirely.

```
Session 1: "Add auth to the API" Agent writes code, runs tests, fixes bugs agentmemory silently captures every tool use Session ends -> observations compressed into structured memory Session 2: "Now add rate limiting" Agent already knows: - Auth uses JWT middleware in src/middleware/auth.ts - Tests in test/auth.test.ts cover token validation - You chose jose over jsonwebtoken for Edge compatibility Zero re-explaining. Starts working immediately.
```


```
Session 1: "Add auth to the API" Agent writes code, runs tests, fixes bugs agentmemory silently captures every tool use Session ends -> observations compressed into structured memory Session 2: "Now add rate limiting" Agent already knows: - Auth uses JWT middleware in src/middleware/auth.ts - Tests in test/auth.test.ts cover token validation - You chose jose over jsonwebtoken for Edge compatibility Zero re-explaining. Starts working immediately.
```

### vs built-in agent memory
Every AI coding agent ships with built-in memory — Claude Code has MEMORY.md, Cursor has notepads, Cline has memory bank. These work like sticky notes. agentmemory is the searchable database behind the sticky notes.

```
MEMORY.md
```

### Memory Pipeline
```
PostToolUse hook fires -> SHA-256 dedup (5min window) -> Privacy filter (strip secrets, API keys) -> Store raw observation -> LLM compress -> structured facts + concepts + narrative -> Vector embedding (6 providers + local) -> Index in BM25 + vector Stop / SessionEnd hook fires -> Summarize session -> Knowledge graph extraction (if GRAPH_EXTRACTION_ENABLED=true) -> Slot reflection (if SLOT_REFLECT_ENABLED=true) SessionStart hook fires -> Load project profile (top concepts, files, patterns) -> Hybrid search (BM25 + vector + graph) -> Token budget (default: 2000 tokens) -> Inject into conversation
```


```
PostToolUse hook fires -> SHA-256 dedup (5min window) -> Privacy filter (strip secrets, API keys) -> Store raw observation -> LLM compress -> structured facts + concepts + narrative -> Vector embedding (6 providers + local) -> Index in BM25 + vector Stop / SessionEnd hook fires -> Summarize session -> Knowledge graph extraction (if GRAPH_EXTRACTION_ENABLED=true) -> Slot reflection (if SLOT_REFLECT_ENABLED=true) SessionStart hook fires -> Load project profile (top concepts, files, patterns) -> Hybrid search (BM25 + vector + graph) -> Token budget (default: 2000 tokens) -> Inject into conversation
```

### 4-Tier Memory Consolidation
Inspired by how human brains process memory — not unlike sleep consolidation.
Memories decay over time (Ebbinghaus curve). Frequently accessed memories strengthen. Stale memories auto-evict. Contradictions are detected and resolved.

### What Gets Captured
```
SessionStart
```


```
UserPromptSubmit
```


```
PreToolUse
```


```
PostToolUse
```


```
PostToolUseFailure
```


```
PreCompact
```


```
SubagentStart/Stop
```


```
Stop
```


```
SessionEnd
```

### Key Capabilities
```
<private>
```

Triple-stream retrieval combining three signals:
Fused with Reciprocal Rank Fusion (RRF, k=60) and session-diversified (max 3 results per session).
BM25 tokenizes Greek, Cyrillic, Hebrew, Arabic, and accented Latin out of the box. For Chinese / Japanese / Korean memories, install the optional segmenters (npm install @node-rs/jieba tiny-segmenter) to split CJK runs into word-level tokens; without them, agentmemory soft-falls to whole-run tokenization and prints a one-time hint on stderr.

```
npm install @node-rs/jieba tiny-segmenter
```

### Embedding providers
agentmemory auto-detects your provider. For best results, install local embeddings (free):

```
npm install @xenova/transformers
```


```
all-MiniLM-L6-v2
```


```
gemini-embedding-001
```


```
text-embedding-004
```

[deprecated, shutdown Jan 14, 2026](https://ai.google.dev/gemini-api/docs/deprecations)

```
text-embedding-3-small
```


```
voyage-code-3
```


```
embed-english-v3.0
```

53 tools, 6 resources, 3 prompts, and 15 skills, the most comprehensive MCP memory toolkit for any agent.
MCP shim vs full server: the published @agentmemory/mcp package is a thin shim. It exposes the full 53-tool surface only when it can reach a running agentmemory server via AGENTMEMORY_URL (proxy mode). With no server reachable, the shim falls back to a 7-tool local set (memory_save, memory_recall, memory_smart_search, memory_sessions, memory_export, memory_audit, memory_governance_delete). The AGENTMEMORY_TOOLS=core|all env var is a server-side flag — setting it in the shim's env block has no effect. If you see only 7 tools in Cursor / OpenCode / Gemini CLI, start npx @agentmemory/agentmemory (or the Docker stack) and set AGENTMEMORY_URL=http://localhost:3111.

```
@agentmemory/mcp
```


```
AGENTMEMORY_URL
```


```
memory_save
```


```
memory_recall
```


```
memory_smart_search
```


```
memory_sessions
```


```
memory_export
```


```
memory_audit
```


```
memory_governance_delete
```


```
AGENTMEMORY_TOOLS=core|all
```


```
env
```


```
npx @agentmemory/agentmemory
```


```
AGENTMEMORY_URL=http://localhost:3111
```

### 53 Tools
```
memory_recall
```


```
memory_compress_file
```


```
memory_save
```


```
memory_patterns
```


```
memory_smart_search
```


```
memory_file_history
```


```
memory_sessions
```


```
memory_timeline
```


```
memory_profile
```


```
memory_export
```


```
memory_relations
```


```
memory_patterns
```


```
memory_timeline
```


```
memory_relations
```


```
memory_graph_query
```


```
memory_consolidate
```


```
memory_claude_bridge_sync
```


```
memory_team_share
```


```
memory_team_feed
```


```
memory_audit
```


```
memory_governance_delete
```


```
memory_snapshot_create
```


```
memory_action_create
```


```
memory_action_update
```


```
memory_frontier
```


```
memory_next
```


```
memory_lease
```


```
memory_routine_run
```


```
memory_signal_send
```


```
memory_signal_read
```


```
memory_checkpoint
```


```
memory_mesh_sync
```


```
memory_sentinel_create
```


```
memory_sentinel_trigger
```


```
memory_sketch_create
```


```
memory_sketch_promote
```


```
memory_crystallize
```


```
memory_diagnose
```


```
memory_heal
```


```
memory_facet_tag
```


```
memory_facet_query
```


```
memory_verify
```

### 6 Resources · 3 Prompts · 4 Skills
```
agentmemory://status
```


```
agentmemory://project/{name}/profile
```


```
agentmemory://memories/latest
```


```
agentmemory://graph/stats
```


```
recall_context
```


```
session_handoff
```


```
detect_patterns
```


```
/recall
```


```
/remember
```


```
/session-history
```


```
/forget
```

Run without the full server — for any MCP client. Either of these works:

```
npx -y @agentmemory/agentmemory mcp # canonical (always available) npx -y @agentmemory/mcp # shim package alias
```

Or add to your agent's MCP config:
Most agents (Cursor, Claude Desktop, Cline, Roo Code, Windsurf, Gemini CLI):

```
{ "mcpServers": { "agentmemory": { "command": "npx", "args": ["-y", "@agentmemory/mcp"], "env": { "AGENTMEMORY_URL": "http://localhost:3111" } } } }
```

Merge the agentmemory entry into your host's existing mcpServers object rather than replacing the file. For sandboxed clients that can't reach the host's localhost, add "AGENTMEMORY_FORCE_PROXY": "1" to the env block and set AGENTMEMORY_URL to a route the sandbox can reach.

```
agentmemory
```


```
mcpServers
```


```
localhost
```


```
"AGENTMEMORY_FORCE_PROXY": "1"
```


```
AGENTMEMORY_URL
```

OpenCode (opencode.json):

```
opencode.json
```


```
{ "mcp": { "agentmemory": { "type": "local", "command": ["npx", "-y", "@agentmemory/mcp"], "enabled": true } }, "plugin": ["./plugins/agentmemory-capture.ts"] }
```

Copy the plugin file from the repo:

```
mkdir -p ~/.config/opencode/plugins cp plugin/opencode/agentmemory-capture.ts ~/.config/opencode/plugins/ cp plugin/opencode/commands/*.md ~/.config/opencode/commands/
```

Auto-starts on port 3113. Live observation stream, session explorer, memory browser, knowledge graph visualization, and health dashboard.

```
3113
```


```
open http://localhost:3113
```

The viewer server binds to 127.0.0.1 by default. The REST-served /agentmemory/viewer endpoint follows the normal AGENTMEMORY_SECRET bearer-token rules. CSP headers use a per-response script nonce and disable inline handler attributes (script-src-attr 'none').

```
127.0.0.1
```


```
/agentmemory/viewer
```


```
AGENTMEMORY_SECRET
```


```
script-src-attr 'none'
```

The viewer at :3113 shows what your agent remembered. The [iii console](https://iii.dev/docs/console) shows what your agent did — every memory op as an OpenTelemetry trace, every KV entry editable, every function invocable, every stream tappable. Two windows on the same memory: one product-shaped, one engine-shaped.

```
:3113
```

Watch a memory_smart_search fire and see the BM25 scan → embedding lookup → RRF fusion → reranker as a waterfall. Edit a stuck consolidation timer in the KV browser. Replay a PostToolUse hook with a tweaked payload. Pin the WebSocket stream and watch observations land live.

```
memory_smart_search
```


```
PostToolUse
```

agentmemory ships this for free because every function call and trigger fires through iii — nothing custom, nothing to instrument.
https://github.com/rohitg00/agentmemory/blob/main/assets/iii-console/workers.png Workers page: every connected worker — including agentmemory itself — with PID, function count, runtime, and last-seen.
Already installed. The console ships with iii — no separate installer.

```
iii
```

Launch alongside agentmemory:

```
# agentmemory viewer holds port 3113, so run the console on 3114. # Engine REST (3111), WebSocket (3112), and bridge (49134) defaults match agentmemory. iii console --port 3114
```

Then open http://localhost:3114. Add --enable-flow for the experimental architecture-graph page.

```
http://localhost:3114
```


```
--enable-flow
```

Override engine endpoints only if you've moved them:

```
iii console --port 3114 \ --engine-port 3111 \ --ws-port 3112 \ --bridge-port 49134
```

What you can do from the console:

```
memory.recall
```


```
memory.consolidate
```


```
graph.query
```


```
trace_id
```


```
memory.search
```


```
--enable-flow
```

https://github.com/rohitg00/agentmemory/blob/main/assets/iii-console/traces-waterfall.png Traces: waterfall / flame / service breakdown for every memory operation.
Traces are already on:
iii-config.yaml ships with the iii-observability worker enabled (exporter: memory, sampling_ratio: 1.0, metrics + logs). No extra config needed — the moment agentmemory starts, every memory operation emits a trace span and a structured log the console can read.

```
iii-config.yaml
```


```
iii-observability
```


```
exporter: memory
```


```
sampling_ratio: 1.0
```

If you want to export to Jaeger/Honeycomb/Grafana Tempo instead, change exporter: memory to exporter: otlp and set the collector endpoint per iii's observability docs.

```
exporter: memory
```


```
exporter: otlp
```

### Standalone MCP
Heads-up: no auth is enforced on the console itself — keep it bound to 127.0.0.1 (the default) and never expose it publicly.

```
127.0.0.1
```

agentmemory is already a running [iii](https://iii.dev) instance. Three primitives — worker, function, trigger — compose the runtime; KV state, streams, and OTEL traces come from iii-state, iii-stream, and iii-observability workers that ship with iii. You didn't install Postgres, Redis, Express, pm2, or Prometheus, because iii replaces them.
That means one more command extends agentmemory with an entire new capability.

### Extend agentmemory with one command
```
iii worker add iii-pubsub # fan memory writes out to every connected instance iii worker add iii-cron # scheduled consolidation, decay sweeps, snapshot rotation iii worker add iii-queue # durable retries for embedding + compression jobs iii worker add iii-observability # OTEL traces on every memory op (default on) iii worker add iii-sandbox # run recalled code inside an isolated microVM iii worker add iii-database # swap in a SQL-backed state adapter iii worker add mcp # generic MCP host alongside the agentmemory MCP
```

Each iii worker add registers new functions and triggers into the same engine agentmemory is already running on. The viewer and console pick them up immediately — no reload, no new integration, no new container.

```
iii worker add
```


```
iii worker add
```

[iii-pubsub](https://workers.iii.dev/workers/iii-pubsub)

```
iii-pubsub
```


```
remember
```


```
search
```

[iii-cron](https://workers.iii.dev/workers/iii-cron)

```
iii-cron
```

[iii-queue](https://workers.iii.dev/workers/iii-queue)

```
iii-queue
```

[iii-observability](https://workers.iii.dev/workers/iii-observability)

```
iii-observability
```


```
iii-config.yaml
```

[iii-sandbox](https://workers.iii.dev/workers/iii-sandbox)

```
iii-sandbox
```


```
memory_recall
```

[iii-database](https://workers.iii.dev/workers/iii-database)

```
iii-database
```

[mcp](https://workers.iii.dev/workers/mcp)

```
mcp
```

Full registry: [workers.iii.dev](https://workers.iii.dev). Every worker there composes through the same primitives agentmemory uses — and the agentmemory you already have is one of them.

### What iii replaces
```
iii worker add <name>
```

174 source files · ~37,800 LOC · 1,423+ tests · 258 functions · 44 KV scopes — all on three primitives. No agentmemory plugin install. The plugin system is iii itself.

```
agentmemory plugin install
```

### LLM Providers
agentmemory auto-detects from your environment. By default, no LLM calls are made unless you configure a provider or explicitly opt in to the Claude subscription fallback.

```
AGENTMEMORY_ALLOW_AGENT_SDK
```


```
ANTHROPIC_API_KEY
```


```
MINIMAX_API_KEY
```


```
GEMINI_API_KEY
```


```
OPENROUTER_API_KEY
```


```
OPENAI_API_KEY
```


```
gpt-4o-mini
```


```
OPENAI_MODEL
```


```
OPENAI_API_KEY=local
```


```
OPENAI_BASE_URL=http://localhost:11434/v1
```


```
http://localhost:1234/v1
```


```
OPENAI_MODEL=<your model>
```

[Local models](https://github.com/rohitg00/agentmemory#local-models-ollama-lm-studio-vllm)

```
AGENTMEMORY_ALLOW_AGENT_SDK=true
```


```
@anthropic-ai/claude-agent-sdk
```

### Local models (Ollama / LM Studio / vLLM)
agentmemory talks to any OpenAI-API-compatible server, so anything that exposes /v1/chat/completions works without code changes. No paid keys, no cloud, no rate limits — runs entirely on your hardware.

```
/v1/chat/completions
```

Ollama (default port 11434):

```
11434
```


```
ollama pull qwen2.5-coder:7b # or llama3.2:3b, mistral:7b, etc. ollama serve
```


```
# ~/.agentmemory/.env OPENAI_API_KEY=ollama # any non-empty string; Ollama ignores it OPENAI_BASE_URL=http://localhost:11434/v1 OPENAI_MODEL=qwen2.5-coder:7b
```

LM Studio (default port 1234):

```
1234
```

Open LM Studio → Local Server tab → Start Server. Pick any chat model from the picker (Qwen 2.5 Coder, Llama 3.2, DeepSeek, etc.).

```
# ~/.agentmemory/.env OPENAI_API_KEY=lmstudio # any non-empty string; LM Studio ignores it OPENAI_BASE_URL=http://localhost:1234/v1 OPENAI_MODEL=qwen2.5-coder-7b-instruct # match the model name from LM Studio
```

vLLM / llama.cpp / Text Generation Inference: same shape — point OPENAI_BASE_URL at whatever URL your server exposes, set OPENAI_MODEL to a name your server will accept.

```
OPENAI_BASE_URL
```


```
OPENAI_MODEL
```

Model picks for memory work: compression and summarization are short tasks (<2K tokens in, <500 tokens out) where a 7B instruct model is plenty. Recommendations:

```
qwen2.5-coder:7b
```


```
llama3.2:3b
```


```
mistral:7b-instruct
```


```
deepseek-r1:7b
```

Reasoning-class models (o1-style with <think> blocks) can return empty content with a reasoning field your local server may not surface. If extractions come back blank, switch to a non-reasoning model first. The OPENAI_REASONING_EFFORT=none env can also disable thinking on Ollama Cloud thinking models that mirror the OpenAI reasoning schema.

```
o1
```


```
<think>
```


```
content
```


```
reasoning
```


```
OPENAI_REASONING_EFFORT=none
```

Local embeddings ship out of the box via @xenova/transformers — EMBEDDING_PROVIDER=local (default) gives you BGE-small entirely on-device. No extra config needed.

```
@xenova/transformers
```


```
EMBEDDING_PROVIDER=local
```

### Cost-aware model selection
Background compression runs on every observation, so model choice meaningfully changes monthly spend. Captured workload data: 635 requests / 888K tokens / 35 hours of active use, run against three OpenRouter models at 2026-05-23 pricing.

```
deepseek/deepseek-v4-pro
```


```
deepseek/deepseek-chat
```


```
qwen/qwen3-coder
```


```
anthropic/claude-sonnet-4.6
```


```
openai/gpt-4o
```


```
anthropic/claude-opus-4.6
```

agentmemory prints a runtime warning when OPENROUTER_MODEL matches a premium-tier pattern. Set AGENTMEMORY_SUPPRESS_COST_WARNING=1 to silence once you've made an informed choice.

```
OPENROUTER_MODEL
```


```
AGENTMEMORY_SUPPRESS_COST_WARNING=1
```

Quality vs cost tradeoff for memory work: compression is a summarization task with relatively loose quality bars (the agent re-reads the summary, not the user). DeepSeek-V4-Pro / Qwen3-Coder land within rounding error of Sonnet on this task while costing ~10× less. Save the premium-tier models for queries you read directly.
Sources: [OpenRouter pricing for Sonnet 4.6](https://openrouter.ai/anthropic/claude-sonnet-4.6/pricing), [DeepSeek V4 Pro](https://openrouter.ai/deepseek/deepseek-v4-pro), [DeepSeek pricing notes](https://api-docs.deepseek.com/quick_start/pricing/).

### Multi-agent memory (AGENT_ID + AGENTMEMORY_AGENT_SCOPE)
```
AGENT_ID
```


```
AGENTMEMORY_AGENT_SCOPE
```

In multi-agent setups where several roles share one agentmemory server (architect / developer / reviewer / researcher / support-agent), AGENT_ID tags every write with the role that made it. AGENTMEMORY_AGENT_SCOPE controls whether recall filters by that tag.

```
AGENT_ID
```


```
AGENTMEMORY_AGENT_SCOPE
```


```
TEAM_ID=company USER_ID=engineering-team AGENT_ID=architect AGENTMEMORY_AGENT_SCOPE=isolated # optional; default "shared"
```

Two modes:

```
shared
```


```
isolated
```

What gets tagged when AGENT_ID is set: Session.agentId, RawObservation.agentId, CompressedObservation.agentId, Memory.agentId. The role flows from api::session::start → mem::observe → mem::compress → KV.

```
AGENT_ID
```


```
Session.agentId
```


```
RawObservation.agentId
```


```
CompressedObservation.agentId
```


```
Memory.agentId
```


```
api::session::start
```


```
mem::observe
```


```
mem::compress
```

What gets filtered in isolated mode: mem::smart-search, /agentmemory/memories, /agentmemory/observations, /agentmemory/sessions. Each endpoint accepts ?agentId=<role> to override per-request, and ?agentId=* to opt out of the env scope entirely. /memories also accepts ?includeOrphans=true to surface pre-AGENT_ID memories whose agentId is undefined.

```
mem::smart-search
```


```
/agentmemory/memories
```


```
/agentmemory/observations
```


```
/agentmemory/sessions
```


```
?agentId=<role>
```


```
?agentId=*
```


```
/memories
```


```
?includeOrphans=true
```


```
agentId
```

Per-call override at the SDK / REST layer: every mutating endpoint (/session/start, /remember) accepts an agentId field in the request body that wins over the env. Useful for runtimes routing many roles through one server process.

```
/session/start
```


```
/remember
```


```
agentId
```

When AGENT_ID is unset, memory remains unscoped (legacy behavior, no tags, no filters).

```
AGENT_ID
```

### Ports
agentmemory + iii-engine bind four ports by default. If a restart fails with port in use, this table tells you which process to look for.

```
port in use
```


```
3111
```


```
/agentmemory/health
```


```
/agentmemory/livez
```


```
III_REST_PORT
```


```
3112
```


```
III_STREAMS_PORT
```


```
3113
```


```
http://localhost:3113
```


```
AGENTMEMORY_VIEWER_PORT
```


```
49134
```


```
III_ENGINE_URL
```


```
ws://localhost:49134
```

Stale-process cleanup when ports stay bound after a crashed run:

```
# macOS / Linux — find whatever is on each port and kill it lsof -i :3111,3112,3113,49134 pkill -f agentmemory || true pkill -f 'iii ' || true # Windows netstat -ano | findstr ":3111 :3112 :3113 :49134" taskkill /F /PID <pid>
```

agentmemory stop reaps both the worker and the engine pidfile cleanly on graceful shutdown (#640, #474). The manual cleanup above is only for the post-crash case where neither pidfile is left behind.

```
agentmemory stop
```

### Config File
Put agentmemory runtime configuration in ~/.agentmemory/.env instead of exporting variables in every shell. If the viewer shows a setup hint like export ANTHROPIC_API_KEY=..., copy it into this file as ANTHROPIC_API_KEY=... without the export prefix, then restart agentmemory.

```
~/.agentmemory/.env
```


```
export ANTHROPIC_API_KEY=...
```


```
ANTHROPIC_API_KEY=...
```


```
export
```

Process environment variables still work and take precedence over values in the file.
On Windows, the same file lives at %USERPROFILE%\.agentmemory\.env:

```
%USERPROFILE%\.agentmemory\.env
```


```
New-Item -ItemType Directory -Force $HOME\.agentmemory notepad $HOME\.agentmemory\.env
```

To test with a Claude Code Pro/Max subscription instead of an API key, opt in explicitly:

```
AGENTMEMORY_ALLOW_AGENT_SDK=true AGENTMEMORY_AUTO_COMPRESS=true
```

Consolidation (graph nodes, lessons, crystals) is on by default whenever an LLM provider is configured. Explicitly opt out with CONSOLIDATION_ENABLED=false if you want LLM-free operation. Graph extraction is a separate flag:

```
CONSOLIDATION_ENABLED=false
```


```
GRAPH_EXTRACTION_ENABLED=true # CONSOLIDATION_ENABLED=false # opt out of auto-consolidation
```

### Environment Variables
Create ~/.agentmemory/.env:

```
~/.agentmemory/.env
```

```
# LLM provider (pick one — default is the no-op provider: no LLM calls) # ANTHROPIC_API_KEY=sk-ant-... # ANTHROPIC_BASE_URL=... # Optional: Anthropic-compatible proxy / Azure # GEMINI_API_KEY=... # OPENROUTER_API_KEY=... # MINIMAX_API_KEY=... # OPENAI_API_KEY=*** # NOTE: this same key auto-activates BOTH the # # OpenAI LLM provider (here) AND the OpenAI # # embedding provider (further below). Set # # OPENAI_API_KEY_FOR_LLM=false to scope it # # to embeddings only. # OPENAI_BASE_URL=https://api.openai.com # Optional: override for Azure / vLLM / LM Studio / proxies # # Azure: https://<resource>.openai.azure.com/openai/deployments/<deployment> # # Auto-detected from `.openai.azure.com` hostname; uses # # api-key header + api-version query param. # OPENAI_API_VERSION=2024-08-01-preview # Optional: Azure api-version query param # OPENAI_MODEL=gpt-4o-mini # Optional: default model # OPENAI_TIMEOUT_MS=60000 # Optional: OpenAI-scoped alias for the outbound fetch # # timeout. Takes precedence over AGENTMEMORY_LLM_TIMEOUT_MS # # for back-compat with v0.9.17. New configs should # # prefer the global AGENTMEMORY_LLM_TIMEOUT_MS below. # OPENAI_REASONING_EFFORT=none # Optional: "low" | "medium" | "high" | "none" # # Honored only by OpenAI's reasoning models (o1, o3, # # gpt-*-reasoning) and providers that mirror that # # schema (Ollama Cloud thinking models). Standard # # chat models reject this field with 400. Set to # # "none" for thinking models that return reasoning # # but no content. # OPENAI_API_KEY_FOR_LLM=false # Optional: set to false to skip OpenAI auto-detection # # for LLM (useful if you only want OpenAI for embeddings) # Opt-in Claude-subscription fallback (spawns @anthropic-ai/claude-agent-sdk); # leave OFF unless you understand the Stop-hook recursion risk (#149 follow-up): # AGENTMEMORY_ALLOW_AGENT_SDK=true # Embedding provider (auto-detected, or override) # EMBEDDING_PROVIDER=local # VOYAGE_API_KEY=... # OPENAI_API_KEY=sk-... # OPENAI_BASE_URL=https://api.openai.com # Override for Azure / vLLM / LM Studio / proxies # OPENAI_EMBEDDING_MODEL=text-embedding-3-small # OPENAI_EMBEDDING_DIMENSIONS=1536 # Required when the model is not in the known-models table # Outbound LLM / embedding timeout # AGENTMEMORY_LLM_TIMEOUT_MS=60000 # Default: 60 000 ms (60 s). Applies to every # raw-fetch provider (Gemini, OpenRouter, MiniMax, # OpenAI LLM, OpenAI/Cohere/Voyage/OpenRouter # embedding). For the OpenAI LLM path, the # OpenAI-scoped OPENAI_TIMEOUT_MS alias (above) # takes precedence when set, for back-compat # with v0.9.17. # Increase for slow networks or large batch calls; # decrease to fail-fast on rate-limit holds. # Search tuning # BM25_WEIGHT=0.4 # VECTOR_WEIGHT=0.6 # TOKEN_BUDGET=2000 # Auth # AGENTMEMORY_SECRET=your-secret # Ports (defaults: 3111 API, 3113 viewer) # III_REST_PORT=3111 # Features # AGENTMEMORY_AUTO_COMPRESS=false # OFF by default (#138). When on, # every PostToolUse hook calls your # LLM provider to compress the # observation — expect significant # token spend on active sessions. # AGENTMEMORY_SLOTS=false # OFF by default. Editable pinned # memory slots — persona, # user_preferences, tool_guidelines, # project_context, guidance, # pending_items, session_patterns, # self_notes. Size-limited; agent # edits via memory_slot_* tools. # Pinned slots addressable for # SessionStart injection. # AGENTMEMORY_REFLECT=false # OFF by default. Requires SLOTS=on. # Stop hook fires mem::slot-reflect: # scans recent observations, auto- # appends TODOs to pending_items, # counts patterns in # session_patterns, records touched # files in project_context. Fire- # and-forget; does not block. # AGENTMEMORY_INJECT_CONTEXT=false # OFF by default (#143). When on: # - SessionStart may inject ~1-2K # chars of project context into # the first turn of each session # (this is what actually reaches # the model — Claude Code treats # SessionStart stdout as context) # - PreToolUse fires /agentmemory/enrich # on every file-touching tool call # (resource cleanup, not a token # fix — PreToolUse stdout is debug # log only per Claude Code docs) # Observations are still captured via # PostToolUse regardless of this flag. # GRAPH_EXTRACTION_ENABLED=false # CONSOLIDATION_ENABLED=false # on by default when an LLM provider is configured # LESSON_DECAY_ENABLED=true # OBSIDIAN_AUTO_EXPORT=false # AGENTMEMORY_EXPORT_ROOT=~/.agentmemory # CLAUDE_MEMORY_BRIDGE=false # SNAPSHOT_ENABLED=false # Team # TEAM_ID= # USER_ID= # TEAM_MODE=private # Tool visibility: "core" (8 tools, lean fallback) or "all" (53 tools) # AGENTMEMORY_TOOLS=core
```

128 endpoints on port 3111. The REST API binds to 127.0.0.1 by default. Protected endpoints require Authorization: Bearer <secret> when AGENTMEMORY_SECRET is set, and mesh sync endpoints require AGENTMEMORY_SECRET on both peers.

```
3111
```


```
127.0.0.1
```


```
Authorization: Bearer <secret>
```


```
AGENTMEMORY_SECRET
```


```
AGENTMEMORY_SECRET
```


```
GET
```


```
/agentmemory/health
```


```
POST
```


```
/agentmemory/session/start
```


```
POST
```


```
/agentmemory/session/end
```


```
POST
```


```
/agentmemory/observe
```


```
POST
```


```
/agentmemory/smart-search
```


```
POST
```


```
/agentmemory/context
```


```
POST
```


```
/agentmemory/remember
```


```
POST
```


```
/agentmemory/forget
```


```
POST
```


```
/agentmemory/enrich
```


```
GET
```


```
/agentmemory/profile
```


```
GET
```


```
/agentmemory/export
```


```
POST
```


```
/agentmemory/import
```


```
POST
```


```
/agentmemory/graph/query
```


```
POST
```


```
/agentmemory/team/share
```


```
GET
```


```
/agentmemory/audit
```

Full endpoint list: [src/triggers/api.ts](https://github.com/rohitg00/agentmemory/blob/main/src/triggers/api.ts)

```
src/triggers/api.ts
```


```
npm run dev # Hot reload npm run build # Production build npm test # 1,423+ tests npm run test:integration # API tests (requires running services)
```

Prerequisites: Node.js >= 20, [iii-engine](https://iii.dev/docs) or Docker
[Apache-2.0](https://github.com/rohitg00/agentmemory/blob/main/LICENSE)

[agent-memory.dev](https://agent-memory.dev)

### Topics
[ai](https://github.com/topics/ai)
[memory](https://github.com/topics/memory)
[cursor](https://github.com/topics/cursor)
[hermes](https://github.com/topics/hermes)
[copilot](https://github.com/topics/copilot)
[agents](https://github.com/topics/agents)
[harness](https://github.com/topics/harness)
[codex](https://github.com/topics/codex)
[claude](https://github.com/topics/claude)
[genai](https://github.com/topics/genai)
[claudecode](https://github.com/topics/claudecode)
[agentmemory](https://github.com/topics/agentmemory)
[openclaw](https://github.com/topics/openclaw)

### Resources
[Readme](https://github.com/rohitg00/agentmemory#readme-ov-file)

### License
[Apache-2.0 license](https://github.com/rohitg00/agentmemory#Apache-2.0-1-ov-file)

### Code of conduct
[Code of conduct](https://github.com/rohitg00/agentmemory#coc-ov-file)

### Contributing
[Contributing](https://github.com/rohitg00/agentmemory#contributing-ov-file)

### Security policy
[Security policy](https://github.com/rohitg00/agentmemory#security-ov-file)

### Uh oh!
There was an error while loading. [Please reload this page](https://github.com/rohitg00/agentmemory).
[Activity](https://github.com/rohitg00/agentmemory/activity)

### Stars
[22.5k
        stars](https://github.com/rohitg00/agentmemory/stargazers)

### Watchers
[62
        watching](https://github.com/rohitg00/agentmemory/watchers)

### Forks
[1.9k
        forks](https://github.com/rohitg00/agentmemory/forks)
[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Frohitg00%2Fagentmemory&report=rohitg00+%28user%29)

## [Releases 49](https://github.com/rohitg00/agentmemory/releases)
[Releases
      49](https://github.com/rohitg00/agentmemory/releases)
[v0.9.27

          Latest

      Jun 7, 2026](https://github.com/rohitg00/agentmemory/releases/tag/v0.9.27)
[+ 48 releases](https://github.com/rohitg00/agentmemory/releases)

## [Packages 0](https://github.com/users/rohitg00/packages?repo_name=agentmemory)
[Packages
      0](https://github.com/users/rohitg00/packages?repo_name=agentmemory)

### Uh oh!
There was an error while loading. [Please reload this page](https://github.com/rohitg00/agentmemory).

### Uh oh!
There was an error while loading. [Please reload this page](https://github.com/rohitg00/agentmemory).

[Contributors](https://github.com/rohitg00/agentmemory/graphs/contributors)

There was an error while loading. [Please reload this page](https://github.com/rohitg00/agentmemory).

- 
        [TypeScript
          83.0%](https://github.com/rohitg00/agentmemory/search?l=typescript)

- 
        [JavaScript
          7.4%](https://github.com/rohitg00/agentmemory/search?l=javascript)

- 
        [HTML
          6.7%](https://github.com/rohitg00/agentmemory/search?l=html)

- 
        [CSS
          1.3%](https://github.com/rohitg00/agentmemory/search?l=css)

- 
        [Shell
          0.9%](https://github.com/rohitg00/agentmemory/search?l=shell)

- 
        [Python
          0.5%](https://github.com/rohitg00/agentmemory/search?l=python)

- 
        [Dockerfile
          0.2%](https://github.com/rohitg00/agentmemory/search?l=dockerfile)

[TypeScript
          83.0%](https://github.com/rohitg00/agentmemory/search?l=typescript)
[JavaScript
          7.4%](https://github.com/rohitg00/agentmemory/search?l=javascript)
[HTML
          6.7%](https://github.com/rohitg00/agentmemory/search?l=html)
[CSS
          1.3%](https://github.com/rohitg00/agentmemory/search?l=css)
[Shell
          0.9%](https://github.com/rohitg00/agentmemory/search?l=shell)
[Python
          0.5%](https://github.com/rohitg00/agentmemory/search?l=python)
[Dockerfile
          0.2%](https://github.com/rohitg00/agentmemory/search?l=dockerfile)

- 
            [Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)

- 
            [Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)

- 
            [Security](https://github.com/security)

- 
            [Status](https://www.githubstatus.com/)

- 
            [Community](https://github.community/)

- 
            [Docs](https://docs.github.com/)

- 
            [Contact](https://support.github.com?tags=dotcom-footer)

- 


       Manage cookies



- 


      Do not share my personal information



[Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)
[Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)
[Security](https://github.com/security)
[Status](https://www.githubstatus.com/)
[Community](https://github.community/)
[Docs](https://docs.github.com/)
[Contact](https://support.github.com?tags=dotcom-footer)

