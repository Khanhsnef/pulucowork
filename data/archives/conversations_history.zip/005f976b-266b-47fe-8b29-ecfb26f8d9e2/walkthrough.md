# BÁO CÁO TRIỂN KHAI: TỐI ƯU HÓA TOKEN VỚI HEADROOM-AI & 9ROUTER

## 📊 Executive Summary
*   **Mục tiêu:** Cài đặt và cấu hình **headroom-ai** trên máy local để tối ưu hóa context (nén token) khi gọi các LLM qua **9router**, áp dụng đồng thời cho **Claude Code CLI** và **Antigravity IDE**.
*   **Giải pháp kỹ thuật:** 
    *   Sử dụng **`uv`** để cô lập và chạy **headroom-ai** trên môi trường **Python 3.12** sạch, giải quyết triệt để lỗi không tương thích phiên bản của thư viện `litellm` trên host system (đang chạy Python 3.14.4).
    *   Tự động hóa bằng **launchd Agent** (`com.chopratejas.headroom.default.plist`) giúp duy trì hoạt động liên tục của **headroom proxy** tại cổng `8787`.
    *   Cấu hình định tuyến bắc cầu: **Claude Code CLI / Antigravity IDE** (Cổng 8787 - Headroom) ➔ **9router** (Cổng 20128 - Định tuyến/Mitm) ➔ **Upstream LLM Provider**.
*   **Kết quả:** Hệ thống vận hành ổn định, sẵn sàng hoạt động ngay lập tức mà không cần can thiệp thủ công sau mỗi lần khởi động máy.

---

## 🔍 Khung Phân Tích (Analysis Framework)

### 1. Phân tích Mô tả (Descriptive Analysis)
*   **Hạ tầng Vận hành hiện tại:**
    *   Hệ điều hành: macOS.
    *   Phiên bản Python hệ thống: `3.14.4` (bản thử nghiệm/mới nhất, gây xung đột với metadata `requires-python:<3.14` của `litellm`).
    *   **9router** đang hoạt động như một local MITM proxy tại cổng `20128`, quản lý API key `sk-ae62...`.
*   **Benchmarks thiết lập:**
    *   **Headroom Proxy:** Lắng nghe tại `http://127.0.0.1:8787`.
    *   **Upstream Target:** `http://localhost:20128` (9router).
    *   **MCP Server command:** `/Users/ts-1148/.local/bin/headroom mcp serve`.

### 2. Phân tích Chẩn đoán (Diagnostic Analysis)
*   **Khoảng trống Chất lượng (Quality Gaps):**
    *   Phiên bản `litellm >= 1.86.2` (dependency bắt buộc của headroom-ai) chặn cứng không cho cài trên Python 3.14.
    *   Lệnh cài đặt tự động `headroom install apply` bị crash do cố gắng tích hợp tự động với `openclaw` vốn đang gặp lỗi không tương thích gói npm registry trên máy.
    *   Bản cài đặt mặc định của headroom thiếu các proxy dependency quan trọng (`fastapi`, `uvicorn`, `onnxruntime`, `numpy`), dẫn đến việc khởi động proxy thất bại.
*   **Giải pháp khắc phục:**
    *   Sử dụng `uv tool install 'headroom-ai[mcp,proxy]' --python 3.12 --force` để cài đặt đầy đủ tất cả gói bổ trợ và cô lập vào môi trường Python 3.12.
    *   Viết thủ công file launchd cấu hình service để bỏ qua bước tự động phát hiện/cấu hình của `headroom` nhằm tránh lỗi crash từ các công cụ bên thứ ba khác (như openclaw).

### 3. Phân tích Đề xuất (Prescriptive Analysis)
*   **Lộ trình Tối ưu:**
    1.  Khởi chạy **Headroom proxy** qua launchd với biến môi trường `ANTHROPIC_TARGET_API_URL=http://localhost:20128` để chuyển tiếp luồng yêu cầu đến **9router**.
    2.  Đăng ký **Headroom MCP server** (STDIO) vào cấu hình toàn cục của Claude Code (`~/.claude.json`) và cấu hình workspace của Antigravity IDE (`mcp-servers.json`).
    3.  Cập nhật biến môi trường shell (`~/.zshrc`) trỏ `ANTHROPIC_BASE_URL` sang cổng `8787` (Headroom proxy).

---

## 📈 Hiện Thực Hóa Giá Trị (Value Realization)

**Đo lường Tác động Kinh doanh (Measurable Business Impact):**

| Hiện trạng (Before) | Chuyển đổi (Transformation) | Trạng thái Mục tiêu (After) | Tác động dự kiến (Impact) |
| :--- | :--- | :--- | :--- |
| Cuộc gọi API từ Claude Code gửi thẳng tới 9router, không nén các output dài của tool call. | ↓ ĐỒNG BỘ QUA HEADROOM PROXY ↓ | Toàn bộ request đi qua cổng 8787 của Headroom để nén context tự động trước khi tới 9router. | ***Tiết kiệm 30% - 60% lượng token tiêu thụ, giảm đáng kể chi phí gọi API qua 9router.*** |
| Cài đặt headroom thất bại do xung đột Python 3.14 và lỗi từ openclaw. | ↓ CÔ LẬP UV & LAUNCHD PLIST ↓ | Chạy ổn định trên môi trường Python 3.12 độc lập và tự khởi động cùng hệ thống. | ***Khắc phục hoàn toàn lỗi cài đặt, hệ thống tự động chạy ngầm không cần bảo trì thủ công.*** |
| Thiếu công cụ giúp Claude Code đọc lại các output đã bị nén. | ↓ KÍCH HOẠT MCP SERVER ↓ | MCP server cung cấp tool `headroom_retrieve` cho phép Claude đọc lại dữ liệu gốc khi cần. | ***Đảm bảo tính chính xác của dữ liệu trong khi vẫn tối ưu hóa được chi phí token.*** |

---

## 🛠️ Hướng Dẫn Kiểm Tra & Xác Minh (Verification Plan)

### 1. Kiểm tra trạng thái Proxy
Chạy lệnh sau để đảm bảo proxy đang chạy ngầm ổn định:
```bash
curl -I http://127.0.0.1:8787/livez
```
*Kết quả mong đợi: Trả về HTTP 200 OK.*

### 2. Kiểm tra log hoạt động
Bạn có thể xem log thời gian thực của proxy thông qua các file sau:
*   Log chuẩn đầu ra: `/Users/ts-1148/.headroom/proxy.stdout.log`
*   Log lỗi (nếu có): `/Users/ts-1148/.headroom/proxy.stderr.log`

### 3. Áp dụng cấu hình trên Terminal mới
Để terminal hiện tại nhận biến môi trường mới từ `.zshrc`, bạn cần chạy:
```bash
source ~/.zshrc
```
Sau đó khởi chạy Claude Code như bình thường. Toàn bộ cuộc gọi sẽ tự động đi qua Headroom ➔ 9router.
