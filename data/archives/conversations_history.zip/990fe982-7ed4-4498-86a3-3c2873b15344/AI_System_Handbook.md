# 🤖 AI SYSTEM HANDBOOK — Khanh's Personal AI Stack
> *Tài liệu đóng gói hệ thống AI cá nhân — Phiên bản chia sẻ*
> **Cập nhật:** 2026-06-15 | **Tác giả:** Lê Phương Khanh

---

## 📊 Executive Summary

Đây là hệ thống AI **tự động định tuyến (Smart Router)** được xây dựng trên nền tảng Claude Code + 9Router — cho phép **1 câu hỏi tự động chọn đúng AI tốt nhất** để xử lý mà không cần nhớ tên model hay gõ lệnh phức tạp.

**3 tính năng cốt lõi:**
1. **Smart Router v3** — AI phân loại ý định + Regex fallback → chọn model tự động
2. **10 Sub-Agents chuyên biệt** — Mỗi agent có vai trò riêng (SQL, báo cáo, comms, event...)
3. **Auto-sync** — Mọi file tự động push lên GitHub + Google Drive sau mỗi phiên làm việc

---

## 🏗️ KIẾN TRÚC HỆ THỐNG (Architecture Overview)

```
Người dùng gõ câu hỏi
        │
        ▼
┌─────────────────────────┐
│   TẦNG 1: AI CLASSIFIER │  ← ai-classify.py (Python)
│   Claude Haiku → Gemini │     Timeout: 8s
│   Flash → DeepSeek      │     Trả về: DEEP_THINK / CODE_FORMAT /
│   (thử lần lượt)        │              LANGUAGE / ENGLISH / QUICK
└──────────┬──────────────┘
           │ Thất bại (FALLBACK)
           ▼
┌─────────────────────────┐
│   TẦNG 2: REGEX ROUTER  │  ← Quét từ khóa tiếng Việt/Anh
│   Pattern matching      │     Tốc độ: instant, không cần API
│   25+ từ khóa/nhóm      │
└──────────┬──────────────┘
           │
           ▼
┌─────────────────────────────────────────────────────┐
│                  MODEL SELECTION                    │
│                                                     │
│  🧠 OPUS 4.8      │ Chiến lược, phân tích, P&L      │
│  💻 SONNET 4.6    │ Code, SQL, HTML, format          │
│  ⚡ GEMINI PRO    │ Viết lách, dịch, content         │
│  🌐 GPT-5.5       │ Tiếng Anh, báo cáo HQ            │
│  💨 DEEPSEEK      │ Hỏi nhanh, tra cứu (miễn phí)   │
└─────────────────────────────────────────────────────┘
           │
           ▼
┌─────────────────────────┐
│   9ROUTER PROXY         │  ← http://127.0.0.1:8787/v1
│   (Local LLM Gateway)   │     Quản lý quota + routing
│   Key: sk-ae62d35e...   │     đến các provider thực tế
└─────────────────────────┘
```

---

## 🛠️ CÁC THÀNH PHẦN HỆ THỐNG

### 1. Smart Router v3 (`~/.zshrc`)

**File chính:** `~/.zshrc` — Tự động load khi mở Terminal/VS Code

#### Luồng xử lý chi tiết:

```
Câu hỏi → ai-classify.py (AI) → Nếu FALLBACK → _regex_route() → model + label
```

**5 nhãn ý định (Intent Labels):**

| Nhãn | Model được chọn | Trigger keywords |
|:-----|:----------------|:----------------|
| `DEEP_THINK` | 🧠 `cc/claude-opus-4-8` | phân tích, chiến lược, insight, P&L, SLA, OKR, rủi ro, fraud, trade-off |
| `CODE_FORMAT` | 💻 `cc/claude-sonnet-4-6` | code, SQL, HTML, dashboard, lark, markdown, script, báo cáo |
| `LANGUAGE` | ⚡ `gc/gemini-3-pro-preview` | dịch, thông báo, tài xế, zalo, viết lại, caption, tóm tắt, competitive |
| `ENGLISH` | 🌐 `oc/gpt-5-5` | english, proposal, HQ, leadership, investor, global, board |
| `QUICK` | 💨 `oc/deepseek-v4-flash-free` | hỏi nhanh, định nghĩa, là gì, tính toán, quick |

---

### 2. Lệnh Terminal — Bảng Tổng Hợp

#### 🟢 Lệnh Chính (Dùng hàng ngày)

| Lệnh | Chức năng | Khi nào dùng |
|:-----|:----------|:------------|
| `chat` hoặc `start` | Mở Smart Chat REPL (chế độ chat tương tác) | Muốn chat nhiều câu liên tiếp, giữ ngữ cảnh |
| `ai "câu hỏi"` | One-shot: hỏi 1 câu rồi thoát | Muốn hỏi nhanh, không vào chế độ chat |
| `claude` | Mở Claude Opus 4.8 trực tiếp | Khi biết mình cần model mạnh nhất |

#### 🔵 Alias Ép Model (Khi biết rõ cần model nào)

| Lệnh | Model | Dùng cho |
|:-----|:------|:---------|
| `c-opus` | Claude Opus 4.8 | Phân tích chiến lược sâu, ra quyết định phức tạp |
| `c-think` | Claude Opus 4.6 Thinking | Bài toán logic, lập luận từng bước |
| `c-sonnet` | Claude Sonnet 4.6 | Lập trình, viết code, format tài liệu |
| `c-gemini` | Gemini Pro | Dịch thuật, viết content, ngôn ngữ tự nhiên |
| `c-gpt` | GPT-5.5 | Văn bản tiếng Anh chuẩn quốc tế |
| `c-fast` | DeepSeek Flash | Hỏi đáp siêu nhanh, hoàn toàn miễn phí |

#### 🟡 Tính Năng Ẩn

| Tính năng | Cách hoạt động |
|:----------|:--------------|
| **Command Not Found** | Gõ thẳng câu hỏi vào terminal (không phải lệnh hệ thống) → tự động route đến AI |
| **Hybrid Mode** | Trong `chat`, nếu prompt có từ `docx/pdf/tạo file/xuất` → tự bật Tool Mode (cấp quyền đầy đủ) |
| **Continue Session** | Trong `chat`, mỗi câu tiếp theo dùng `--continue` → AI nhớ toàn bộ ngữ cảnh |

---

### 3. AI Intent Classifier (`~/.local/bin/ai-classify.py`)

**Vai trò:** Tầng thứ nhất của Smart Router — gọi AI nhỏ (Haiku/Flash/DeepSeek) để phân loại ý định với **độ chính xác cao hơn regex**.

```python
# Luồng thử model (theo thứ tự ưu tiên):
models_to_try = [
    ("cc/claude-haiku-4-5", 20),       # Nhanh + rẻ nhất
    ("gc/gemini-3-flash",   20),       # Dự phòng nếu Haiku fail
    ("oc/deepseek-v4-flash-free", 200) # Miễn phí, cần nhiều token hơn
]
# Timeout: 8 giây — nếu quá thời gian → fallback về Regex
```

**System Prompt gốc:**
```
You are an intent classifier. Return ONLY one label:
DEEP_THINK   - strategic analysis, P&L, SLA, risk, OKR, driver retention
CODE_FORMAT  - code, SQL, HTML, dashboard, markdown, lark docs
LANGUAGE     - rewrite, notifications, driver comms, captions, translate
ENGLISH      - proposals, HQ reports, investor deck, formal English
QUICK        - quick questions, definitions, calculations
```

---

### 4. Sub-Agents Chuyên Biệt (`.claude/agents/`)

> **Cách hoạt động:** Claude tự động kích hoạt agent phù hợp theo task — **không cần gọi thủ công**.

| Agent File | Tên Agent | Tự động kích hoạt khi... |
|:-----------|:----------|:------------------------|
| `sql-analyst.md` | 📊 SQL Data Analyst | Cần query AR, FR, CPO, Active Drivers, tính toán dữ liệu |
| `report-writer.md` | 📝 Report Writer | Có data sẵn → cần viết báo cáo chuẩn Lark Docs |
| `competitive-intel.md` | 🔍 Competitive Intel | Phân tích Grab, Be, XanhSM, SPX, GHN |
| `driver-comms.md` | 📣 Driver Comms Writer | Viết thông báo Zalo, script, nội dung cho tài xế |
| `landing-page-builder.md` | 🌐 Landing Page Builder | Tạo trang HTML đẹp, landing page |
| `content-writer.md` | ✍️ Content Writer | Caption MXH, blog, LinkedIn, script vlog |
| `event-planner.md` | 🎉 Event Planner | Lên kế hoạch event offline/online |
| `meeting-prep.md` | 🤝 Meeting Prep | Chuẩn bị trước cuộc họp quan trọng |
| `weekly-review.md` | 📅 Weekly Review | Review cuối tuần + lên kế hoạch tuần tới |

---

### 5. Cấu Hình Workspace (`CLAUDE.md` + `AGENTS.md`)

**`CLAUDE.md`** — Định nghĩa bối cảnh công việc cho Claude:
- Công ty: Ahamove (Logistics On-demand)
- Vai trò: Driver Management Leader
- Quy tắc output: Tiếng Việt, không rào đón, data-driven
- Cấu trúc thư mục lưu file (`output/Ahamove/01→07`)
- Brand colors: #0E4174 (Blue), #FF7F32 (Orange)
- Font: Lexend (từ Google Fonts)

**`AGENTS.md`** — System prompt toàn cục:
- Persona: Enterprise Strategic AI Decision Architect
- Framework: Super Deciders (Claudio Feser)
- Output format: Lark Docs chuẩn doanh nghiệp
- Cấu trúc tài liệu: Executive Summary → Analysis Framework → Value Realization

---

### 6. Automation & Sync (`.claude/settings.json`)

**Auto-sync sau mỗi phiên Claude:**
```bash
# Hook "Stop" — chạy sau khi Claude kết thúc phiên làm việc
cd ~/Desktop/Cowork && git add -A
git commit -m "auto-sync: 2026-06-15 11:30"
git push 2>/dev/null
# Đồng thời rsync lên Google Drive
rsync -a --delete --exclude='.git/' ~/Desktop/Cowork/ "~/Google Drive/My Drive/Cowork/"
```

**Kết quả:** Mọi file được backup tự động lên cả 2 nơi — không bao giờ mất dữ liệu.

---

## 💰 LOGIC TỐI ƯU TOKEN (Token Optimization Layer)

> Đây là **tầng quan trọng nhất** thường bị bỏ qua — toàn bộ hệ thống được thiết kế để **tối đa hóa output chất lượng trong khi tối thiểu hóa token tiêu thụ**.

### 1. Prompt Cache — Tái Sử Dụng Context (Tiết kiệm 80-90% input token)

```json
// Từ .claude.json — tengu_prompt_cache_1h_config
"allowlist": [
  "repl_main_thread*",    // Cache toàn bộ phiên chat chính
  "auto_mode",            // Cache khi ở chế độ tự động
  "rolling_compact",      // Cache sau khi đã compact
  "memdir_relevance",     // Cache memory relevance check
  "agent_classifier",     // Cache phân loại agent
  "compact",              // Cache bản tóm tắt
  "extract_memories"      // Cache quá trình trích xuất memory
]
```

**Ý nghĩa thực tế:** Trong 1 phiên làm việc dài:
- `cacheReadInputTokens`: **25,430,072 tokens đọc từ cache** (không tốn phí)
- `cacheCreationInputTokens`: 1,931,557 tokens tạo cache lần đầu (phí thấp hơn)
- `inputTokens` thực tế: chỉ **9,476 tokens** — tức là **99.96% input đọc từ cache!**

### 2. Token Budget Control — Giới Hạn Chi Phí Theo Tool

```json
// tengu_pewter_kestrel — Giới hạn token đầu ra theo từng công cụ
{
  "global": 50000,              // Tổng giới hạn toàn phiên
  "Bash": 30000,                // Lệnh terminal tối đa 30K tokens
  "PowerShell": 30000,
  "Grep": 20000,                // Tìm kiếm file tối đa 20K
  "Snip": 1000,                 // Snippet nhỏ chỉ 1K
  "StrReplaceBasedEditTool": 30000,  // Sửa file tối đa 30K
  "BashSearchTool": 20000
}
```

**Tác dụng:** Ngăn một lệnh `grep` hay `bash` đọc file khổng lồ tốn sạch quota.

### 3. Smart Output Length — Brevity Mode

```json
// tengu_swann_brevity: "focused"
// tengu_amber_wren: { "maxTokens": 25000 }
```

- **`focused` mode**: Claude tự cắt bớt phần dài dòng không cần thiết
- **`maxTokens: 25000`**: Hard cap cho response thông thường — tránh AI "nói dài" tốn quota

### 4. AI Classifier Dùng Model Rẻ Nhất Có Thể

```python
# ai-classify.py — Thứ tự ưu tiên tối ưu chi phí:
models_to_try = [
    ("cc/claude-haiku-4-5", 20),       # Haiku: $0.00025/1K tokens — cực rẻ
    ("gc/gemini-3-flash",   20),       # Gemini Flash: miễn phí / rất rẻ
    ("oc/deepseek-v4-flash-free", 200) # DeepSeek: 0 đồng
]
# max_tokens: 20 — chỉ cần 1 từ nhãn (DEEP_THINK, QUICK...)
# temperature: 0 — không cần creative, chỉ cần chính xác
```

**Logic tối ưu:** Thay vì gọi thẳng Opus (tốn $15/1M tokens) để phân loại ý định,
hệ thống dùng Haiku ($0.25/1M tokens) — **tiết kiệm 60x chi phí classification**.

### 5. DeepSeek Routing — Lớp Phòng Thủ Miễn Phí

```bash
alias c-fast="claude --model oc/deepseek-v4-flash-free"
# "deepseek-v4-flash-free" → FREE tier, không tốn quota Anthropic
```

Mọi câu hỏi `hỏi nhanh / là gì / tính toán` → **tự động route về DeepSeek** (0 đồng).
Chỉ câu hỏi thực sự cần Opus mới tốn token đắt.

### 6. Headroom Proxy — Tầng Kiểm Soát Rate Limit

```xml
<!-- LaunchAgent: com.chopratejas.headroom.default.plist -->
<!-- Tự khởi động cùng macOS, luôn chạy ngầm -->
<key>ANTHROPIC_TARGET_API_URL</key>
<string>http://localhost:20128</string>  <!-- Headroom lắng nghe tại đây -->
```

**Headroom là gì?** Một local proxy layer ngồi giữa Claude CLI và API thực:
- **Rate limit manager**: Tự động làm chậm request khi gần giới hạn
- **Request queue**: Xếp hàng request thay vì drop khi bận
- **Log & monitor**: Ghi lại mọi request vào `~/.headroom/proxy.stdout.log`
- **Auto-restart**: LaunchAgent `KeepAlive: true` → restart ngay nếu crash

```
Claude CLI → Headroom (:20128) → 9Router (:8787) → API Provider
               [Rate control]    [Model routing]    [Anthropic/Google/OpenAI]
```

### 7. AgentMemory — Long-term Memory Giảm Token Lặp

```bash
# MCP Server: agentmemory (port 3111)
# Wrapper tự khởi động server nếu chưa chạy
exec npx -y @agentmemory/mcp
```

**Tác dụng tối ưu token:**
- **Không phải nhắc lại context** mỗi phiên mới ("Tôi là Khanh, làm tại Ahamove...")
- AI tự truy xuất memory từ các phiên trước → context ngắn hơn → ít token hơn
- Memory lưu vĩnh viễn tại `~/.agentmemory/` — không mất khi đóng terminal

### 8. Smart Chat PRO — `/model` Switch Ngầm (Không Tạo Session Mới)

```python
# ~/.local/bin/smart_chat.py — Cách đổi model KHÔNG reset context:
child.sendline(f"/model {model_id}")  # Gửi lệnh /model vào claude đang chạy
child.expect(r'(?i)> ')              # Chờ xác nhận đổi xong
child.sendline(user_input)           # Gửi câu hỏi với model MỚI
```

**Khác biệt với cách thông thường:**
- ❌ Cách cũ: Mỗi câu `claude --model opus -p "..."` → **tạo session mới** → mất context → phải re-send system prompt → tốn nhiều token
- ✅ Smart Chat PRO: Dùng `/model` để đổi **ngay trong phiên hiện tại** → giữ toàn bộ context → chỉ tốn token của câu hỏi mới

### 9. Compact Mechanism — Nén Context Khi Quá Dài

```json
// tengu_sm_config — Smart Memory / Compact trigger:
{
  "minimumMessageTokensToInit": 150000,   // Khi conversation vượt 150K tokens
  "minimumTokensBetweenUpdate": 40000,    // Compact lại sau mỗi 40K tokens mới
  "toolCallsBetweenUpdates": 10           // Hoặc sau mỗi 10 tool calls
}
```

**Cách hoạt động:** Khi conversation dài, Claude tự tóm tắt lịch sử cũ → replace bằng summary ngắn gọn → giải phóng context window cho nội dung mới. Kết hợp với `rolling_compact` trong prompt cache allowlist.

### 10. Two-Stage Auto Classifier — Không Gọi Model Lớn Khi Không Cần

```json
// tengu_auto_mode_config:
{
  "enabled": "enabled",
  "twoStageClassifier": true  // Phân loại 2 tầng trước khi escalate
}
```

Thay vì luôn dùng model mạnh nhất, Claude Code tự phân loại độ phức tạp:
- **Stage 1**: Classifier nhẹ kiểm tra task đơn giản không?
- **Stage 2**: Nếu phức tạp mới leo lên model lớn hơn

### 📊 Tổng Hợp Mức Tiết Kiệm Token

| Cơ chế | Loại tối ưu | Mức tiết kiệm ước tính |
|:--------|:------------|:-----------------------|
| **Prompt Cache (1h)** | Input tokens | **~90%** input cost trong phiên dài |
| **Token Budget per Tool** | Output overflow | Ngăn 1 tool dùng toàn bộ quota |
| **AI Classifier dùng Haiku** | Classification cost | **60x** rẻ hơn dùng Opus để classify |
| **DeepSeek routing** | Quick queries | **100%** miễn phí cho câu hỏi nhanh |
| **Headroom rate control** | Rate limit hits | Tránh lãng phí retry do bị throttle |
| **AgentMemory long-term** | Context repetition | Giảm ~30% context mỗi phiên mới |
| **Smart Chat `/model` switch** | Session overhead | Tiết kiệm system prompt re-send |
| **Compact mechanism** | Long conversation | Giữ context trong 200K window limit |
| **Brevity mode `focused`** | Output verbosity | Giảm ~20-30% response length |

---

## 🚀 HƯỚNG DẪN CÀI ĐẶT (Cho người mới)

> [!IMPORTANT]
> **Yêu cầu tiên quyết:** macOS + Terminal + Claude Code CLI đã cài đặt + Tài khoản 9Router

### Bước 1: Cài Claude Code CLI
```bash
npm install -g @anthropic-ai/claude-code
```

### Bước 2: Cài 9Router (Local LLM Gateway)
```bash
npm install -g 9router
# Hoặc theo hướng dẫn tại: https://9router.dev
```

### Bước 3: Cài httpx (cho AI Classifier)
```bash
pip3 install httpx
```

### Bước 4: Copy file AI Classifier
```bash
mkdir -p ~/.local/bin
# Copy file ai-classify.py vào ~/.local/bin/
chmod +x ~/.local/bin/ai-classify.py
```

### Bước 5: Thêm Smart Router vào ~/.zshrc
```bash
# Chạy script tự động:
bash _scripts/setup_smart_router.sh

# Hoặc copy thủ công phần "SMART AI ROUTER v3" từ ~/.zshrc vào máy bạn
```

### Bước 6: Cấu hình API Key + Base URL
```bash
# Thêm vào ~/.zshrc:
export ANTHROPIC_BASE_URL="http://127.0.0.1:8787/v1"  # 9Router local
export ANTHROPIC_API_KEY="your-9router-key-here"
```

### Bước 7: Reload và test
```bash
source ~/.zshrc
chat  # Nên hiện giao diện Smart Chat REPL
```

---

## 📁 CẤU TRÚC THƯ MỤC WORKSPACE

```
~/Desktop/Cowork/
├── AGENTS.md              ← System prompt toàn cục (Enterprise AI Architect)
├── CLAUDE.md              ← Context công việc (Ahamove Ops)
├── Readme-Pulu.md         ← Hướng dẫn sử dụng nhanh
│
├── .claude/
│   ├── agents/            ← 9 Sub-Agents chuyên biệt
│   │   ├── sql-analyst.md
│   │   ├── report-writer.md
│   │   ├── competitive-intel.md
│   │   ├── driver-comms.md
│   │   ├── landing-page-builder.md
│   │   ├── content-writer.md
│   │   ├── event-planner.md
│   │   ├── meeting-prep.md
│   │   └── weekly-review.md
│   ├── settings.json      ← Auto-sync hook (GitHub + Drive)
│   └── settings.local.json ← Permissions (WebFetch, Bash, Read...)
│
├── _scripts/
│   ├── setup_smart_router.sh   ← Script cài đặt tự động
│   ├── github-auto-sync.sh
│   ├── sync-push.sh
│   └── sync-pull.sh
│
└── Output/
    └── Ahamove/
        ├── 01. STRATEGY_PLANNING/
        ├── 02. CAMPAIGNS_PROJECTS/
        ├── 03. DRIVER_COMMUNITY/
        ├── 04. OPS_METRICS/
        ├── 05. ANALYSIS_REPORTS/
        ├── 06. COMPETITIVE_INTEL/
        └── 07. TEAM_MANAGEMENT/
```

---

## 💡 WORKFLOW THỰC TẾ — Các Tình Huống Phổ Biến

### Tình huống 1: Phân tích chiến lược buổi sáng
```bash
chat
You ▶ phân tích retention driver Q2 và đề xuất action plan Q3
# → Tự động route: 🧠 OPUS 4.8 (AI-routed)
# → Sub-agent sql-analyst.md kích hoạt nếu cần query
```

### Tình huống 2: Viết thông báo Zalo cho tài xế
```bash
chat
You ▶ viết thông báo zalo thay đổi cơ chế thưởng tháng 7
# → Tự động route: ⚡ GEMINI PRO (AI-routed)
# → Sub-agent driver-comms.md kích hoạt
```

### Tình huống 3: Xuất báo cáo ra file Word
```bash
chat
You ▶ tạo file docx báo cáo weekly review tuần này
# → Tự động route: 💻 SONNET 4.6 + TOOL MODE
# → Màn hình bật chế độ Tool (có thanh progress)
# → Sau khi xong: gõ /exit để trở lại chat
```

### Tình huống 4: Hỏi nhanh không cần vào chat
```bash
ai "deepseek v4 khác gì deepseek v3?"
# → Tự động route: 💨 DEEPSEEK (regex) — trả lời ngay
```

### Tình huống 5: Viết proposal tiếng Anh cho HQ
```bash
c-gpt
# Vào thẳng GPT-5.5 — không qua routing
```

---

## ⚖️ ĐIỂM MẠNH & GIỚI HẠN

### ✅ Điểm mạnh
- **Zero friction:** Gõ `chat` là xong — không cần nhớ tên model
- **Tiết kiệm quota:** Model đắt (Opus) chỉ dùng khi thực sự cần
- **Fallback thông minh:** AI Classifier → Regex → Default Opus (3 lớp an toàn)
- **Context persistence:** Giữ ngữ cảnh xuyên suốt buổi chat (`--continue`)
- **Tool mode tự động:** File/code tasks tự bật quyền đầy đủ
- **Auto-backup:** GitHub + Google Drive sau mỗi phiên

### ⚠️ Giới hạn cần lưu ý
- **Yêu cầu 9Router đang chạy:** Nếu tắt 9Router, mọi lệnh đều fail
- **AI Classifier cần internet:** Nếu mất mạng → tự động fallback về Regex (vẫn hoạt động)
- **Context reset khi thoát chat:** Gõ `exit` xong mở lại `chat` là mất ngữ cảnh cũ
- **Tool Mode cần gõ /exit thủ công:** Sau khi tạo file xong phải thoát bằng tay

---

## 🔧 TROUBLESHOOTING NHANH

| Vấn đề | Nguyên nhân | Giải pháp |
|:--------|:-----------|:----------|
| `command not found: chat` | zshrc chưa load | `source ~/.zshrc` |
| AI không trả lời | 9Router chưa chạy | `9router --tray` hoặc check port 8787 |
| Classifier trả về FALLBACK liên tục | httpx chưa cài | `pip3 install httpx` |
| Tool Mode không bật | Từ khóa không khớp | Thêm "tạo file" / "xuất" / "docx" vào prompt |
| Auto-sync lỗi | Git chưa config remote | `git remote add origin <url>` |

---

## 📦 CHECKLIST ĐỂ CHIA SẺ VỚI NGƯỜI KHÁC

Khi muốn setup cho bạn bè/đồng nghiệp, đảm bảo họ có đủ:

- [ ] macOS (hệ thống tương đương Linux cũng được với điều chỉnh nhỏ)
- [ ] Node.js + npm (để cài Claude Code CLI)
- [ ] Python 3.8+ với `httpx` (`pip3 install httpx`)
- [ ] Claude Code CLI (`npm install -g @anthropic-ai/claude-code`)
- [ ] Tài khoản 9Router + API Key
- [ ] 9Router đang chạy trên port 8787
- [ ] File `ai-classify.py` tại `~/.local/bin/`
- [ ] Phần Smart Router trong `~/.zshrc`
- [ ] Thư mục workspace với `CLAUDE.md` + `AGENTS.md` + `.claude/agents/`

---

*📌 Hệ thống này được xây dựng và tinh chỉnh bởi Lê Phương Khanh — Driver Management Leader @ Ahamove*
*🔄 Version: Smart Router v3 | AI Classifier + Regex Fallback + Hybrid Tool Mode*
