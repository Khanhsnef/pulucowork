# Khung Mô Hình Học Máy Dự Báo Driver Churn — Ahamove Bike Instant

**Phiên bản:** 2026-07 | Driver Management & Data Science Team | Tài liệu chiến lược nội bộ

---

## Executive Summary

*   📊 **Executive Summary:** Rời bỏ (Churn) của tài xế công nghệ là một quá trình dịch chuyển hành vi diễn ra từ 14–21 ngày trước khi tài xế thực sự dừng hoạt động hẳn. Framework này chuyển dịch năng lực phát hiện từ **Heuristic Clustering** (quy tắc phân cụm tĩnh B1-B5) sang **Mô hình Học máy Dự báo (Predictive Machine Learning Model)**. Bằng cách khai thác các tín hiệu cực ngắn hạn (micro-signals) trong 7 ngày gần nhất về hiệu suất thu nhập, độ trễ nhận đơn, tỷ lệ hủy đơn chủ động (cancellation detail), mô hình cho phép can thiệp tự động ở "Cửa sổ vàng" (ngày thứ 3 đến ngày thứ 7 kể từ khi lệch hành vi), tối ưu hóa chi phí giữ chân tài xế (Retention Cost) và duy trì chất lượng dịch vụ SLA.
*   🎯 **Mục tiêu Kinh doanh (Business Objectives):**
    *   **Giảm tỷ lệ Churn** của nhóm đối tượng cốt lõi (Tenure > 60 ngày, Tier R1 & R2) xuống dưới **5%/tháng** (giảm 15% so với baseline).
    *   **Tối ưu hóa ROI ngân sách giữ chân:** Tự động hóa phân bổ ngân sách khuyến khích (incentive budget) tập trung 100% vào tập khách hàng *Persuadables* (những người sẽ rời đi NẾU không có can thiệp), thay vì lãng phí vào nhóm *Sure Things* (chắc chắn chạy) hoặc *Lost Causes* (chắc chắn bỏ).
    *   **Bảo vệ SLA hệ thống:** Đảm bảo tỷ lệ Fulfillment Rate (FR) toàn hệ thống vào peak hours luôn duy trì ổn định trên **92%**.
*   📈 **Chỉ số Cốt lõi (Important KPIs):**
    *   **Model Performance:** Area Under Precision-Recall Curve (PR-AUC) > **0.82**; F1-score > **0.78** (ưu tiên Precision để tránh phân bổ promo sai đối tượng).
    *   **Business Impact:** Driver Churn Rate (hàng tháng), Retention Cost per Order (CPO Retention), Acceptance Rate (AR), Peak Hour Fulfillment Rate (FR).

---

## 1. KHUNG PHÂN TÍCH (ANALYSIS FRAMEWORK)

### 1.1 Phân tích Mô tả (Descriptive Analysis - Hiện trạng)
*   **Hạ tầng Vận hành hiện tại:** Dữ liệu hành vi của tài xế đang được lưu trữ trên DWH (BigQuery) thông qua các bảng lõi: dữ liệu đăng ký/profile (`supplier_raw`), thời gian online (`ops_suppliers_online_hours`), hiệu suất hàng ngày (`fct_supplier_performance`), lịch sử đơn hàng và sự kiện tương tác ứng dụng (`raw_performance`), chi tiết hủy đơn (`fact_cancellation_detail`). Quy trình phát hiện hiện tại đang dựa trên câu lệnh SQL báo cáo định kỳ theo tuần (Heuristic), phân loại thủ công dựa trên số ngày inactive tuyệt đối (ngưỡng 30 ngày) và phân cụm tĩnh (B1-B5).
*   **Benchmarks Hiệu suất:** Đối với mô hình vận hành On-demand Gig Economy (Grab, Be, Lalamove, XanhSM), việc tài xế không hoạt động quá 14 ngày mà không báo trước có xác suất churn vĩnh viễn lên tới **85%**. Chu kỳ hình thành thói quen (habit formation) của tài xế mới kéo dài trong **60 ngày đầu tiên** (D60 retention cliff). Tỷ lệ churn tự nhiên hàng tháng của Ahamove Bike hiện đang dao động ở mức **15-20%**, cao hơn đáng kể so với mô hình tài xế có bảo hiểm của XanhSM (15-20%/năm) và mô hình cam kết của Swiggy StepUp (10-15%).
*   **Hệ sinh thái Liên quan:**
    *   *BI & Data Science:* Chịu trách nhiệm bảo trì data pipeline, tính toán Feature Store hàng ngày, huấn luyện và đánh giá mô hình học máy.
    *   *Driver Operations:* Điều phối các chương trình can thiệp thực địa (Captain, Driver Community, Event Offline).
    *   *Product & Growth:* Thiết lập trigger push thông báo cá nhân hóa tự động thông qua CRM hệ thống dựa trên điểm số rủi ro (Risk Scores) trả về từ model.

### 1.2 Phân tích Chẩn đoán (Diagnostic Analysis - Nguyên nhân gốc rễ)
*   **Khoảng trống Chất lượng (Quality Gaps):** Việc sử dụng ngưỡng churn cố định 30 ngày dẫn đến tình trạng "phát hiện khi sự đã rồi". Khi tài xế đã offline 30 ngày, họ đã xóa app, rút tiền ký quỹ hoặc đăng ký chạy cho nền tảng đối thủ (switching cost đã được trả xong). Ngoài ra, hệ thống heuristic không cá nhân hóa ngưỡng nghỉ của tài xế, dẫn đến việc đánh đồng một tài xế part-time chạy 1 ngày/tuần (nghỉ 6 ngày liên tục là bình thường) với một tài xế full-time chạy liên tục (nghỉ 3 ngày đã là dấu hiệu At-Risk nghiêm trọng).
*   **Điểm nghẽn Vận hành (Bottlenecks):** Sự mất cân bằng cung-cầu cục bộ trong các khung giờ cao điểm (Peak-hour supply deficit). Tài xế thường có xu hướng bỏ ứng dụng khi EPH (Earnings Per Hour) thực tế của họ trong 7 ngày gần nhất giảm mạnh (>20%) do phân bổ đơn hàng không tối ưu, thời gian chờ tại các Mini-hub/Station quá lâu, hoặc do mật độ tài xế tập trung tại một khu vực quá dày đặc.
*   **Lệch pha Chiến lược (Misalignments):** Ngân sách chạy khuyến khích (Incentive Budget) hiện được phân bổ đại trà (Mass Promo) hoặc dựa trên Rank lịch sử (AhaBenefits). Điều này dẫn đến hiện tượng tài xế R1/R2 nhận thưởng nhưng vẫn churn vì họ tối đa hóa thu nhập ngắn hạn trên cả hai app (Grab/Ahamove song song), trong khi ngân sách không được tập trung đúng vào thời điểm tài xế bắt đầu chán nản (khi EPH sụt giảm liên tục).

### 1.3 Phân tích Dự báo (Predictive Analysis - Thiết kế Mô hình ML)

#### A. Định nghĩa Bài toán (Problem Formulation)
Chúng ta sẽ thiết kế bài toán dưới dạng **Phân loại Nhị phân (Binary Classification)** sử dụng phương pháp **Rolling Window**:
*   **Observation Date (Ngày quan sát - $T_{obs}$):** Mỗi ngày, mô hình sẽ quét toàn bộ tập tài xế active trong 30 ngày qua để dự báo.
*   **Feature Window (Cửa sổ đặc trưng - $[T_{obs} - 30, T_{obs}]$):** Trích xuất toàn bộ đặc trưng hành vi của tài xế trong 30 ngày trước ngày quan sát (chia nhỏ thành các khung 1d, 3d, 7d, 14d, 30d để tính toán tốc độ thay đổi/quỹ đạo hành vi).
*   **Label Window (Cửa sổ nhãn - $[T_{obs} + 1, T_{obs} + 14]$):** Định nghĩa tài xế Churn ($Y = 1$) nếu họ **không hoàn thành bất kỳ chuyến đi nào (completed trips = 0) trong vòng 14 ngày tiếp theo**. Nếu có ít nhất 1 chuyến đi, $Y = 0$.

```text
                  Feature Window (30 ngày)               Label Window (14 ngày)
        |---------------------------------------|=======================================|
     T_obs-30                                 T_obs                                   T_obs+14
                                          (Ngày Dự Báo)
```

#### B. Thiết kế Feature Engineering (4 Nhóm Đặc Trưng Lõi)

1.  **Recency / Inactivity (Độ cận và Sự không hoạt động):**
    *   `gap_current`: Số ngày liên tiếp không chạy tính đến $T_{obs}$.
    *   `pgb` (Personal Gap Baseline): Trung vị số ngày nghỉ giữa các chuyến trong 60 ngày qua.
    *   `gap_trend`: `gap_current / NULLIF(pgb, 0)` (Tài xế đang lệch bao nhiêu lần so với thói quen nghỉ ngơi bình thường của họ).
2.  **Performance & Activity (Hiệu suất và Cường độ hoạt động):**
    *   `trips_7d`, `trips_30d`: Số chuyến hoàn thành trong 7 ngày và 30 ngày gần nhất.
    *   `trips_trajectory`: Tỷ lệ thay đổi số chuyến `trips_7d / (trips_30d / 4) - 1`.
    *   `online_hours_7d`, `online_hours_30d`: Số giờ online tương ứng.
    *   `eph_7d`, `eph_30d`: Thu nhập ròng trên mỗi giờ online (Earnings Per Hour) bao gồm cả thưởng.
    *   `eph_trajectory`: `eph_7d / NULLIF(eph_30d, 0) - 1` (Quỹ đạo thu nhập đang đi xuống hay đi lên).
3.  **Order Acceptance Behavior (Hành vi Nhận đơn - Phản hồi Nhu cầu):**
    *   `total_requests_7d`, `total_requests_30d`: Tổng số lượt đơn hàng đẩy về máy tài xế (ping).
    *   `acceptance_rate_7d`, `acceptance_rate_30d`: Số đơn chấp nhận / Tổng số lượt ping.
    *   `ar_trajectory`: `acceptance_rate_7d / NULLIF(acceptance_rate_30d, 0) - 1`.
    *   `ignore_rate_7d`: Tỷ lệ đơn hàng bị trôi qua (ignored) không bấm nhận/từ chối trên tổng yêu cầu.
4.  **Cancellation Behavior (Hành vi Hủy đơn - Ma sát vận hành):**
    *   `cancellation_rate_7d`, `cancellation_rate_30d`: Số đơn hủy / Số đơn đã nhận.
    *   `driver_cancellation_rate_7d`: Tỷ lệ tự hủy từ phía tài xế chủ động.
    *   `cr_poc_rate_7d`: Tỷ lệ hủy đơn do tài xế yêu cầu hủy (phân tích qua text comment: "Driver ask", "by supplier" hoặc lý do "poc").
    *   `cr_trajectory`: `cancellation_rate_7d / NULLIF(cancellation_rate_30d, 0) - 1` (Hành vi hủy đơn tăng đột biến là chỉ số báo trước sự ức chế vận hành).

#### C. SQL Feature Store Extraction (Dự thảo Query chuẩn trên BigQuery DWH)

Đoạn mã SQL dưới đây trích xuất tự động toàn bộ Feature Set và Label cho một ngày quan sát cụ thể ($T_{obs} = \text{'2026-06-30'}$):

```sql
-- =========================================================================
-- SQL PIPELINE: EXTRACTION FEATURE STORE & LABELS CHO MÔ HÌNH CHURN
-- Target database: BigQuery (Ahamove DWH)
-- Observation Date: 2026-06-30
-- =========================================================================

DECLARE obs_date DATE DEFAULT DATE('2026-06-30');

-- Bước 1: Xác định danh sách tài xế active hợp lệ (đã từng chạy trước obs_date)
WITH active_drivers AS (
    SELECT
        id                                                                    AS supplier_id,
        DATE(first_complete_time, 'Asia/Saigon')                             AS dfd_date,
        CASE WHEN city_id IN ('HAN','SGN') THEN city_id ELSE 'EXP' END      AS city_id,
        JSON_EXTRACT_SCALAR(extra, '$.vehicle_type')                          AS vehicle_type
    FROM ahamove_supplier_raw.supplier_raw
    WHERE DATE(first_complete_time, 'Asia/Saigon') <= obs_date
      AND JSON_EXTRACT_SCALAR(extra, '$.vehicle_type') IN ('MOTORBIKE','EV-BIKE')
      AND COALESCE(email, 'a') NOT LIKE '%ahamove_ka_lazada%'
      AND COALESCE(services, 'a') NOT LIKE '%VNM-WH-DELIVERY%'
      AND COALESCE(services, 'a') NOT LIKE '%VNM-WH-VENDOR%'
      AND COALESCE(tags, 'a') NOT LIKE '%SALESFORCE%'
      AND partitioned_create_time >= '2010-01-01'
),

-- Bước 2: Tính toán Personal Gap Baseline (PGB) dựa trên lịch sử 60 ngày
driver_gaps AS (
    SELECT
        supplier_id,
        period,
        DATE_DIFF(period, prev_period, DAY) AS gap_days
    FROM (
        SELECT 
            supplier_id, 
            DATE(period) AS period,
            LAG(DATE(period)) OVER (PARTITION BY supplier_id ORDER BY DATE(period)) AS prev_period
        FROM ahamove_archive_ops.fct_supplier_performance
        WHERE period >= DATE_SUB(obs_date, INTERVAL 60 DAY)
          AND period <= obs_date
          AND stp_complete > 0
    )
    WHERE prev_period IS NOT NULL
),
pgb_store AS (
    SELECT
        supplier_id,
        COALESCE(PERCENTILE_CONT(gap_days, 0.5) OVER(PARTITION BY supplier_id), 1.0) AS pgb
    FROM driver_gaps
    QUALIFY ROW_NUMBER() OVER(PARTITION BY supplier_id ORDER BY period DESC) = 1
),

-- Bước 3: Thu thập dữ liệu hiệu suất (Trips, Income, Cancellations) trong Feature Window
performance_features AS (
    SELECT
        p.supplier_id,
        -- Trips & Active Days
        SUM(CASE WHEN p.period >= DATE_SUB(obs_date, INTERVAL 7 DAY) THEN p.stp_complete ELSE 0 END) AS trips_7d,
        SUM(p.stp_complete) AS trips_30d,
        COUNT(DISTINCT CASE WHEN p.period >= DATE_SUB(obs_date, INTERVAL 7 DAY) AND p.stp_complete > 0 THEN p.period END) AS active_days_7d,
        COUNT(DISTINCT CASE WHEN p.stp_complete > 0 THEN p.period END) AS active_days_30d,
        
        -- Income
        SUM(CASE WHEN p.period >= DATE_SUB(obs_date, INTERVAL 7 DAY) THEN p.order_income + p.reward_income ELSE 0 END) AS income_7d,
        SUM(p.order_income + p.reward_income) AS income_30d,
        
        -- Cancellations
        SUM(CASE WHEN p.period >= DATE_SUB(obs_date, INTERVAL 7 DAY) THEN p.accept_order ELSE 0 END) AS accept_order_7d,
        SUM(p.accept_order) AS accept_order_30d,
        SUM(CASE WHEN p.period >= DATE_SUB(obs_date, INTERVAL 7 DAY) THEN p.cancel_order ELSE 0 END) AS cancel_order_7d,
        SUM(p.cancel_order) AS cancel_order_30d,
        
        -- Rating
        SAFE_DIVIDE(
            SUM(p.rating_5star*5 + p.rating_4star*4 + p.rating_3star*3 + p.rating_2star*2 + p.rating_1star),
            SUM(p.rating_5star + p.rating_4star + p.rating_3star + p.rating_2star + p.rating_1star)
        ) AS avg_rating_30d,
        
        -- Recency
        DATE_DIFF(obs_date, MAX(CASE WHEN p.stp_complete > 0 THEN p.period END), DAY) AS gap_current
    FROM ahamove_archive_ops.fct_supplier_performance p
    WHERE p.period >= DATE_SUB(obs_date, INTERVAL 30 DAY)
      AND p.period <= obs_date
    GROUP BY 1
),

-- Bước 4: Thu thập dữ liệu online hours
online_features AS (
    SELECT
        supplier_id,
        SUM(CASE WHEN period >= DATE_SUB(obs_date, INTERVAL 7 DAY) THEN online_hours ELSE 0 END) AS online_hours_7d,
        SUM(online_hours) AS online_hours_30d
    FROM ahamove_archive.ops_suppliers_online_hours
    WHERE period >= DATE_SUB(obs_date, INTERVAL 30 DAY)
      AND period <= obs_date
    GROUP BY 1
),

-- Bước 5: Chi tiết hành vi nhận đơn / trôi đơn (Acceptance Rate) từ raw_performance
demand_features AS (
    SELECT
        r.supplier_id,
        COUNT(DISTINCT CASE WHEN r.order_date >= DATE_SUB(obs_date, INTERVAL 7 DAY) THEN r.order_id END) AS total_requests_7d,
        COUNT(DISTINCT r.order_id) AS total_requests_30d,
        
        COUNT(DISTINCT CASE WHEN r.order_date >= DATE_SUB(obs_date, INTERVAL 7 DAY) AND r.accept_time IS NOT NULL THEN r.order_id END) AS accepted_requests_7d,
        COUNT(DISTINCT CASE WHEN r.accept_time IS NOT NULL THEN r.order_id END) AS accepted_requests_30d
    FROM ahamove_raw.raw_performance r
    WHERE r.order_date >= DATE_SUB(obs_date, INTERVAL 30 DAY)
      AND r.order_date <= obs_date
      AND r.status IN ('CANCELLED','COMPLETED')
      AND r.seq <> 0
      AND r.user_id NOT IN ('84862151477','84862151000')
      AND NOT REGEXP_CONTAINS(r.service_id, '-(INTERCT|TRUCK|RIDE|VAN|PARTNER|TRICYCLE|TEST|PARTNER-BIGC|ASTGROUP|INTERNAL|HUB|BKN|RENT|MASAN)-?')
    GROUP BY 1
),

-- Bước 6: Chi tiết hành vi hủy đơn do tài xế yêu cầu (Cancel POC)
cancellation_details AS (
    SELECT
        supplier_id,
        COUNT(DISTINCT CASE WHEN order_date >= DATE_SUB(obs_date, INTERVAL 7 DAY) AND (
            cancel_comment LIKE '%for supplier%'
            OR cancel_comment LIKE '%Driver ask%'
            OR cancel_comment LIKE '%by Driver%'
            OR cancel_comment LIKE '%by Supplier%'
            OR cancel_comment LIKE '%by supplier%'
            OR cancel_by = 'supplier'
        ) AND reason_type = 'poc' THEN order_id END) AS cancel_poc_7d
    FROM ahamove_archive_ops.fact_cancellation_detail
    WHERE order_date >= DATE_SUB(obs_date, INTERVAL 30 DAY)
      AND order_date <= obs_date
      AND partner != 'tiktokshop'
    GROUP BY 1
),

-- Bước 7: Xác định Label thực tế trong Label Window (14 ngày tiếp theo)
labels AS (
    SELECT
        supplier_id,
        -- Nhãn Churn: 1 nếu không có chuyến nào hoàn thành trong 14 ngày tiếp theo, ngược lại 0
        CASE WHEN SUM(stp_complete) IS NULL OR SUM(stp_complete) = 0 THEN 1 ELSE 0 END AS is_churn
    FROM ahamove_archive_ops.fct_supplier_performance
    WHERE period >= DATE_ADD(obs_date, INTERVAL 1 DAY)
      AND period <= DATE_ADD(obs_date, INTERVAL 14 DAY)
    GROUP BY 1
)

-- Bước 8: Kết hợp Feature Store + Label hoàn chỉnh
SELECT
    d.supplier_id,
    d.city_id,
    d.vehicle_type,
    DATE_DIFF(obs_date, d.dfd_date, DAY) AS tenure_days,
    
    -- Recency
    COALESCE(p.gap_current, 30) AS gap_current,
    COALESCE(pgb.pgb, 1.0) AS pgb,
    SAFE_DIVIDE(COALESCE(p.gap_current, 30), COALESCE(pgb.pgb, 1.0)) AS gap_ratio,
    
    -- Trips
    COALESCE(p.trips_7d, 0) AS trips_7d,
    COALESCE(p.trips_30d, 0) AS trips_30d,
    SAFE_DIVIDE(COALESCE(p.trips_7d, 0), SAFE_DIVIDE(COALESCE(p.trips_30d, 0), 4.0)) - 1.0 AS trips_trajectory,
    
    -- Income & EPH (Earnings Per Hour)
    COALESCE(p.income_7d, 0) AS income_7d,
    COALESCE(p.income_30d, 0) AS income_30d,
    SAFE_DIVIDE(COALESCE(p.income_7d, 0), NULLIF(COALESCE(o.online_hours_7d, 0), 0)) AS eph_7d,
    SAFE_DIVIDE(COALESCE(p.income_30d, 0), NULLIF(COALESCE(o.online_hours_30d, 0), 0)) AS eph_30d,
    SAFE_DIVIDE(
        SAFE_DIVIDE(COALESCE(p.income_7d, 0), NULLIF(COALESCE(o.online_hours_7d, 0), 0)),
        NULLIF(SAFE_DIVIDE(COALESCE(p.income_30d, 0), NULLIF(COALESCE(o.online_hours_30d, 0), 0)), 0)
    ) - 1.0 AS eph_trajectory,
    
    -- Online Hours
    COALESCE(o.online_hours_7d, 0.0) AS online_hours_7d,
    COALESCE(o.online_hours_30d, 0.0) AS online_hours_30d,
    
    -- AR (Acceptance Rate)
    SAFE_DIVIDE(COALESCE(dem.accepted_requests_7d, 0), NULLIF(COALESCE(dem.total_requests_7d, 0), 0)) AS ar_7d,
    SAFE_DIVIDE(COALESCE(dem.accepted_requests_30d, 0), NULLIF(COALESCE(dem.total_requests_30d, 0), 0)) AS ar_30d,
    SAFE_DIVIDE(
        SAFE_DIVIDE(COALESCE(dem.accepted_requests_7d, 0), NULLIF(COALESCE(dem.total_requests_7d, 0), 0)),
        NULLIF(SAFE_DIVIDE(COALESCE(dem.accepted_requests_30d, 0), NULLIF(COALESCE(dem.total_requests_30d, 0), 0)), 0)
    ) - 1.0 AS ar_trajectory,
    
    -- CR (Cancellation Rate)
    SAFE_DIVIDE(COALESCE(p.cancel_order_7d, 0), NULLIF(COALESCE(p.accept_order_7d, 0), 0)) AS cr_7d,
    SAFE_DIVIDE(COALESCE(p.cancel_order_30d, 0), NULLIF(COALESCE(p.accept_order_30d, 0), 0)) AS cr_30d,
    SAFE_DIVIDE(COALESCE(c_poc.cancel_poc_7d, 0), NULLIF(COALESCE(p.accept_order_7d, 0), 0)) AS cr_poc_7d,
    
    -- Ratings
    COALESCE(p.avg_rating_30d, 5.0) AS avg_rating_30d,
    
    -- TARGET LABEL
    COALESCE(l.is_churn, 1) AS is_churn  -- Nếu không tìm thấy hoạt động trong 14 ngày tới thì nhãn mặc định là churn (1)

FROM active_drivers d
LEFT JOIN performance_features p    ON d.supplier_id = p.supplier_id
LEFT JOIN pgb_store pgb             ON d.supplier_id = pgb.supplier_id
LEFT JOIN online_features o         ON d.supplier_id = o.supplier_id
LEFT JOIN demand_features dem       ON d.supplier_id = dem.supplier_id
LEFT JOIN cancellation_details c_poc ON d.supplier_id = c_poc.supplier_id
LEFT JOIN labels l                  ON d.supplier_id = l.supplier_id
WHERE d.city_id != 'EXP'
  -- Chỉ huấn luyện trên tập tài xế có hoạt động tối thiểu trong 30 ngày qua để tránh nhiễu từ tài xế đã churn từ trước
  AND COALESCE(p.active_days_30d, 0) >= 1;
```

#### D. Python Training Pipeline Template (LightGBM)

Sau khi trích xuất Feature Store thông qua SQL, dữ liệu sẽ được đưa vào pipeline học máy dưới đây để huấn luyện mô hình dự báo xác suất Churn:

```python
import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score, average_precision_score
import warnings
warnings.filterwarnings('ignore')

# 1. Tải tập dữ liệu từ kết quả SQL Query
# Giả sử file raw_data.csv chứa kết quả trích xuất từ BigQuery
df = pd.read_csv('churn_feature_store.csv')

# 2. Tiền xử lý dữ liệu (Handling Categorical & Missing Values)
categorical_cols = ['city_id', 'vehicle_type']
for col in categorical_cols:
    df[col] = df[col].astype('category')

# Điền các giá trị thiếu logic
df['trips_trajectory'] = df['trips_trajectory'].fillna(0)
df['eph_trajectory'] = df['eph_trajectory'].fillna(0)
df['ar_trajectory'] = df['ar_trajectory'].fillna(0)
df['eph_7d'] = df['eph_7d'].fillna(0)
df['eph_30d'] = df['eph_30d'].fillna(0)
df['ar_7d'] = df['ar_7d'].fillna(0)
df['ar_30d'] = df['ar_30d'].fillna(0)
df['cr_7d'] = df['cr_7d'].fillna(0)
df['cr_30d'] = df['cr_30d'].fillna(0)
df['cr_poc_7d'] = df['cr_poc_7d'].fillna(0)

# Xác định danh sách features và target
features = [
    'tenure_days', 'gap_current', 'pgb', 'gap_ratio',
    'trips_7d', 'trips_30d', 'trips_trajectory',
    'income_7d', 'income_30d', 'eph_7d', 'eph_30d', 'eph_trajectory',
    'online_hours_7d', 'online_hours_30d',
    'ar_7d', 'ar_30d', 'ar_trajectory',
    'cr_7d', 'cr_30d', 'cr_poc_7d', 'avg_rating_30d',
    'city_id', 'vehicle_type'
]
target = 'is_churn'

# 3. Phân tách tập huấn luyện & kiểm thử (Time-based split hoặc Stratified split)
# Trong môi trường sản phẩm thực tế, khuyên dùng Time-based Split (ví dụ: Train trên T5, Test trên T6)
# Ở đây ta sử dụng Stratified Train-Test Split để đảm bảo phân bổ nhãn đồng đều
X = df[features]
y = df[target]

X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# 4. Cấu hình tham số LightGBM Classifier
# Thiết kế tối ưu cho dữ liệu mất cân bằng (Imbalanced class weights)
scale_pos_weight = (len(y_train) - sum(y_train)) / sum(y_train)

params = {
    'objective': 'binary',
    'metric': 'aucpr',  # Tập trung tối ưu diện tích dưới đường cong Precision-Recall
    'boosting_type': 'gbdt',
    'learning_rate': 0.05,
    'num_leaves': 31,
    'max_depth': 6,
    'feature_fraction': 0.8,
    'bagging_fraction': 0.8,
    'bagging_freq': 5,
    'scale_pos_weight': scale_pos_weight,  # Điều chỉnh trọng số lớp Churn
    'verbose': -1,
    'random_state': 42
}

# 5. Huấn luyện mô hình với Early Stopping
train_data = lgb.Dataset(X_train, label=y_train)
val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)

print("Đang huấn luyện mô hình LightGBM...")
model = lgb.train(
    params,
    train_data,
    num_boost_round=1000,
    valid_sets=[train_data, val_data],
    callbacks=[
        lgb.early_stopping(stopping_rounds=50, verbose=True),
        lgb.log_evaluation(period=50)
    ]
)

# 6. Đánh giá mô hình trên tập kiểm thử
y_pred_proba = model.predict(X_val, num_iteration=model.best_iteration)
y_pred_binary = (y_pred_proba >= 0.5).astype(int)

print("\n=== ĐÁNH GIÁ MÔ HÌNH TRÊN TẬP KIỂM THỬ ===")
print(f"ROC-AUC: {roc_auc_score(y_val, y_pred_proba):.4f}")
print(f"PR-AUC (Average Precision): {average_precision_score(y_val, y_pred_proba):.4f}")
print("\nBáo cáo phân loại chi tiết (Classification Report):")
print(classification_report(y_val, y_pred_binary))

# 7. Phân tích Feature Importance (Mức độ đóng góp của các biến số)
importance = pd.DataFrame({
    'feature': features,
    'importance': model.feature_importance(importance_type='gain')
}).sort_values('importance', ascending=False)

print("\n=== TOP 10 ĐẶC TRƯNG HÀNH VI QUAN TRỌNG NHẤT ===")
print(importance.head(10).to_string(index=False))

# Lưu mô hình đã huấn luyện để triển khai API dự báo hàng ngày
model.save_model('lgbm_driver_churn_model.txt')
```

### 1.4 Phân tích Đề xuất (Prescriptive Analysis - Khuyến nghị Chiến lược)

#### A. Tối ưu hóa Ngân sách giữ chân tài xế (Targeted CRM Strategy)
Mô hình sẽ sinh ra giá trị xác suất Churn chạy từ `0.0` đến `1.0`. Dựa vào xác suất này kết hợp với giá trị trọn đời tài xế (LTV) và phân khúc hành vi (Clusters B1-B5), chúng ta sẽ thiết kế một ma trận ra quyết định thông minh:

```mermaid
graph TD
    A[Dự báo Churn Probability P] --> B{Xác định mức độ rủi ro}
    B -->|P < 0.3| C[Green Zone - Giữ nguyên chính sách thường]
    B -->|0.3 <= P < 0.6| D[Yellow Zone - At-Risk nhẹ]
    B -->|P >= 0.6| E[Red Zone - Critical At-Risk]
    
    D --> D1[Hỏi thăm rào cản tự động qua App Push / Zalo Mini App]
    D1 --> D2[Gợi ý ca chạy tối ưu để cải thiện EPH ngắn hạn]
    
    E --> F{Xét phân cụm Tenure và Rank}
    F -->|B1/B2 Core Vet| G[Bảo vệ SLA - Ưu tiên can thiệp trực tiếp qua Đội Trưởng Captain]
    F -->|B3 Newbie| H[Onboarding Rescue Program - Hỗ trợ thu nhập tối thiểu trong 3 ca chạy kế tiếp]
    F -->|B4 Declining Drifter| I[Incentive Uplift - Tặng voucher/thưởng streak cá nhân hóa có điều kiện]
```

*   **Lộ trình Tối ưu:**
    1.  **Dừng phát đại trà khuyến mãi:** Thay thế bằng việc chỉ gửi Promo giữ chân (ví dụ: Hoàn thành 10 đơn tặng 50,000đ) cho nhóm `B4` (Declining) và `B3` (Newbie) khi xác suất Churn nằm trong khoảng `[0.55, 0.80]`.
    2.  **Can thiệp phi tài chính (Non-monetary nudges):** Đối với các tài xế Core `B1` (Full-timer), khi có rủi ro Churn (thường do sự cố app hoặc ức chế đơn hàng cụ thể), chuyển tiếp ngay lập tức thông tin đến Đội hỗ trợ (Driver CS Hotline) để gọi điện chăm sóc cá nhân hóa thay vì gửi promo.
*   **Bản đồ Thực thi (Execution Roadmap):**
    *   *Tuần 1-2 (Phase 1 - Pipeline Setup):* Chạy SQL Feature Extraction để chuẩn bị tập dữ liệu lịch sử 6 tháng. Đóng băng dữ liệu làm tập Train/Val/Test độc lập.
    *   *Tuần 3-4 (Phase 2 - Model Tuning & Validation):* Huấn luyện mô hình LightGBM, tinh chỉnh tham số `scale_pos_weight` và kiểm nghiệm độ chính xác offline. Đạt chỉ tiêu PR-AUC > 0.82.
    *   *Tuần 5-8 (Phase 3 - Shadow Deploy & A/B Testing):* Triển khai mô hình dự báo ngầm (Shadow mode) hàng ngày ghi nhận điểm số vào DWH. Tiến hành A/B Test thực tế:
        *   **Group A (Control):** Giữ chân theo phương thức cũ (phát promo theo cụm hoặc rank).
        *   **Group B (Treatment - Model Guided):** Can thiệp CRM tự động dựa trên xác suất churn của mô hình.
        *   Đo lường mức tăng trưởng Retention Rate và chi phí CPO sau 30 ngày.

---

## 2. 📈 HIỆN THỰC HÓA GIÁ TRỊ (VALUE REALIZATION)

Dưới đây là so sánh chi tiết về hiệu quả vận hành và quản trị tài xế trước và sau khi triển khai Mô hình Học máy dự báo Churn:

| Hiện trạng (Current State) | Chuyển đổi (Transformation) | Trạng thái Mục tiêu (Target State) | Tác động (Impact) |
| :--- | :--- | :--- | :--- |
| **Nhận diện trễ:** Churn được định nghĩa tĩnh dựa trên 30 ngày inactive. Can thiệp khi tài xế đã rời bỏ platform hoàn toàn. | ↓ **ML EARLY WARNING** ↓ | Phát hiện sớm trước 7-14 ngày dựa trên micro-signals về suy giảm EPH, AR và sự thay đổi trong thói quen online. | ***Tăng 22% tỷ lệ cứu giữ thành công tài xế At-Risk ở ngày thứ 3-7.*** |
| **Phân bổ ngân sách lãng phí:** Gửi khuyến mãi giữ chân đại trà hoặc dựa trên Rank tĩnh, tài xế nhận promo xong vẫn churn. | ↓ **PERSUADABLES TARGETING** ↓ | CRM tự động chỉ gửi promo hỗ trợ thu nhập có điều kiện cho nhóm Persuadables (Churn Probability [0.55-0.80]). | ***Tiết kiệm 30% ngân sách giữ chân tài xế (Retention Budget), giảm CPO tổng thể.*** |
| **Ngưỡng quy chụp chung:** Dùng chung một ngưỡng nghỉ cho toàn bộ tài xế (bất kể full-time hay part-time), gây ra tỷ lệ cảnh báo sai (False Positive) cao. | ↓ **PERSONAL GAP BASELINE** ↓ | Đặc trưng `gap_ratio` được cá nhân hóa hoàn toàn theo trung vị ngày nghỉ của riêng từng tài xế (`pgb`). | ***Giảm 65% tỷ lệ báo động sai, giảm thiểu tình trạng làm phiền tài xế (Alert Fatigue).*** |
| **Mất cân bằng SLA giờ cao điểm:** Thiếu hụt tài xế có kinh nghiệm (Core) vào giờ cao điểm do họ chuyển dịch sang nền tảng đối thủ khi EPH cục bộ giảm. | ↓ **PREEMPTIVE PEAK RE-DIRECTION** ↓ | Tự động đề xuất ca chạy và cam kết thu nhập ngắn hạn thông qua CRM ngay khi mô hình phát hiện xu hướng giảm hoạt động của Full-timers. | ***Tăng 12% Acceptance Rate (AR) và ổn định Fulfillment Rate (FR) giờ cao điểm trên 92%.*** |

---

_Bộ phận Quản trị Tài xế & Khoa học Dữ liệu (Driver Management & Data Science) | Ahamove 2026_
_Tài liệu lưu hành nội bộ — Nghiêm cấm sao chép hoặc phân phối ngoài hệ thống DWH._
