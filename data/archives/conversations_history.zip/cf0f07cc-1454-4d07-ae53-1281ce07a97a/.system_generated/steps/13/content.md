Title: GitHub - tuanminhhole/openclaw-setup: Setup AI Telegram Bot miễn phí bằng OpenClaw + Google Gemini + Docker · GitHub

Description: Setup AI Telegram Bot miễn phí bằng OpenClaw + Google Gemini + Docker - tuanminhhole/openclaw-setup

Source: https://github.com/tuanminhhole/openclaw-setup

---

[Skip to content](https://github.com/tuanminhhole/openclaw-setup#start-of-content)

[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Ftuanminhhole%2Fopenclaw-setup)
- PlatformAI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryNewIntegrate external tools](https://github.com/mcp)DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)[View all features](https://github.com/features)
- AI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
- APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
- SolutionsBY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[View all industries](https://github.com/solutions/industry)[View all solutions](https://github.com/solutions)

- BY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)
- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
- BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
- BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[View all industries](https://github.com/solutions/industry)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)
- ResourcesEXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)[View all resources](https://github.com/resources)
- EXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
- EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
- SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)

- Open SourceCOMMUNITY[GitHub SponsorsFund open source developers](https://github.com/sponsors)PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[Accelerator](https://github.com/accelerator)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- COMMUNITY[GitHub SponsorsFund open source developers](https://github.com/sponsors)
- [GitHub SponsorsFund open source developers](https://github.com/sponsors)
- PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[Accelerator](https://github.com/accelerator)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [Accelerator](https://github.com/accelerator)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
- REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
- EnterpriseENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- ENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [Pricing](https://github.com/pricing)
- AI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
- APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)

- EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryNewIntegrate external tools](https://github.com/mcp)
[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
[MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
[ActionsAutomate any workflow](https://github.com/features/actions)
[CodespacesInstant dev environments](https://github.com/features/codespaces)
[IssuesPlan and track work](https://github.com/features/issues)
[Code ReviewManage code changes](https://github.com/features/code-review)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
[Why GitHub](https://github.com/why-github)
[Documentation](https://docs.github.com)
[Blog](https://github.blog)
[Changelog](https://github.blog/changelog)
[Marketplace](https://github.com/marketplace)
[View all features](https://github.com/features)
- BY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)
- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
- BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
- BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[View all industries](https://github.com/solutions/industry)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)

- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
[Enterprises](https://github.com/enterprise)
[Small and medium teams](https://github.com/team)
[Startups](https://github.com/enterprise/startups)
[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
[App Modernization](https://github.com/solutions/use-case/app-modernization)
[DevSecOps](https://github.com/solutions/use-case/devsecops)
[DevOps](https://github.com/solutions/use-case/devops)
[CI/CD](https://github.com/solutions/use-case/ci-cd)
[View all use cases](https://github.com/solutions/use-case)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)
[Healthcare](https://github.com/solutions/industry/healthcare)
[Financial services](https://github.com/solutions/industry/financial-services)
[Manufacturing](https://github.com/solutions/industry/manufacturing)
[Government](https://github.com/solutions/industry/government)
[View all industries](https://github.com/solutions/industry)
[View all solutions](https://github.com/solutions)
- EXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
- EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
- SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
[AI](https://github.com/resources/articles?topic=ai)
[Software Development](https://github.com/resources/articles?topic=software-development)
[DevOps](https://github.com/resources/articles?topic=devops)
[Security](https://github.com/resources/articles?topic=security)
[View all topics](https://github.com/resources/articles)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
[Customer stories](https://github.com/customer-stories)

[Events & webinars](https://github.com/resources/events)
[Ebooks & reports](https://github.com/resources/whitepapers)
[Business insights](https://github.com/solutions/executive-insights)
[GitHub Skills](https://skills.github.com)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)
[Documentation](https://docs.github.com)
[Customer support](https://support.github.com)
[Community forum](https://github.com/orgs/community/discussions)
[Trust center](https://github.com/trust-center)
[Partners](https://github.com/partners)
[View all resources](https://github.com/resources)
- COMMUNITY[GitHub SponsorsFund open source developers](https://github.com/sponsors)
- [GitHub SponsorsFund open source developers](https://github.com/sponsors)
- PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[Accelerator](https://github.com/accelerator)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [Accelerator](https://github.com/accelerator)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
- REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
- [GitHub SponsorsFund open source developers](https://github.com/sponsors)
[GitHub SponsorsFund open source developers](https://github.com/sponsors)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [Accelerator](https://github.com/accelerator)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
[Security Lab](https://securitylab.github.com)
[Maintainer Community](https://maintainers.github.com)
[Accelerator](https://github.com/accelerator)
[GitHub Stars](https://stars.github.com)
[Archive Program](https://archiveprogram.github.com)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
[Topics](https://github.com/topics)
[Trending](https://github.com/trending)
[Collections](https://github.com/collections)
- ENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
[Pricing](https://github.com/pricing)

# Search code, repositories, users, issues, pull requests...
[Search syntax tips](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax)

# Provide feedback
We read every piece of feedback, and take your input very seriously.

To see all available qualifiers, see our [documentation](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax).
[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Ftuanminhhole%2Fopenclaw-setup)
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=header+logged+out&ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E&source=header-repo&source_repo=tuanminhhole%2Fopenclaw-setup)
[Reload](https://github.com/tuanminhhole/openclaw-setup)
[Reload](https://github.com/tuanminhhole/openclaw-setup)
[Reload](https://github.com/tuanminhhole/openclaw-setup)
[tuanminhhole](https://github.com/tuanminhhole)
[openclaw-setup](https://github.com/tuanminhhole/openclaw-setup)
- 
            [Notifications](https://github.com/login?return_to=%2Ftuanminhhole%2Fopenclaw-setup)    You must be signed in to change notification settings


- 
          [Fork
    61](https://github.com/login?return_to=%2Ftuanminhhole%2Fopenclaw-setup)

- 

        [Star
          154](https://github.com/login?return_to=%2Ftuanminhhole%2Fopenclaw-setup)

[Notifications](https://github.com/login?return_to=%2Ftuanminhhole%2Fopenclaw-setup)
[Fork
    61](https://github.com/login?return_to=%2Ftuanminhhole%2Fopenclaw-setup)
[Star
          154](https://github.com/login?return_to=%2Ftuanminhhole%2Fopenclaw-setup)
- 
  [Code](https://github.com/tuanminhhole/openclaw-setup)
- 
  [Issues
          0](https://github.com/tuanminhhole/openclaw-setup/issues)
- 
  [Pull requests
          0](https://github.com/tuanminhhole/openclaw-setup/pulls)
- 
  [Actions](https://github.com/tuanminhhole/openclaw-setup/actions)
- 
  [Projects](https://github.com/tuanminhhole/openclaw-setup/projects)
- 
  [Security and quality
          0](https://github.com/tuanminhhole/openclaw-setup/security)
- 
  [Insights](https://github.com/tuanminhhole/openclaw-setup/pulse)
[Code](https://github.com/tuanminhhole/openclaw-setup)
[Issues
          0](https://github.com/tuanminhhole/openclaw-setup/issues)
[Pull requests
          0](https://github.com/tuanminhhole/openclaw-setup/pulls)
[Actions](https://github.com/tuanminhhole/openclaw-setup/actions)
[Projects](https://github.com/tuanminhhole/openclaw-setup/projects)
[Security and quality
          0](https://github.com/tuanminhhole/openclaw-setup/security)
[Insights](https://github.com/tuanminhhole/openclaw-setup/pulse)
- 


    [Code](https://github.com/tuanminhhole/openclaw-setup)


- 


    [Issues](https://github.com/tuanminhhole/openclaw-setup/issues)


- 


    [Pull requests](https://github.com/tuanminhhole/openclaw-setup/pulls)


- 


    [Actions](https://github.com/tuanminhhole/openclaw-setup/actions)


- 


    [Projects](https://github.com/tuanminhhole/openclaw-setup/projects)


- 


    [Security and quality](https://github.com/tuanminhhole/openclaw-setup/security)


- 


    [Insights](https://github.com/tuanminhhole/openclaw-setup/pulse)


[Code](https://github.com/tuanminhhole/openclaw-setup)
[Issues](https://github.com/tuanminhhole/openclaw-setup/issues)
[Pull requests](https://github.com/tuanminhhole/openclaw-setup/pulls)
[Actions](https://github.com/tuanminhhole/openclaw-setup/actions)
[Projects](https://github.com/tuanminhhole/openclaw-setup/projects)
[Security and quality](https://github.com/tuanminhhole/openclaw-setup/security)
[Insights](https://github.com/tuanminhhole/openclaw-setup/pulse)

[Branches](https://github.com/tuanminhhole/openclaw-setup/branches)
[Tags](https://github.com/tuanminhhole/openclaw-setup/tags)

## History
[120 Commits](https://github.com/tuanminhhole/openclaw-setup/commits/main/)
[.github/workflows](https://github.com/tuanminhhole/openclaw-setup/tree/main/.github/workflows)
[.github/workflows](https://github.com/tuanminhhole/openclaw-setup/tree/main/.github/workflows)
[dist](https://github.com/tuanminhhole/openclaw-setup/tree/main/dist)
[dist](https://github.com/tuanminhhole/openclaw-setup/tree/main/dist)
[docs](https://github.com/tuanminhhole/openclaw-setup/tree/main/docs)
[docs](https://github.com/tuanminhhole/openclaw-setup/tree/main/docs)
[src](https://github.com/tuanminhhole/openclaw-setup/tree/main/src)
[src](https://github.com/tuanminhhole/openclaw-setup/tree/main/src)
[.gitignore](https://github.com/tuanminhhole/openclaw-setup/blob/main/.gitignore)
[.gitignore](https://github.com/tuanminhhole/openclaw-setup/blob/main/.gitignore)
[CHANGELOG.md](https://github.com/tuanminhhole/openclaw-setup/blob/main/CHANGELOG.md)
[CHANGELOG.md](https://github.com/tuanminhhole/openclaw-setup/blob/main/CHANGELOG.md)
[CHANGELOG.vi.md](https://github.com/tuanminhhole/openclaw-setup/blob/main/CHANGELOG.vi.md)
[CHANGELOG.vi.md](https://github.com/tuanminhhole/openclaw-setup/blob/main/CHANGELOG.vi.md)
[LICENSE](https://github.com/tuanminhhole/openclaw-setup/blob/main/LICENSE)
[LICENSE](https://github.com/tuanminhhole/openclaw-setup/blob/main/LICENSE)
[README.md](https://github.com/tuanminhhole/openclaw-setup/blob/main/README.md)
[README.md](https://github.com/tuanminhhole/openclaw-setup/blob/main/README.md)
[README.vi.md](https://github.com/tuanminhhole/openclaw-setup/blob/main/README.vi.md)
[README.vi.md](https://github.com/tuanminhhole/openclaw-setup/blob/main/README.vi.md)
[package-lock.json](https://github.com/tuanminhhole/openclaw-setup/blob/main/package-lock.json)
[package-lock.json](https://github.com/tuanminhhole/openclaw-setup/blob/main/package-lock.json)
[package.json](https://github.com/tuanminhhole/openclaw-setup/blob/main/package.json)
[package.json](https://github.com/tuanminhhole/openclaw-setup/blob/main/package.json)

## Repository files navigation
- [README](https://github.com/tuanminhhole/openclaw-setup)
- [MIT license](https://github.com/tuanminhhole/openclaw-setup)
[README](https://github.com/tuanminhhole/openclaw-setup)
[MIT license](https://github.com/tuanminhhole/openclaw-setup)

https://camo.githubusercontent.com/ece1c1a382e837607373c0f239cc53bc033144ff01fa725b2f9bd452d358a3b6/68747470733a2f2f666c616763646e2e636f6d2f32307831352f67622e706e67[Tiếng Việt](https://github.com/tuanminhhole/openclaw-setup/blob/main/README.vi.md) · English
A next-generation Web UI Setup and management dashboard that automates 100% of the project scaffolding, deployment, and control of free multi-bot AI assistants on Telegram or Zalo — supports Windows, macOS, Ubuntu, and VPS.

- New: Infographic Poster Generator Skill: Integrates automatic infographic and poster generation via 9Router API. Automatically generates the helper script image-generator.js (synchronizing API credentials from openclaw.json) and a comprehensive SKILL.md guiding agents on styling rules, Vietnamese font support, layouts, and image generation syntax.
- New: Zalo Sticker & Auto-Tag Skill:

Automatically mentions the active sender in group chats (Agent doesn't need to manually prefix with @Name anymore, the system handles it).
Enables agents to dynamically send Zalo stickers by appending [Sticker: <keyword>] at the end of their text responses.
Automatically maps emotional keywords (such as love, haha, ca khia, angry, thank you, etc.) to actual Zalo sticker IDs.
Generates the patch script mentions.js and a dedicated SKILL.md inside the agent's workspace.


- Automatically mentions the active sender in group chats (Agent doesn't need to manually prefix with @Name anymore, the system handles it).
- Enables agents to dynamically send Zalo stickers by appending [Sticker: <keyword>] at the end of their text responses.
- Automatically maps emotional keywords (such as love, haha, ca khia, angry, thank you, etc.) to actual Zalo sticker IDs.
- Generates the patch script mentions.js and a dedicated SKILL.md inside the agent's workspace.
- Polish: Simplified TOOLS.md generation: Streamlined the TOOLS.md generator to output a concise, static guide focusing on general principles and referencing the ./skills/ directory, rather than generating dynamic lists based on installed plugins.
- Polish: Standardized Reference Docs list in AGENTS.md: Updated the reference docs list in the generated AGENTS.md (for both single and relay variants in Vietnamese and English) to match the new structure, removing obsolete files (TEAMS.md for single-bot, BROWSER.md) and standardizing descriptions to keep exactly 9 core documents.

```
image-generator.js
```


```
openclaw.json
```


```
SKILL.md
```

- Automatically mentions the active sender in group chats (Agent doesn't need to manually prefix with @Name anymore, the system handles it).
- Enables agents to dynamically send Zalo stickers by appending [Sticker: <keyword>] at the end of their text responses.
- Automatically maps emotional keywords (such as love, haha, ca khia, angry, thank you, etc.) to actual Zalo sticker IDs.
- Generates the patch script mentions.js and a dedicated SKILL.md inside the agent's workspace.

```
@Name
```


```
[Sticker: <keyword>]
```


```
love
```


```
haha
```


```
ca khia
```


```
angry
```


```
thank you
```


```
mentions.js
```


```
SKILL.md
```


```
TOOLS.md
```


```
./skills/
```


```
AGENTS.md
```


```
TEAMS.md
```


```
BROWSER.md
```

- 🎨 Modern Web UI Dashboard: Completely replaces the legacy index.html static wizard and terminal-based manual setups with a highly intuitive, premium dark red/black themed web dashboard to install and manage bots.
- 🔀 Centralized AI Proxy via 9Router: The installer now relies exclusively on 9Router as the unified AI gateway. Through 9Router's OAuth sign-in flow, you can easily route requests to free models (like Google Gemini free tier, Ollama local offline models) as well as premium paid models.
- 📊 Process Controller: Directly Start, Stop, or Recreate bot containers and processes via user-friendly dashboard buttons.
- 📑 Real-Time Live Logs: View real-time streaming console logs of your bot processes directly on the Web UI.
- 📁 File Tree Editor: Read, modify, and save configuration files (openclaw.json, SOUL.md, AGENTS.md) directly in the browser.
- 🔑 Zalo QR Authorization: Authorize Zalo Personal bots in seconds by scanning the Zalo login QR code rendered directly on the management dashboard.
- 🔄 Smart Port Conflict Resolution: Automatically scans and dynamically assigns unique network ports (routerPort) to avoid conflicts when launching multiple bot instances.

```
index.html
```


```
openclaw.json
```


```
SOUL.md
```


```
AGENTS.md
```


```
routerPort
```

- 🤖 Multi-Channel — Telegram (single or multi-bot relay), Zalo Bot API, or Zalo Personal.
- 🧑‍🤝‍🧑 Multi-Bot Team — Run multiple Telegram/Zalo bots simultaneously with synchronized workspaces and teamwork.
- 🧠 Unified AI Routing via 9Router — Easily route messages to Google Gemini, Claude, GPT-4o, OpenRouter, and Ollama (local offline models).
- 🧩 Built-in Skills — Web Search, Browser Automation (Chrome CDP), and Cron/Scheduler tasks.
- 🔌 Integrated Marketplace — Install advanced plugins (like openclaw-zalo-mod, Facebook Crawler...) with a single click.
- 🔀 9Router Integration — Open-source OAuth-based AI proxy that gets you up and running for free without individual API keys.
- 🔒 Safe & Private — All configurations and API keys are stored locally on your own machine.

```
openclaw-zalo-mod
```

### 1️⃣ Method 1: Using NPX (Recommended)
Open your terminal and run this single command:

```
npx create-openclaw-bot
```

The bootstrapper will automatically download package files, launch the local backend server, and open the Setup UI in your browser.

### 2️⃣ Method 2: Manual Clone
If you downloaded or cloned the repository files locally:

```
npm install npm start
```

## 📋 System Prerequisites
- Node.js: Version 20, 22, or 24 (Avoid Node 25 due to runtime library deprecations).
- Git: Installed and available in your environment PATH.
- Docker Desktop (If deploying via Docker): Support for Docker Compose V2.

## 🧠 Supported AI Providers (via 9Router)
- [9Router GitHub](https://github.com/decolua/9router)
[9Router GitHub](https://github.com/decolua/9router)

## 🔌 Supported Channels
- Telegram: Acquire your official Bot Token from @BotFather.
- Zalo Bot API: Obtain credentials from [developers.zalo.me](https://developers.zalo.me).
- Zalo Personal: Scan the QR authorization image displayed on the OpenClaw Dashboard.

```
@BotFather
```

[developers.zalo.me](https://developers.zalo.me)

## 📁 Repository Structure
```
openclaw-setup/ |-- README.md ← English documentation (You are here) |-- README.vi.md ← Vietnamese documentation |-- package.json ← NPM entry and runner scripts |-- dist/ ← Compiled Web UI and CLI bundles `-- src/ ← Source code (UI, local API backend, build tools)
```


```
openclaw-setup/ |-- README.md ← English documentation (You are here) |-- README.vi.md ← Vietnamese documentation |-- package.json ← NPM entry and runner scripts |-- dist/ ← Compiled Web UI and CLI bundles `-- src/ ← Source code (UI, local API backend, build tools)
```

## 🔗 Useful Links
- [OpenClaw Docs](https://openclaw.ai/docs)
- [9Router GitHub](https://github.com/decolua/9router)
- [Google AI Studio](https://aistudio.google.com/)
- [Telegram BotFather](https://t.me/BotFather)
- [Zalo Developer Platform](https://developers.zalo.me)
- [Docker Desktop](https://www.docker.com/products/docker-desktop/)
- [ClawHub (Skills)](https://clawhub.com)
[OpenClaw Docs](https://openclaw.ai/docs)
[9Router GitHub](https://github.com/decolua/9router)
[Google AI Studio](https://aistudio.google.com/)
[Telegram BotFather](https://t.me/BotFather)
[Zalo Developer Platform](https://developers.zalo.me)
[Docker Desktop](https://www.docker.com/products/docker-desktop/)
[ClawHub (Skills)](https://clawhub.com)

## 🙏 Acknowledgments
- [OpenClaw](https://openclaw.ai) — Core AI Gateway framework
- [9Router](https://github.com/decolua/9router) — Open-source AI proxy (OAuth-based, no API keys)
- [ClawHub](https://clawhub.com) — Bot skills registry
- [TheSVG](https://thesvg.org) — High-quality SVG brand icons
[OpenClaw](https://openclaw.ai)
[9Router](https://github.com/decolua/9router)
[ClawHub](https://clawhub.com)
[TheSVG](https://thesvg.org)
Made with 🦞 by [tuanminhhole](https://github.com/tuanminhhole)

## About
Setup AI Telegram Bot miễn phí bằng OpenClaw + Google Gemini + Docker

### Resources
[Readme](https://github.com/tuanminhhole/openclaw-setup#readme-ov-file)

### License
[MIT license](https://github.com/tuanminhhole/openclaw-setup#MIT-1-ov-file)

### Uh oh!
There was an error while loading. [Please reload this page](https://github.com/tuanminhhole/openclaw-setup).
[Activity](https://github.com/tuanminhhole/openclaw-setup/activity)

### Stars
[154
        stars](https://github.com/tuanminhhole/openclaw-setup/stargazers)

### Watchers
[3
        watching](https://github.com/tuanminhhole/openclaw-setup/watchers)

### Forks
[61
        forks](https://github.com/tuanminhhole/openclaw-setup/forks)
[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Ftuanminhhole%2Fopenclaw-setup&report=tuanminhhole+%28user%29)

## [Releases 76](https://github.com/tuanminhhole/openclaw-setup/releases)
[Releases
      76](https://github.com/tuanminhhole/openclaw-setup/releases)
[v5.8.17

          Latest

      Jun 8, 2026](https://github.com/tuanminhhole/openclaw-setup/releases/tag/v5.8.17)
[+ 75 releases](https://github.com/tuanminhhole/openclaw-setup/releases)

## [Packages 0](https://github.com/users/tuanminhhole/packages?repo_name=openclaw-setup)
[Packages
      0](https://github.com/users/tuanminhhole/packages?repo_name=openclaw-setup)

There was an error while loading. [Please reload this page](https://github.com/tuanminhhole/openclaw-setup).

[Contributors](https://github.com/tuanminhhole/openclaw-setup/graphs/contributors)

There was an error while loading. [Please reload this page](https://github.com/tuanminhhole/openclaw-setup).

- 
        [JavaScript
          80.0%](https://github.com/tuanminhhole/openclaw-setup/search?l=javascript)

- 
        [CSS
          19.9%](https://github.com/tuanminhhole/openclaw-setup/search?l=css)

- 
        [HTML
          0.1%](https://github.com/tuanminhhole/openclaw-setup/search?l=html)

[JavaScript
          80.0%](https://github.com/tuanminhhole/openclaw-setup/search?l=javascript)
[CSS
          19.9%](https://github.com/tuanminhhole/openclaw-setup/search?l=css)
[HTML
          0.1%](https://github.com/tuanminhhole/openclaw-setup/search?l=html)

- 
            [Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)

- 
            [Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)

- 
            [Security](https://github.com/security)

- 
            [Status](https://www.githubstatus.com/)

- 
            [Community](https://github.community/)

- 
            [Docs](https://docs.github.com/)

- 
            [Contact](https://support.github.com?tags=dotcom-footer)

- 


       Manage cookies



- 


      Do not share my personal information



[Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)
[Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)
[Security](https://github.com/security)
[Status](https://www.githubstatus.com/)
[Community](https://github.community/)
[Docs](https://docs.github.com/)
[Contact](https://support.github.com?tags=dotcom-footer)

