# Phương Án Dịch Thuật Ngữ "Cascade" Cho Vận Hành Ahamove

Trong tài liệu **Driver Ranking & Layer Management**, thuật ngữ **Cascade** mô tả cơ chế hệ thống tự động phân bổ/chuyển tiếp đơn hàng (hoặc quyền nhận đơn) sang tầng (layer) tiếp theo khi tầng ưu tiên hiện tại đạt ngưỡng lấp đầy (fill rate) $\ge 80\%$.

Dưới đây là các phương án dịch nghĩa sang **Tiếng Việt** đảm bảo tính **gọn gàng**, **chuẩn vận hành (Operations)** và **dễ hiểu** cho cả đội ngũ BI, Product và Ops.

---

## 📊 Bảng So Sánh Các Phương Án

| Phương án | Tiếng Việt đề xuất | Độ gọn | Tính chính xác vận hành | Mức độ quen thuộc với tài xế/Ops | Đánh giá & Khuyến nghị |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Option 1 (Khuyên dùng)** | **Điều phối tràn** / **Tràn đơn** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | **Tối ưu nhất**. Sát với thực tế vận hành on-demand (khi tầng L2 đầy 80%, đơn sẽ "tràn" sang L3). |
| **Option 2** | **Chuyển tầng tự động** / **Mở tầng** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | **Rất gọn**. Phù hợp trực quan vì Ahamove đang chia theo cấu trúc Layer (L2 -> L3 -> L4). |
| **Option 3** | **Trượt đơn** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | Thuật ngữ kỹ thuật định tuyến (Routing). Hơi khó hình dung đối với khối phi kỹ thuật. |
| **Option 4** | **Phân cấp mở rộng** | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ | Mang tính học thuật, không tối ưu cho tài liệu thực chiến. |

---

## 📝 Đề Xuất Thay Thế Chi Tiết Trong Bảng

Dưới đây là cách thay thế cụ thể tại **Dòng 291** của tài liệu [2026-05-driver-ranking-params.md](file:///Users/ts-1148/Desktop/Cowork/Output/Ahamove/01.%20STRATEGY%20&%20PLANNING/2026-05-driver-ranking-params.md#L291):

### Phương án A: Dùng "**Tràn đơn**" (Gọn nhất & Sát nghĩa nhất)
```diff
-| **Cascade mở khi** | L2 ≥80% fill | L3 ≥80% fill | L4 ≥80% fill | — | luôn mở |
+| **Tràn đơn khi** | L2 ≥80% fill | L3 ≥80% fill | L4 ≥80% fill | — | luôn mở |
```

### Phương án B: Dùng "**Mở tầng**" (Gắn liền với cấu trúc Layer)
```diff
-| **Cascade mở khi** | L2 ≥80% fill | L3 ≥80% fill | L4 ≥80% fill | — | luôn mở |
+| **Mở tầng khi** | L2 ≥80% fill | L3 ≥80% fill | L4 ≥80% fill | — | luôn mở |
```

### Phương án C: Dùng "**Điều phối tràn**" (Chuyên nghiệp cấp Enterprise)
```diff
-| **Cascade mở khi** | L2 ≥80% fill | L3 ≥80% fill | L4 ≥80% fill | — | luôn mở |
+| **Điều phối tràn khi** | L2 ≥80% fill | L3 ≥80% fill | L4 ≥80% fill | — | luôn mở |
```
