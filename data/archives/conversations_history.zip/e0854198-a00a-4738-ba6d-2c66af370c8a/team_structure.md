# 📊 SƠ ĐỒ TỔ CHỨC & MA TRẬN RACI — DRIVER MANAGEMENT TEAM (Q3/2026)

## 1. Tóm Tắt Thực Thi (Executive Summary)

*   📊 **Phát hiện Cốt lõi:** Cơ cấu tổ chức của **Driver Management Team** (Ahamove) trong quý 3/2026 được phân cấp rõ ràng dưới sự quản lý tổng thể của **Khanh** (Driver Management Leader) và hỗ trợ của **Chị Trang** (Asst. Driver Management Manager), phân tách thành hai nhánh chuyên biệt: **Sub-team DM** (Vận hành & Hiệu suất) và **Sub-team DE** (Gắn kết & Truyền thông).
*   🎯 **Mục tiêu Vận hành:** Tối ưu hóa phân bổ nguồn lực vận hành thực địa (MiniHub, Captain Program) và chuẩn hóa ma trận trách nhiệm RACI nhằm tránh chồng chéo công việc, đặc biệt là các nhiệm vụ liên vùng (cross-squad) như Lượng (Ops + Captain PIC) và Trúc (MiniHub + Captain Support).
*   📈 **Cơ cấu Nhân sự (Team Size):** Tổng số **11 nhân sự** hoạt động (bao gồm 1 vị trí Ops đang tuyển dụng).

---

## 2. Khung Phân Tích Cơ Cấu Tổ Chức (Org Chart)

```mermaid
graph TD
    classDef am fill:#1a1a2e,stroke:#FF7F32,stroke-width:2px,color:#fff;
    classDef leader fill:#0E4174,stroke:#FF7F32,stroke-width:2px,color:#fff;
    classDef lead fill:#fff,stroke:#0E4174,stroke-width:2px,color:#374151;
    classDef member fill:#fff,stroke:#E5E7EB,stroke-width:1.5px,color:#4B5563;
    classDef vacant fill:#F9FAFB,stroke:#D1D5DB,stroke-width:1.5px,stroke-dasharray: 5 5,color:#9CA3AF;
    classDef eng fill:#fff,stroke:#FF7F32,stroke-width:2px,color:#374151;

    Trang["Chị Trang<br/>(Asst. Driver Management Manager)"]:::am
    Khanh["Khanh<br/>(Driver Management Leader)"]:::leader
    
    Trang --> Khanh
    
    subgraph DM["SUB-TEAM: DM (Performance - Capacity - Retention)"]
        Tiên["Tiên (Lead)<br/>[PERFORMANCE]"]:::lead
        Hoàng["Hoàng (Lead)<br/>[MINIHUB OPS]"]:::lead
        LượngL["Lượng (Lead)<br/>[CAPTAIN PROJECT]"]:::lead
        
        Tiên --> LượngM["Lượng (Ops & Captain PIC)"]:::member
        Tiên --> Nhi["Nhi (NIM/NLM - 60-day)"]:::member
        Tiên --> Vacant["Vacant (Đang tuyển)"]:::vacant
        
        Hoàng --> TrúcM["Trúc (MiniHub SGN & Captain Support)"]:::member
        
        LượngL --> TrúcM
    end
    
    subgraph DE["SUB-TEAM: DE (Engagement - Comms - Partnership)"]
        Vân["Vân (Lead)<br/>[ENGAGEMENT]"]:::eng
        
        Vân --> Thúy["Thúy<br/>(HAN Region)"]:::member
        Vân --> Khoa["Khoa<br/>(Comms)"]:::member
        Vân --> Hoa["Hoa<br/>(Comms)"]:::member
    end
    
    Khanh --> Tiên
    Khanh --> Hoàng
    Khanh --> LượngL
    Khanh --> Vân

    %% Hỗ trợ quản lý của AM
    Trang -.->|Hỗ trợ quản lý| Hoàng
    Trang -.->|Hỗ trợ quản lý| LượngL
```

---

## 3. Phân Công Trách Nhiệm (RACI Matrix)

*Quy ước viết tắt: **R** (Responsible - Thực hiện), **A** (Accountable - Chịu trách nhiệm chính), **C** (Consulted - Tham vấn), **I** (Informed - Được thông báo).*

### 📂 Phân nhánh Vận hành & Hiệu suất (Sub-team DM)

| Hoạt động / Nhiệm vụ | Khanh (Leader) | AM Trang | Tiên (Ops Lead) | Lượng (Ops+Cpt) | Nhi (NIM/NLM) | Hoàng (Hub Lead) | Trúc (Hub+Cpt) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Giám sát Performance tổng (AR, FR, CPO)** | **A** | **I** | **R** | **R** | **C** | **I** | **I** |
| **Cân đối Capacity & Supply theo zone** | **A** | **C** | **R** | **R** | | **C** | |
| **Incentive Design & Budget Control** | **A** | **C** | **R** | **C** | | **I** | |
| **Driver Retention & Churn Analysis** | **A** | **I** | **R** | **R** | **C** | | |
| **Onboarding Tài xế mới (NIM/NLM)** | **A** | **I** | **C** | | **R** | | |
| **Quản lý Tài xế 60 ngày đầu** | **A** | **I** | **C** | | **R** | | |
| **Driver Tiering (4-tier system)** | **A** | **C** | **R** | **C** | **C** | **C** | |

### 📂 Phân nhánh Giao điểm Zone & Dự án đặc biệt (MiniHub & Captain)

| Hoạt động / Nhiệm vụ | Khanh (Leader) | AM Trang | Tiên (Ops+Cpt) | Hoàng (Hub Lead) | Trúc (Hub+Cpt) | Vân (DE Lead) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Vận hành MiniHub tổng** | **A** | **A** | | **R** | **R** | |
| **MiniHub SGN — vận hành hàng ngày** | **I** | **A** | | **C** | **R** | |
| **Driver trong Zone — phân bổ & SLA** | **A** | **C** | | **R** | **R** | |
| **Thiết kế & triển khai Captain Program** | **A** | **A** | **R** | | **R** | |
| **Tuyển chọn & quản lý Captain** | **I** | **A** | **R** | | **C** | |
| **Đánh giá hiệu quả Captain** | **A** | **C** | **R** | | **C** | |

### 📢 Phân nhánh Gắn kết & Truyền thông (Sub-team DE)

| Hoạt động / Nhiệm vụ | Khanh (Leader) | AM Trang | Vân (DE Lead) | Thúy (HAN) | Khoa (Comms) | Hoa (Comms) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Chiến lược Engagement tổng** | **A** | **I** | **R** | **C** | **C** | **C** |
| **Hoạt động gắn kết offline SGN** | **I** | **I** | **A** | | **R** | **R** |
| **Hoạt động gắn kết offline HAN** | **I** | **I** | **A** | **R** | | |
| **Partnership & Benefits Tài xế** | **A** | **I** | **R** | **C** | **C** | **C** |
| **Truyền thông nội bộ Tài xế** | **I** | **I** | **A** | | **R** | **R** |

---

## 4. Hiện Thực Hóa Giá Trị (Value Realization)

| Hiện trạng Vận hành | Chuyển đổi Cơ cấu | Trạng thái Mục tiêu | Tác động Vận hành |
| :--- | :--- | :--- | :--- |
| Trách nhiệm chồng chéo giữa MiniHub và Captain Squad tại miền Nam. | ↓ CHUẨN HÓA RACI & PIC CHÉO SQUAD ↓ | Định vị Lượng là PIC Captain, Trúc là PIC MiniHub hỗ trợ chéo nhau. | ***Tăng 30% tốc độ giải quyết khiếu nại thực địa & đảm bảo SLA zone ổn định*** |
| Thiếu vị trí quản lý vận hành chuyên biệt cho New Driver (60 ngày đầu). | ↓ PHÂN BỔ NHI PHỤ TRÁCH NIM/NLM ↓ | Tập trung 100% tài nguyên của Nhi vào quản trị vòng đời tài xế mới. | ***Giảm 15% tỷ lệ churn của tài xế mới trong 2 tháng đầu*** |
| Ranh giới quản lý giữa Manager và Leader đối với MiniHub/Captain chưa rõ ràng. | ↓ THIẾT LẬP ĐỒNG CHỊU TRÁCH NHIỆM (DOUBLE-A) ↓ | AM Trang chịu trách nhiệm hoạt động hàng ngày, Khanh chịu trách nhiệm tổng thể. | ***Rút ngắn 50% thời gian phê duyệt ngân sách và kế hoạch hành động khẩn cấp*** |
