# 📋 CHI TIẾT NHIỆM VỤ & TRÁCH NHIỆM TỪNG SUB-TEAM — DRIVER MANAGEMENT

## 1. Tóm Tắt Thực Thi (Executive Summary)

*   📊 **Phát hiện Cốt lõi:** Nhằm tối ưu hóa hiệu quả vận hành thực địa và gắn kết tài xế, cấu trúc Driver Management (DM) được chia làm 2 Sub-team lớn:
    *   **Sub-team DM (Vận hành & Hiệu suất):** Gồm 3 Squads (**Operations**, **MiniHub**, **Captain**) tập trung tối ưu hóa các chỉ số hiệu suất vận hành chính (AR, FR, CPO, SLA, Churn).
    *   **Sub-team DE (Gắn kết & Truyền thông):** Tập trung vào chiến lược giữ chân tài xế phi tài chính (Non-financial retention), truyền thông và các đối tác phúc lợi (Partnership & Benefits).
*   🎯 **Mục tiêu Vận hành:** Định biên rõ ràng công việc hàng ngày của từng nhân sự, hạn chế chồng chéo và thiết lập quy trình bàn giao công việc mượt mà.

---

## 2. Chi Tiết Nhiệm Vụ Từng Sub-Team & Squad

### 📂 SUB-TEAM 1: DM (Driver Management - Performance & Capacity)
*Tập trung vào khía cạnh số liệu vận hành, hiệu suất tài xế, cung cầu và quản lý các hub thực địa.*

#### 1. Operations Squad (Performance & Lifecycle Management)
*   **Trưởng nhóm (Lead):** Tiên | **Thành viên:** Lượng, Nhi
*   **Danh sách công việc & Trách nhiệm chính:**
    1.  **Giám sát & Tối ưu hóa Chỉ số Vận hành (AR/FR/CPO):** Giám sát hàng ngày tỷ lệ chấp nhận đơn (Acceptance Rate - AR), tỷ lệ hoàn thành đơn (Fulfillment Rate - FR) và chi phí trên mỗi đơn hàng (Cost per Order - CPO).
    2.  **Cân đối Cung - Cầu (Capacity Balancing):** Phân tích lượng tài xế hoạt động theo từng Zone và khung giờ (Peak hours) để kịp thời điều phối dòng tài xế.
    3.  **Thiết kế & Quản lý Ngân sách Incentive (Incentive Design):** Xây dựng các chương trình thưởng ngắn hạn, thưởng tuần/tháng cho tài xế và kiểm soát hiệu quả P&L.
    4.  **Phân tích Churn & Giữ chân Tài xế (Retention Analysis):** Phân tích dữ liệu tài xế ngừng hoạt động để đưa ra các biện pháp cảnh báo sớm.
    5.  **Quản trị Vòng đời Tài xế Mới (NIM/NLM):**
        *   *PIC chính:* Nhi
        *   Tổ chức onboarding tài xế mới, quản lý hiệu suất và kèm cặp tài xế trong 60 ngày đầu tiên để nâng cao tỷ lệ kích hoạt (Activation rate).
    6.  **Quản lý Hệ thống Phân tầng (Driver Tiering):** Quản lý hệ thống 4 tầng tài xế và quyền lợi tương ứng để thúc đẩy tài xế tăng trưởng chuyến đi.

#### 2. MiniHub Squad (Zone Operations)
*   **Trưởng nhóm (Lead):** Hoàng | **Thành viên:** Trúc
*   **Danh sách công việc & Trách nhiệm chính:**
    1.  **Vận hành Hệ thống MiniHub miền Nam (SGN MiniHubs):** Quản lý, giám sát các trạm mini-hub thực địa nhằm hỗ trợ tài xế trực tiếp.
    2.  **Quản lý Vận hành Zone:** Phân bổ tài xế theo vùng địa lý đặc thù và đảm bảo cam kết chất lượng dịch vụ (SLA) tại từng Zone.
    3.  **Điều phối Cung cầu tại Điểm nóng (Mini-hub level):** Phản ứng nhanh với tình trạng thiếu hụt tài xế cục bộ tại các khu vực mini-hub phụ trách.

#### 3. Captain Squad (Project Management)
*   **Trưởng dự án (PIC):** Lượng | **Thành viên hỗ trợ:** Trúc
*   **Danh sách công việc & Trách nhiệm chính:**
    1.  **Thiết kế & Triển khai Chương trình Đội trưởng (Captain Program):** Xây dựng cấu trúc nhóm tài xế nòng cốt (Captains) làm cầu nối thông tin giữa Ahamove và cộng đồng tài xế.
    2.  **Tuyển chọn & Huấn luyện Captain:** Lọc hồ sơ, phỏng vấn và đào tạo kỹ năng điều phối cho các Captain.
    3.  **Đánh giá Hiệu quả Đội nhóm:** Đánh giá định kỳ KPI của các Captain và đội nhóm tài xế dưới quyền của họ để tối ưu hóa sự gắn kết thực địa.

---

### 📂 SUB-TEAM 2: DE (Driver Engagement - Engagement & Comms)
*Tập trung vào trải nghiệm tài xế, xây dựng văn hóa cộng đồng, phúc lợi phi tài chính và truyền thông.*

#### 1. Driver Engagement Squad (Community & Partnership)
*   **Trưởng nhóm (Lead):** Vân | **Thành viên:** Thúy (HAN), Khoa (Comms), Hoa (Comms)
*   **Danh sách công việc & Trách nhiệm chính:**
    1.  **Hoạt động Gắn kết Cộng đồng (Offline Engagement):**
        *   Lên kế hoạch và tổ chức các sự kiện offline, họp mặt cộng đồng, lễ vinh danh tài xế xuất sắc.
        *   *Phân vùng phụ trách:* Vân & Khoa & Hoa phụ trách miền Nam (SGN) | Thúy phụ trách miền Bắc (HAN).
    2.  **Phát triển Đối tác & Phúc lợi (Partnership & Benefits):** Kết nối với các đối tác ngoài (xăng dầu, bảo hiểm, sửa xe, viễn thông...) để cung cấp các gói ưu đãi độc quyền cho tài xế Ahamove.
    3.  **Truyền thông Nội bộ Tài xế (Internal Communications):**
        *   *PIC chính:* Khoa & Hoa
        *   Soạn thảo tin nhắn, thông báo, bài viết trên các kênh chính thức (Zalo, App tài xế, Facebook Group) đảm bảo thông tin chính sách được truyền đạt rõ ràng, chính xác.
    4.  **Hỗ trợ Truyền thông Liên phòng ban:** Hỗ trợ sub-team DM truyền thông các chính sách incentive mới, thay đổi quy định phân tầng hoặc thay đổi vận hành MiniHub.

---

## 3. Hoạt Động Liên Chức Năng (Cross-Functional Tasks)

Các công việc đòi hỏi sự phối hợp chặt chẽ giữa các sub-teams và báo cáo trực tiếp cho Leadership (**Khanh** & **AM Trang**):
1.  **Báo cáo Tuần/Tháng (Reporting):** Tập hợp số liệu vận hành và gắn kết để báo cáo lên Ban giám đốc.
2.  **Quy hoạch Siêu sự kiện (Mega Sales Planning):** Chuẩn bị kế hoạch cung ứng và thưởng đột phá cho các đợt cao điểm mua sắm lớn.
3.  **Phòng chống Gian lận (Fraud Detection):** Phối hợp rà soát hệ thống, phát hiện các hành vi gian lận (fake GPS, fake orders, thông đồng) và thực hiện các chế tài xử phạt theo quy định.
4.  **Chuyển đổi Xe điện (EV Driver Transition):** Triển khai chiến lược chuyển đổi và hỗ trợ tài xế chuyển sang sử dụng xe điện theo định hướng xanh hóa.
