# 📊 TÀI LIỆU KHẢO SÁT & BÁO CÁO: RANK × LAYER × AHABENEFITS V2.0

## 1. TÓM TẮT THỰC THI (EXECUTIVE SUMMARY)

*   **Bối cảnh:** Hệ thống xếp hạng cũ của đối tác gặp bất cập khi sử dụng các chỉ số riêng rẽ (AR-FR-Rating), chưa tạo sự phân hóa rõ ràng về quyền lợi và thiếu kiểm soát chất lượng dịch vụ thực tế.
*   **Giải pháp:** Tái cấu trúc sang cơ chế **Rank × Layer × Quyền lợi** khép kín. Dùng điểm chất lượng **DQS** làm màng lọc Rank, Rank quyết định khung giờ ưu tiên đăng ký vùng hoạt động (**Layer**), và chính sách phúc lợi điểm thưởng (**AhaPoints**) tại các Layer này đóng vai trò lực kéo tự nhiên điều phối nguồn cung.
*   **Mục tiêu Chiến lược (Business Objectives):**
    *   **Chuẩn hóa chất lượng:** Dùng DQS để lọc sạch tài xế gian lận, nâng cao chất lượng dịch vụ tổng thể.
    *   **Điều phối cung tự động:** Khơi thông luồng cung vào peak-hour thông qua hệ số nhân AhaPoints, giảm chi phí hỗ trợ tiền mặt trực tiếp.
    *   **Tối ưu hóa P&L:** Chuyển dịch cơ cấu incentive từ thưởng cố định sang phúc lợi phi tiền mặt do đối tác tài trợ.
*   **Chỉ số Cốt lõi (Important KPIs):**
    *   **Active Drivers / Rank:** R1 Elite (~15%), R2 Active (~35%), R3 Standard (~35%), Unranked (~15%).
    *   **Fulfillment Rate (FR) / ca:** Đạt &ge; 90% tại các khu vực Minizone (L2) và Mediumzone (L3).
    *   **Acceptance Rate (AR):** Đạt &ge; 90% toàn hệ thống nhờ cam kết ca chạy.
    *   **DQS (Driver Quality Score):** R1 Elite duy trì DQS &ge; 80, R2/R3 duy trì DQS &ge; 75.

---

## 2. KHUNG PHÂN TÍCH (ANALYSIS FRAMEWORK)

### Phân tích Mô tả (Descriptive Analysis)
Hệ thống vận hành hiện tại phân mảnh cơ chế thưởng và đăng ký ca theo địa bàn thủ công. Doanh thu chuyến xe (`trip_GSV`) chưa được khai thác tối ưu để chuyển hóa thành điểm thưởng gắn kết. Tỷ lệ phân bổ tài xế (fleet ratio) tập trung ở các nhóm trung bình (R2/R3 chiếm 70%), cho thấy tiềm năng thúc đẩy năng suất nếu có cơ chế phân tầng đặc quyền hợp lý.

### Phân tích Chẩn đoán (Diagnostic Analysis)
*   **Khoảng trống chất lượng:** Tài xế chạy lượng đơn lớn nhưng chất lượng kém (gian lận, huỷ ca, ứng xử tệ) vẫn giữ rank cao do thiếu chỉ số DQS sàng lọc.
*   **Điểm nghẽn vận hành:** Thiếu hụt tài xế cục bộ tại các khu vực lõi (Minizone) vào giờ cao điểm, trong khi ngân sách Promo/Incentives bị phân bổ dàn trải, không tạo ra ROI thực tế.

### Phân tích Dự báo (Predictive Analysis)
*   Áp dụng hệ số nhân AhaPoints (L2 ×1.5, L3 ×1.3) sẽ giúp tăng **35% Fulfillment rate** tại các khu vực trọng yếu mà không cần tăng chi phí tiền mặt trực tiếp.
*   Tài xế L6 (MASS - chạy tự do) chỉ tích luỹ tối đa **4.840 pts/tháng**, thấp hơn ngưỡng đổi thưởng tối thiểu (5.000 pts), tạo động lực tự nhiên thúc đẩy tài xế thăng hạng lên R3/R2/R1 để hưởng ca ưu tiên.

### Phân tích Đề xuất (Prescriptive Analysis)

#### 🎴 SLIDE BÁO CÁO: TỔNG HỢP RANK × LAYER × AHABENEFITS

````carousel
# SLIDE: HỆ THỐNG PHÂN CẤP ĐẶC QUYỀN VÀ PHÂN BỔ NGUỒN CUNG V2.0
> **Tóm tắt cốt lõi:** Cơ chế liên kết 3 trụ cột: **Xét hạng bằng DQS** $\rightarrow$ **Ưu tiên đăng ký ca theo Vùng (Layer)** $\rightarrow$ **Hưởng hệ số nhân AhaPoints và Đặc quyền theo Rank**.

```
                   ▲
                  / \     R1 Elite (~15% Fleet) - L2 Minizone (Bán kính ≤ 4km)
                 /R1 \    👉 Ưu tiên Ca 00:00 - 10:00 | Hệ số nhân ×1.5 AhaPoints
                /-----\
               /  R2   \  R2 Active (~35% Fleet) - L3 Mediumzone (Bán kính ≤ 8km)
              /---------\ 👉 Ưu tiên Ca 10:00 - 14:00 | Hệ số nhân ×1.3 AhaPoints
             /    R3     \
            /-------------\ R3 Standard (~35% Fleet) - L4 Bigzone (Vùng diện rộng)
           /   Unranked    \ 👉 Ưu tiên Ca sau 14:00 | Hệ số nhân ×1.1 AhaPoints
          /_________________\
                            Unranked / Trễ ca (~15% Fleet) - L6 MASS (Chạy tự do)
                            👉 Đăng ký Ngày 2+ | Hệ số nhân ×1.0 AhaPoints
```

| Tham số / Quyền lợi | 💎 R1 Elite (Kim Cương) | 🥇 R2 Active (Vàng) | 🥈 R3 Standard (Bạc) | 👤 Unranked (Chưa xếp hạng) |
| :--- | :---: | :---: | :---: | :---: |
| **Tỷ lệ Fleet** | ~15% fleet | ~35% fleet | ~35% fleet | ~15% fleet |
| **Điều kiện lọc (DQS)** | **DQS &ge; 80** | **DQS &ge; 75** | **DQS &ge; 75** | Không yêu cầu |
| **Layer ưu tiên** | **L2 Minizone** (≤4km) | **L3 Mediumzone** (≤8km) | **L4 Bigzone** | **L6 MASS** (Chạy tự do) |
| **Khung giờ đăng ký ca** | **00:00 - 10:00 (Ngày 1)** | **10:00 - 14:00 (Ngày 1)** | **Sau 14:00 (Ngày 1)** | **Ngày 2+** (Slot dư) |
| **Hệ số AhaPoints** | <span style="color:#C2410C; font-weight:bold;">×1.5</span> | <span style="color:#1D4ED8; font-weight:bold;">×1.3</span> | <span style="color:#065F46; font-weight:bold;">×1.1</span> | ×1.0 |
| **Ước tính tích luỹ/ca** | **420 pts** (~70k EPH) | **338 pts** (~65k EPH) | **264 pts** (~60k EPH) | 220 pts (~55k EPH) |
| **Voucher xăng/EV** | **50.000đ/tháng** | **30.000đ/tháng** | ❌ Không | ❌ Không |
| **Đăng ký ca Full-day** | **✅ Hỗ trợ 50% slot** | **✅ Hỗ trợ 50% slot** | ❌ Không | ❌ Không |
| **EV Charging Priority** | **✅ Slot 1** | **✅ Slot 2** | ❌ Không | ❌ Không |
| **Hỗ trợ thực địa** | ✅ Đội trưởng hỗ trợ | ✅ Đội trưởng hỗ trợ | ✅ Đội phó hỗ trợ | ❌ Không |
| **Đặc quyền khác** | Đổi điểm lấy bảo hiểm tai nạn | Quà tặng sinh nhật, ưu đãi | Voucher data 5GB/tháng | Tích lũy cơ bản |

> [!NOTE]
> *   **Công thức tích điểm:** `earned_pts = round(round(trip_GSV ÷ 1.000) * layer_multiplier)`. Điểm số được cộng realtime trên app của tài xế.
> *   **Quy tắc reset điểm:** Reset vào ngày cuối cùng của **mỗi quý**. Thông báo trước 14 ngày để tài xế đổi thưởng.
> *   **Cơ chế ĐBCL:** Vi phạm quy chuẩn dịch vụ phạt thẳng **−50 pts/lần** (điểm tối thiểu sàn bằng 0, không âm).
<!-- slide -->
# PHÂN TÍCH HIỆU QUẢ CƠ CHẾ "POINTS ECONOMY" VÀ PHÚC LỢI ĐẶC QUYỀN
> **Tóm tắt cốt lõi:** Lợi ích kinh tế của Points Economy nằm ở sự dịch chuyển chi phí từ P&L cố định sang chi phí biến đổi được tài trợ từ mạng lưới đối tác (Non-cash benefits).

### 🪙 Động lực thăng hạng từ Điểm số:
*   **Mức đổi thưởng tối thiểu:** 5.000 pts đổi voucher xăng/EV hoặc quà tặng trị giá **50.000đ**.
*   **Tài xế Unranked/MASS:** Chạy ca tự do L6 tối đa chỉ tích lũy **4.840 pts/tháng** (EPH ~55k, 22 ngày chạy) $\rightarrow$ *Không bao giờ đủ điểm đổi thưởng tối thiểu*.
*   **Tài xế R1 Elite:** Chạy L2 Minizone tích lũy **9.240 pts/tháng** $\rightarrow$ *Dư sức đổi các gói bảo hiểm tai nạn cao cấp và voucher quà tặng*.
*   **Tác động:** Tạo lực đẩy tự thân cực mạnh bắt buộc tài xế phải nâng cao chất lượng dịch vụ (DQS) để thăng hạng nhằm tiếp cận các Layer cao hơn.

### 🛡️ Tối ưu hoá Cơ cấu Chi phí:
1.  **Voucher xăng/EV:** Chỉ tập trung nguồn lực tài chính cho nhóm R1 & R2 có đóng góp năng suất cao nhất (15% và 35% fleet), giúp tối ưu **25% ngân sách incentive**.
2.  **Bảo hiểm tai nạn R1:** Áp dụng cơ chế **đổi điểm AhaPoints** thay vì cấp miễn phí:
    *   *Gói bảo vệ 10k/tháng:* Đổi bằng **285 pts**.
    *   *Gói bảo vệ 30k/tháng:* Đổi bằng **857 pts**.
3.  **Mạng lưới trạm hỗ trợ (R3 Standard):** Liên kết với các đối tác sửa xe, vá lốp lưu động giúp Ahamove không tốn chi phí cố định mà vẫn gia tăng phúc lợi thiết thực cho tài xế hạng phổ thông.
````

---

## 3. 📈 HIỆN THỰC HÓA GIÁ TRỊ (VALUE REALIZATION)

| Hiện trạng (Current State) | Chuyển đổi (Transformation) | Trạng thái Mục tiêu (Target State) | Tác động kinh doanh (Measurable Impact) |
| :--- | :--- | :--- | :--- |
| Quy trình tính thưởng ca thủ công trên Excel, rủi ro sai sót và gian lận cao. | ↓ **TỰ ĐỘNG HÓA SQL & APP** ↓ | Điểm AhaPoints tính tự động theo ca đăng ký thực tế hiển thị realtime trên App. | ***Giảm 90% công sức vận hành của Ops team, triệt tiêu rủi ro gian lận điểm thưởng.*** |
| Thiếu hụt tài xế cục bộ vào khung giờ cao điểm peak-hour. | ↓ **ĐIỀU PHỐI CUNG TỰ NGUYỆN** ↓ | Áp dụng hệ số nhân điểm AhaPoints đặc quyền (L2 ×1.5, L3 ×1.3) để tạo lực hút cung tự nhiên. | ***Tăng 35% Fulfillment rate tại các zone trọng yếu; giảm 15% tỷ lệ rơi rớt đơn (SLA drop).*** |
| Quyền lợi các Rank mờ nhạt, tài xế không có mục tiêu phấn đấu. | ↓ **PHÂN CẤP KHUNG GIỜ MỞ ĐĂNG KÝ CA** ↓ | Khóa cứng giờ mở cổng theo Rank (R1: 0-10h, R2: 10-14h, R3: 14h+, Unranked: Ngày 2). | ***Tăng 40% tỷ lệ duy trì chất lượng dịch vụ (DQS &ge; 75/80) của tài xế tích cực.*** |
| Chi phí đảm bảo thu nhập cố định tăng cao gây áp lực lên P&L. | ↓ **CHUYỂN DỊCH PHÚC LỢI PHI TIỀN MẶT** ↓ | Chuyển sang đổi điểm lấy voucher xăng, sạc điện, data, bảo hiểm do đối tác tài trợ. | ***Tối ưu hóa 25% ngân sách incentive, giảm chi phí CPO (Cost per Order) thực tế.*** |
