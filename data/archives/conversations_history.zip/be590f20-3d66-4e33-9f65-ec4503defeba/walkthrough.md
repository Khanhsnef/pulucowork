# Báo cáo kết quả và Hướng dẫn sử dụng Template PowerPoint Ahamove

Tài liệu này tổng hợp kết quả phân tích ngôn ngữ thiết kế slide của Ahamove và hướng dẫn chi tiết cách sử dụng file template PowerPoint (`.pptx`) đã được khởi tạo tự động.

---

## 📈 Kết quả đã thực hiện

Chúng tôi đã xây dựng và xuất thành công file template PowerPoint tại đường dẫn sau trong không gian làm việc:
👉 **[ahamove_report_template.pptx](file:///Users/ts-1148/Desktop/Pulu-workspace/_templates/ahamove_report_template.pptx)**

### Chi tiết 5 Slide Layout đã được thiết lập:

1.  **Slide 1: Báo cáo Hiệu suất 3 Cột (Executive Performance Dashboard)**
    *   *Mục tiêu:* Đánh giá nhanh các chỉ số cốt lõi và đối sánh thị trường.
    *   *Bố cục:*
        *   **Cột 1 (Active Driver):** KPI chính 45.7K tài xế hoạt động (tăng trưởng YoY), kèm bảng phân tích quy mô vùng HAN, SGN, EXP dạng biểu đồ thanh ngang mini. Ở đáy cột có hộp màu xanh lá nổi bật về thu nhập EPH.
        *   **Cột 2 (Demand & Năng suất):** So sánh trực quan giữa SGN (tăng trưởng) và HAN (thách thức) bằng hai hộp màu xanh và đỏ, kèm hình mô phỏng đồ thị xu hướng và nhận định vận hành thực tế.
        *   **Cột 3 (Highlights):** 3 khối màu tương ứng các phân khúc tăng trưởng mũi nhọn: Truck (Cam), Decal (Tím), EV (Xanh lá).
        *   **Bottom Banner:** Dải màu Navy đậm chứa lưu trình định hướng 5 bước kết nối bằng các mũi tên chỉ hướng màu cam nổi bật.
2.  **Slide 2: Ma trận Đối sánh Chiến dịch (Before - Action - Impact Layout)**
    *   *Mục tiêu:* Phân tích nguyên nhân, các bước triển khai hành động thực địa và đánh giá tác động sau chiến dịch.
    *   *Bố cục:*
        *   **Cột 1 (Before):** Đối sánh cơ cấu nguồn cung (Salesforce vs Organic) của T6/2025 và T6/2026 cho 2 thành phố SGN và HAN. Ở dưới cùng có khối cảnh báo màu cam nổi bật.
        *   **Cột 2 (Action):** Sơ đồ quy trình thực tế mà team vận hành đã làm cho SGN (Build Driver Branding) và HAN (Rebuild Acquisition Engine).
        *   **Cột 3 (Impact):** Tỷ lệ dịch chuyển sang nguồn Organic, các mốc vượt target HAN và chi phí tuyển dụng (CPD) cực thấp ở khối màu tím nổi bật.
        *   **Bottom Note Banner:** Tóm tắt bài học kinh nghiệm từ Case Study về mối quan hệ giữa Branding thực địa và tối ưu hóa P&L/CPD.
3.  **Slide 3: Tiêu điểm Dự án (Project Spotlight Dashboard - EV Style)**
    *   *Mục tiêu:* Trình bày báo cáo chuyên sâu của một dự án lớn (ví dụ: Xe điện EV).
    *   *Bố cục:*
        *   **Hàng trên (KPI Row):** 4 thẻ tóm tắt nhanh về số lượng tài xế EV, tỷ lệ Demand VD1, tổng đơn hàng hoàn thành và Huy hiệu Xanh hóa chuyển đổi.
        *   **Hàng giữa (Body):** Phân tích chi phí CPD bên trái, biểu đồ tròn phân bổ nguồn tuyển dụng ở giữa, và khối Insight & Nhận định ở bên phải.
        *   **Hàng dưới (Growth & Plan):** Biểu đồ cột biểu thị đà tăng trưởng thực tế kết hợp dự phóng tương lai (Target Q3) bên trái, kết hợp lộ trình hành động Quý 3 ở bên phải.
        *   **Bottom Banner:** 3 thông điệp chiến lược (Xanh hơn - Tiết kiệm hơn - Bền vững hơn) được phân chia màu sắc nổi bật.
4.  **Slide 4: Dashboard Báo cáo So sánh Chi tiết (Baga Supply Review Layout)**
    *   *Mục tiêu:* Theo dõi chi tiết các khâu của chuỗi cung ứng baga chia theo 2 thành phố lớn.
    *   *Bố cục:*
        *   **Cột 1 (Tiêu chí):** Cột danh mục mô tả (Active driver, Enabled baga, Active baga, Xu hướng, Nhận định).
        *   **Cột SGN & HAN (So sánh song song):** Biểu đồ cột 3 cột nhỏ đại diện cho 3 mốc thời gian đối soát tuần, kèm nhận định chi tiết bên dưới.
        *   **Cột Enabled & Conversion:** Phân tích sâu tỷ trọng tài xế đã bật tính năng (Enabled) và tỷ lệ chuyển đổi thực tế nhận đơn (Conversion) kèm thanh tiến trình (progress bar) màu trực quan.
        *   **Cột Hướng hành động:** 3 bước hành động khẩn cấp được đánh số tròn nổi bật.
5.  **Slide 5: Ma trận Phân hạng & Tiêu chí (Driver Tier Matrix Table)**
    *   *Mục tiêu:* Thể hiện chính sách, điều kiện xếp hạng và quyền lợi tài xế rõ ràng trong một bảng chuẩn hóa.
    *   *Bố cục:*
        *   **Cột tiêu chí bên trái:** Đóng vai trò làm tiêu đề hàng của bảng ma trận (DQS, Năng suất, Giờ mở cổng, Quyền lợi, Hệ số điểm, AhaBenefits).
        *   **4 Cột phân hạng:** R1 Elite (Xanh dương), R2 Active (Vàng cam), R3 Standard (Xanh ngọc), Unranked (Xám nhạt). Mỗi ô chứa các điều kiện và chỉ số cụ thể của hạng đó.
        *   **Bottom Banner:** Nhấn mạnh nguyên tắc tự động hóa chấm điểm và phân cổng FCFS theo rank.

---

## 🛠️ Hướng dẫn Tùy chỉnh Template trong PowerPoint

File PPTX được thiết kế hoàn toàn bằng các hình vẽ hình học gốc của PowerPoint (**Shapes**) kết hợp các hộp văn bản (**Textboxes**), **không dùng hình ảnh tĩnh** cho các biểu đồ hay thẻ card. Do đó, bạn có thể chỉnh sửa trực tiếp và dễ dàng trong PowerPoint:

1.  **Chỉnh sửa số liệu & văn bản:** Click đúp trực tiếp vào các ô chữ hoặc số liệu (ví dụ: `45,700`, `▲ 8.12%`,...) để cập nhật giá trị mới.
2.  **Điều chỉnh biểu đồ mô phỏng:** 
    *   *Biểu đồ cột (Bar charts):* Click chọn thanh hình chữ nhật và kéo rộng/dài ra theo chiều cao mong muốn để khớp với số liệu thực tế.
    *   *Thanh tiến trình (Progress bars):* Click vào thanh màu nằm đè phía trên và kéo giãn ra theo tỷ lệ phần trăm Conversion mới.
3.  **Di chuyển & Thay đổi bố cục:** Bạn có thể chọn toàn bộ card (bao gồm viền và nội dung chữ bên trong) để di chuyển, co giãn hoặc copy sang các slide mới mà không lo vỡ định dạng.
4.  **Thay đổi màu sắc:** Nếu muốn đổi tông màu card (ví dụ: chuyển từ đỏ sang xanh để biểu thị trạng thái HAN đã cải thiện), click vào shape card -> Chọn `Shape Format` -> `Shape Fill` -> Chọn màu mới.

---

## 🤖 Cấu hình Skill tự động hóa (`/pptx`)

Để đảm bảo các phiên làm việc sau này của Claude tự động nhận diện và sử dụng template này, chúng tôi đã cấu hình tệp Skill tại cả 2 cấp độ:
1.  **Skill dự án (Cục bộ):** **[SKILL.md (local)](file:///Users/ts-1148/Desktop/Pulu-workspace/.claude/skills/pptx/SKILL.md)**
2.  **Skill ứng dụng Claude (Toàn cục):** **[SKILL.md (global)](file:///Users/ts-1148/.claude/skills/pptx/SKILL.md)**

### Cơ chế hoạt động:
*   Mỗi khi bạn ra lệnh tạo slide PowerPoint (hoặc dùng `/pptx`), Claude sẽ tự động đọc cấu hình này.
*   Claude sẽ ưu tiên kiểm tra sự tồn tại của tệp template mẫu `_templates/ahamove_report_template.pptx`.
*   Claude sẽ tự động viết code để nạp và chỉnh sửa trực tiếp nội dung trên các slide có sẵn trong template thay vì vẽ lại từ đầu, đảm bảo tính nhất quán của thiết kế thương hiệu Ahamove.

---

## 🔄 Đồng bộ hóa toàn bộ Skills dự án sang Claude toàn cục

Chúng tôi đã thực hiện đồng bộ hóa toàn bộ các Skill đặc thù từ dự án `pulu-workspace` sang thư mục cấu hình toàn cục của Claude tại `/Users/ts-1148/.claude/skills/`.

### Các Skill đã được đồng bộ:
*   `ahamove-brief` -> **[SKILL.md](file:///Users/ts-1148/.claude/skills/ahamove-brief/SKILL.md)**
*   `auto-ops-dashboard-builder` -> **[SKILL.md](file:///Users/ts-1148/.claude/skills/auto-ops-dashboard-builder/SKILL.md)**
*   `competitor-intel-reporter` -> **[SKILL.md](file:///Users/ts-1148/.claude/skills/competitor-intel-reporter/SKILL.md)**
*   `sql-to-report` -> **[SKILL.md](file:///Users/ts-1148/.claude/skills/sql-to-report/SKILL.md)**

*Lưu ý: Đối với skill `pptx`, chúng tôi đã cập nhật thủ công tệp `SKILL.md` toàn cục để tích hợp hướng dẫn sử dụng template mới mà không ghi đè mất các tập lệnh và tiện ích mặc định sẵn có của hệ thống.*


