# Kế hoạch phân tích slide Ahamove & Thiết lập Template PPTX

Tài liệu này phân tích chi tiết ngôn ngữ thiết kế, cấu trúc bố cục (grid system) và hệ thống màu sắc từ các slide báo cáo hiệu suất của Ahamove. Từ đó, đề xuất phương án xây dựng một file template PowerPoint (`.pptx`) chuẩn hóa để tự động hóa hoặc sử dụng cho các báo cáo chiến lược sau này.

---

## 🎨 Phân tích Ngôn ngữ Thiết kế Slide Ahamove

Các slide của Ahamove được thiết kế theo phong cách **Dashboard độ chi tiết cao (High-density Executive Dashboard)**, tương tự như Lark Docs layout. Phong cách này giúp tối ưu hóa không gian hiển thị, trình bày nhiều thông tin dạng bảng biểu, KPI, và phân tích đối sánh trên cùng một trang slide mà không gây cảm giác lộn xộn nhờ hệ thống phân ranh giới (card-based layout) rõ ràng.

### 1. Hệ thống Màu sắc (Color Palette)
*   **Màu chủ đạo (Primary Dark Navy):** `#0A0D1A` hoặc `#111827` – Được dùng làm màu nền cho các thanh header phụ, tiêu đề cột hoặc banner tổng kết ở chân slide (Bottom Banner).
*   **Màu nhấn thương hiệu (Brand Accent Orange):** `#FF5500` hoặc `#FF7F32` – Dùng cho logo, số liệu KPI quan trọng, các điểm nhấn tăng trưởng của phân khúc chính (ví dụ: Truck, SGN).
*   **Màu sắc phân khúc / Trạng thái:**
    *   *Xanh lá cây (Green - Eco/Growth):* `#10B981` – Dùng cho dự án EV, chỉ số tăng trưởng dương (YoY/QoQ), hoặc trạng thái Active tốt.
    *   *Xanh dương (Blue - Standard/Neutral):* `#1E40AF` hoặc `#3B82F6` – Dùng cho phân khúc trung lập, chỉ số nền tảng (Active driver, Decal).
    *   *Tím (Purple - Efficiency/Cost):* `#7C3AED` hoặc `#8B5CF6` – Dùng cho các chỉ số về chi phí tuyển dụng (CPD), chuyển đổi (Conversion).
    *   *Đỏ/Đỏ cam (Red - Challenge/Warning):* `#EF4444` – Dùng cho các khu vực gặp thách thức lớn (HAN demand giảm), chỉ số âm.
*   **Màu nền & Viền (Background & Borders):**
    *   Nền slide tổng thể: Trắng sáng hoặc Xám nhạt `#F9FAFB` để tạo cảm giác chuyên nghiệp, dễ đọc khi trình chiếu.
    *   Nền Card/Panel: Trắng `#FFFFFF` hoặc Xám siêu nhẹ `#F3F4F6` để tách biệt các khu vực.
    *   Đường viền: `#E5E7EB` (mảnh, bo góc `border-radius: 12-16px`).

### 2. Bố cục lưới & Phân cấp Thông tin (Grid System & Typography)
*   **Tỷ lệ Slide:** 16:9 Widescreen (chuẩn trình chiếu hiện đại).
*   **Tiêu đề trang (Header):**
    *   Tiêu đề chính: Font **Montserrat** (hoặc Arial Bold nếu font hệ thống hạn chế), kích thước lớn (32-36pt), in hoa, phối hợp 2 màu Navy & Orange (ví dụ: `SUPPLY PERFORMANCE` màu Navy + `Q2.2026` màu Orange).
    *   Tiêu đề phụ (Subtitle): Mô tả thông tin ngữ cảnh bên dưới tiêu đề chính, dạng chữ thường nghiêng nhẹ hoặc màu xám trung tính, font **Inter** / **Arial** (12-14pt).
    *   Thẻ nhãn góc phải (Topic Pill): Một khối bo góc màu Navy viền cam chứa thông tin tóm lược phân loại slide (ví dụ: `Q2.26 SUPPLY PERFORMANCE`).
*   **Cấu trúc Lưới đa cột (Multi-column Cards):**
    *   *Layout 3 cột:* Phổ biến nhất (Slide 1, Slide 2, Slide 6). Cột 1 thường là core metric (Active Driver), Cột 2 là Demand & Năng suất (đối sánh HAN vs SGN), Cột 3 là Growth Highlights hoặc Action Plan.
    *   *Layout Ma trận / Bảng biểu:* Dành cho các slide mô hình như Driver Ranking hoặc Baga Supply (Slide 4, Slide 5). Cột tiêu chí bên trái ngoài cùng, theo sau là các cột phân hạng tài xế (Elite, Active, Standard, Unranked) với màu nền nhạt tương ứng với hạng.
*   **Banner chân trang (Strategic Bottom Banner):**
    *   Dải màu Navy đậm full-width ở đáy slide, chứa các mũi tên quy trình hoặc nguyên tắc cốt lõi (Key Design Principles) màu trắng/cam giúp định hướng chiến lược.
    *   Hoặc footer thanh mảnh hiển thị danh mục báo cáo và số trang dạng: `Driver Management • Baga Supply Review • Jun-Jul 2026`.

---

## 🛠️ Đề xuất Thiết kế Template Slide Báo cáo (PPTX)

Chúng ta sẽ tạo ra một file PowerPoint Template (`.pptx`) chứa **4 mẫu slide layout** tiêu biểu nhất, được lập trình cấu trúc hoàn chỉnh bằng thư viện `python-pptx`. 

### Mẫu 1: Slide Báo cáo Hiệu suất 3 Cột (Executive Performance Dashboard)
*   Bố cục lưới 3 cột dọc (tỷ lệ 30% - 40% - 30%) chứa các khung thông tin (Card) bo góc.
*   Header chuẩn Ahamove có logo và nhãn phân loại slide ở góc trên bên phải.
*   Bottom banner dạng chuỗi tiến trình 5 bước kết nối bằng mũi tên.

### Mẫu 2: Slide Đối sánh Chiến dịch (Before - Action - Impact Layout)
*   Cột 1: So sánh cơ cấu nguồn cung tài xế trước/sau (Before).
*   Cột 2: Quy trình hành động của nhóm vận hành dưới dạng lưu đồ 4 bước (Action).
*   Cột 3: Kết quả đo lường, chi phí tuyển dụng và mức độ hiệu quả (Impact).

### Mẫu 3: Slide Tổng quan Dự án (Project Spotlight Dashboard - EV Style)
*   Thanh ngang chứa 4 thẻ KPI tóm tắt hàng đầu (Top Row KPIs).
*   Phần thân chia thành 2 phần chính: Phân tích định lượng (biểu đồ tròn/đối sánh chi phí) bên trái; Nhận định chuyên sâu (Insight list) bên phải.
*   Đáy slide hiển thị mục tiêu hành động Quý tiếp theo và biểu đồ đường dự phóng tăng trưởng.

### Mẫu 4: Slide Ma trận So sánh Hạng & Tiêu chí (Driver Tier Matrix Table)
*   Cấu trúc bảng ma trận phân hạng (4 cột thứ hạng tài xế, 1 cột tiêu chí).
*   Phối màu cho các cột hạng: R1 Elite (Xanh dương), R2 Active (Vàng cam), R3 Standard (Xanh ngọc), Unranked (Xám).
*   Các thẻ ghi chú và nguyên tắc hành động bổ sung nằm ở đáy trang.

---

## 💻 Kế hoạch Triển khai Code (python-pptx)

Chúng ta sẽ viết và thực thi một script Python `generate_pptx_template.py` để dựng trực tiếp các slide này với đầy đủ hình khối, nhãn văn bản, vị trí chính xác và màu sắc theo bộ mã HEX đã định nghĩa ở trên.

### Cấu trúc file mã nguồn đề xuất:
1.  **Khởi tạo Presentation & Thiết lập kích thước:** 16:9 (`13.33 inches x 7.5 inches`).
2.  **Định nghĩa bộ mã màu (RGBColor):** Navy, Orange, Green, Blue, Purple, Red, Gray.
3.  **Xây dựng hàm Helper:**
    *   `add_slide_header(slide, title_navy, title_orange, subtitle, category_tag)`: Vẽ logo giả định, ghi tiêu đề và vẽ nhãn tag góc phải.
    *   `add_card(slide, left, top, width, height, border_color, fill_color)`: Tạo các khung card bo góc.
    *   `add_bottom_banner(slide, items_list)`: Tạo thanh footer chiến lược.
4.  **Dựng từng slide mẫu cụ thể** bằng cách định vị tọa độ (inches) cho các khối vẽ.
5.  **Lưu file** dưới tên `/Users/ts-1148/Desktop/Pulu-workspace/_templates/ahamove_report_template.pptx`.

---

## 📈 Kế hoạch Kiểm thử & Bàn giao (Verification Plan)

### Kiểm tra tự động
*   Chạy script Python để sinh file PowerPoint không lỗi biên dịch hoặc thư viện.

### Kiểm tra thủ công (User Verification)
*   Mở file `.pptx` vừa sinh trên Microsoft PowerPoint hoặc Keynote để kiểm tra:
    *   Tỷ lệ slide có chuẩn 16:9 không.
    *   Các khối màu và văn bản có bị đè lên nhau hoặc lệch tọa độ không.
    *   Font chữ và màu sắc có đồng bộ và trực quan như mong muốn không.
