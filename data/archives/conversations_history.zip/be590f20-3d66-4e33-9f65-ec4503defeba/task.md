- [x] Tạo file script Python `generate_pptx_template.py` trong thư mục scratch của cuộc hội thoại để lập trình dựng các slide layout.
- [x] Chạy script Python để xuất file `ahamove_report_template.pptx` sang thư mục `/Users/ts-1148/Desktop/Pulu-workspace/_templates/`.
- [x] Xác minh sự tồn tại và cấu trúc của file PowerPoint được tạo.
- [x] Tạo file `walkthrough.md` tổng kết các slide đã dựng và hướng dẫn sử dụng.
- [x] Cấu hình Skill mới `/pptx` tại `.claude/skills/pptx/SKILL.md` (cục bộ) và cập nhật `SKILL.md` toàn cục của Claude tại `/Users/ts-1148/.claude/skills/pptx/SKILL.md` để ưu tiên nạp tệp mẫu này cho các báo cáo slide sau.

