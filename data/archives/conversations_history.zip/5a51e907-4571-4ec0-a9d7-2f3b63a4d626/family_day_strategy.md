# 📊 CHIẾN LƯỢC GẮN KẾT CỘNG ĐỒNG & TỐI ƯU HÓA HIỆU SUẤT TÀI XẾ NHÂN NGÀY HỘI GIA ĐÌNH AHAMOVE 2026

## 1. TÓM TẮT THỰC THI (EXECUTIVE SUMMARY)

### 📊 Executive Summary
Dựa trên phân tích dữ liệu lịch sử cohort (tháng 1/2025 – tháng 4/2026), Ahamove ghi nhận **vực sâu rò rỉ nguồn cung lớn nhất nằm ở 60 ngày đầu tiên (mất mát ~51% tài xế đăng ký mới)**. Trong khi các chính sách Incentive tài chính ngắn hạn ngày càng chịu áp lực tối ưu hóa **CPO (Cost per Order)**, việc kích hoạt động lực phi tài chính dựa trên **tâm lý học hành vi (Driver Psychology)** là chìa khóa chiến lược để cải thiện giữ chân nguồn cung cốt lõi. 

Chiến dịch **Ngày hội Gia đình Ahamove 2026** không đơn thuần là một hoạt động truyền thông thương hiệu, mà là một **quyết định vận hành chiến lược**. Bằng cách chạm sâu vào nhu cầu **Relatedness (Sự gắn kết cộng đồng và gia đình)** thuộc mô hình tự quyết (Self-Determination Theory), chiến dịch hướng tới việc củng cố điểm tựa tinh thần đằng sau tay lái, chuyển hóa lòng tự hào nghề nghiệp thành cam kết vận hành thực địa (tăng **Acceptance Rate** và **Fulfillment Rate** vào giờ cao điểm).

---

### 🎯 Mục tiêu Kinh doanh (SCR Framework)
*   **Tình huống (Situation):** Ahamove đang vận hành mạng lưới hơn **10,500 đối tác tài xế 2 bánh hoạt động hàng tuần** tại SGN và HAN. Đây là lực lượng nòng cốt đảm bảo SLA cho các dịch vụ Instant (Siêu tốc, Giao ngay 1H, Ghép đơn).
*   **Bất cập (Complication):** Áp lực mưu sinh, bụi đường và thời gian di chuyển kéo dài gây căng thẳng tâm lý lớn cho tài xế, tạo ra khoảng cách lớn với con cái và gia đình. Điều này dẫn đến tỷ lệ **Driver Churn Rate** trung bình tháng ở mức **8.5%** và sự thiếu hụt nguồn cung cục bộ trong các khung giờ cao điểm tối hoặc cuối tuần do tài xế ưu tiên về nhà.
*   **Giải pháp (Resolution):** Triển khai chiến dịch truyền thông đa kênh tích hợp **Ngày hội Gia đình Ahamove 2026** (Online storytelling + Offline Family Event + Trao học bổng "Aha Ươm mầm tương lai" + Gói bảo hiểm gia đình mở rộng) nhằm gia tăng **Switching Cost phi tài chính**, giữ chân đối tác lâu dài và cải thiện hiệu suất nguồn cung.

---

### 📈 Chỉ số Cốt lõi (Important KPIs)
Để đánh giá chính xác tác động của chiến dịch đối với hiệu quả kinh doanh và vận hành, DM Team sẽ giám sát chặt chẽ các chỉ số sau:
1.  **Driver Churn Rate (Hằng tháng):** Mục tiêu giảm từ **8.5% xuống < 6.5%**.
2.  **Peak-hour Fulfillment Rate (FR):** Đạt tối thiểu **88%** (tăng từ baseline 82%).
3.  **Acceptance Rate (AR):** Duy trì trung bình **≥ 85%** toàn đội ngũ.
4.  **Referral Rate (Giới thiệu tài xế mới tự nhiên):** Tăng **50%** lượng tài xế mới đăng ký thông qua mã giới thiệu từ core drivers hoạt động ổn định.
5.  **Driver CSAT (Chỉ số hài lòng):** Đạt điểm khảo sát in-app trung bình **≥ 4.6 / 5**.

---

## 2. KHUNG PHÂN TÍCH (ANALYSIS FRAMEWORK)

### Phân tích Mô tả (Đánh giá Hiện trạng - Descriptive Analysis)
*   **Hạ tầng Vận hành hiện tại:** Ahamove quản lý và giao tiếp với đối tác tài xế thông qua ứng dụng tài xế tích hợp, hệ thống thông báo đẩy (In-app Push Notification) và Zalo OA. Mức độ sẵn sàng công nghệ của tài xế rất cao, cho phép tiếp cận thông điệp theo thời gian thực.
*   **Benchmarks Hiệu suất:** Theo nghiên cứu benchmark từ các đối thủ lớn (Grab, Be, XanhSM):
    *   Grab tổ chức thường niên các chương trình gia đình gắn kết giúp duy trì tỷ lệ hoạt động ổn định.
    *   XanhSM áp dụng mô hình Employment (Hợp đồng lao động đầy đủ chế độ) đạt tỷ lệ churn cực thấp (**15-25%/năm**).
    *   Ahamove hiện đang ở mô hình **Structured Gig** (có hệ thống xếp hạng R1-R3 và AhaBenefits) nhưng chưa tối ưu hóa các đặc quyền phi tài chính như bảo hiểm gia đình và các hoạt động cộng đồng quy mô lớn để gia tăng rào cản rời bỏ nền tảng (Switching Cost).
*   **Hệ sinh thái Liên quan:** Bộ phận **Driver Management (DM)** chủ trì phối hợp cùng team **Brand Marketing (PR)** để sản xuất nội dung truyền thông, team **Operations (Ops)** để giám sát SLA thực địa, và bộ phận **Business Intelligence (BI)** để đo lường các chỉ số giữ chân.

---

### Phân tích Chẩn đoán (Điều tra Nguyên nhân Gốc rễ - Diagnostic Analysis)
*   **Khoảng trống Chất lượng (Quality Gaps):** Các thông điệp gửi tới tài xế hiện nay đang bị quá tải bởi các nội dung mang tính **Functional** (áp lực thưởng/phạt, chỉ số DQS, tỷ lệ hủy đơn DCR, chỉ dẫn đơn hàng). Nền tảng đang thiếu trầm trọng các điểm chạm mang tính **Emotional** (thấu cảm nỗ lực mưu sinh, tôn vinh vai trò người trụ cột gia đình).
*   **Điểm nghẽn Vận hành (Bottlenecks):** Vào khung giờ cao điểm chiều tối (17h - 19h30), nhu cầu đơn hàng đạt đỉnh nhưng nguồn cung lại sụt giảm mạnh do tâm lý tài xế muốn nhanh chóng về ăn cơm cùng con cái (như câu thoại trong bài viết: *"Con đợi ba về ăn chung, ba chạy xe cẩn thận"*). Việc thiếu hụt nguồn cung thời điểm này làm tăng đáng kể tỷ lệ rớt đơn và SLA drop.
*   **Lệch pha Chiến lược (Misalignments):** Ngân sách Incentive hiện tại đang tập trung quá mức vào việc kích hoạt ngắn hạn (đốt tiền promo đơn lẻ), dẫn đến tình trạng tài xế chỉ chạy khi có thưởng lớn và sẵn sàng tắt app sang chạy đối thủ khi hết thưởng. Việc đầu tư vào các chương trình phúc lợi gia đình chưa được chuẩn hóa thành một trụ cột giữ chân dài hạn (Retention Anchor).

---

### Phân tích Dự báo (Mô hình hóa Tương lai - Predictive Analysis)
*   **Dự phóng Kết quả (Outcome Projections):** Dựa trên mô hình *Rusbult Investment Model*, việc đưa yếu tố gia đình vào đặc quyền gắn kết sẽ nâng cao rào cản rời bỏ nền tảng. Dự kiến sau chiến dịch, tỷ lệ giữ chân **D60 Retention** (vùng nhạy cảm nhất) sẽ tăng thêm **5 - 8%** đối với nhóm tài xế tham gia tích cực.
*   **Xác suất Thực thi (Implementation Probability):** Đạt mức **~85%** độ tin cậy. Cộng đồng tài xế Ahamove vốn có tính liên kết tự nhiên cao thông qua các hội nhóm tự phát. Việc Ahamove đứng ra tổ chức và vinh danh gia đình họ sẽ được hưởng ứng mạnh mẽ.
*   **Mô hình hóa Tác động (Impact Modeling):** Tăng chỉ số vòng đời tài xế (**Driver LTV**) trung bình từ 3.5 tháng lên **6 - 8 tháng** đối với nhóm core supply. Đồng thời, việc lan tỏa tự nhiên hình ảnh tài xế Ahamove có cuộc sống gia đình hạnh phúc trên mạng xã hội sẽ giúp giảm **CAC (Customer Acquisition Cost)** do tăng lượng đăng ký tự nhiên từ người thân, bạn bè đối tác (Referral Network Effect).

---

### Phân tích Đề xuất (Khuyến nghị Chiến lược - Prescriptive Analysis)
*   **Lộ trình Tối ưu (Optimal Path):** Triển khai chiến dịch truyền thông 3 giai đoạn:
    1.  **Phase 1: Gieo cảm xúc (Online Contest):** Sử dụng chất liệu câu chuyện người thực việc thực (bản nháp câu chuyện do user cung cấp đã được biên tập tối ưu) để khởi động cuộc thi ảnh *"Điểm Tựa Sau Tay Lái"* trên các hội nhóm tài xế.
    2.  **Phase 2: D-Day (Ngày hội Gia đình Offline):** Tổ chức ngày hội tại văn phòng hai miền. Vinh danh top 50 con em tài xế vượt khó học giỏi qua quỹ học bổng *"Aha Ươm mầm tương lai"*.
    3.  **Phase 3: Giá trị bền vững (Welfare Escalation):** Công bố đặc quyền nâng cấp bảo hiểm sức khỏe cho người thân đối với hạng tài xế Kim Cương (R1) và Vàng (R2) nhằm tối đa hóa rào cản rời mạng lưới.
*   **Tối ưu Nguồn lực (Resource Optimization):** Trích 15% ngân sách marketing cộng đồng quý II để đầu tư cho quà tặng và học bổng. Chi phí tổ chức offline sẽ được tối ưu hóa thông qua việc đồng tài trợ từ các thương hiệu đối tác lớn (ví dụ: các nhãn hàng xăng dầu, bảo hiểm, đồ dùng học tập).
*   **Bản đồ Thực thi (Execution Roadmap):**
    *   *Tuần 1 (16/06 - 22/06):* Duyệt kế hoạch, thiết kế ấn phẩm truyền thông, chuẩn bị các kênh in-app và Zalo.
    *   *Tuần 2 (23/06 - 27/06):* Phát động cuộc thi online, mở cổng đăng ký tham dự Ngày hội offline.
    *   *Tuần 3 (28/06 - Ngày Gia đình Việt Nam):* Tổ chức sự kiện offline đồng loạt tại SGN & HAN.
    *   *Tuần 4 (29/06 - 05/07):* Báo cáo chỉ số vận hành sau chiến dịch và truyền thông hậu sự kiện.

---

## 3. 📈 HIỆN THỰC HÓA GIÁ TRỊ (VALUE REALIZATION)

Dưới đây là bảng đánh giá sự chuyển dịch kỳ vọng trước và sau khi triển khai chiến dịch gắn kết gia đình tài xế:

| Hiện trạng (Current State) | Chuyển đổi (Transformation) | Trạng thái Mục tiêu (Target State) | Tác động Vận hành & Kinh doanh |
| :--- | :--- | :--- | :--- |
| Giao tiếp khô khan, chỉ tập trung vào chỉ số phạt/thưởng khiến tài xế cảm thấy bị áp lực và thiếu sự tôn trọng. | ↓ TRUYỀN THÔNG CẢM XÚC & TRI ÂN ↓ | Triển khai thông điệp truyền thông đa kênh tôn vinh "Người hùng thầm lặng" nhân Ngày hội Gia đình. | ***Tăng điểm hài lòng Driver CSAT lên ≥ 4.6/5; tăng lòng tự hào nghề nghiệp.*** |
| Tài xế tắt app sớm vào giờ cao điểm chiều tối để về nhà, gây hụt nguồn cung cục bộ và đẩy CPO lên cao do phải tăng surge incentive. | ↓ NGÀY HỘI GIA ĐÌNH & QUỸ HỌC BỔNG ↓ | Tổ chức trao học bổng thiết thực cho con tài xế đạt thành tích học giỏi và tổ chức ngày hội offline kết nối gia đình. | ***Tăng tỷ lệ hoàn thành đơn FR vào ca cao điểm đạt ≥ 88%, giảm áp lực đốt tiền incentive đột xuất.*** |
| Rủi ro rời mạng lưới cao do các đối thủ cạnh tranh liên tục tung chương trình thưởng lôi kéo. | ↓ BẢO HIỂM GIA ĐÌNH & ĐẶC QUYỀN R1/R2 ↓ | Công bố gói bảo hiểm chăm sóc sức khỏe cho người thân (vợ/con) của core driver. | ***Giảm Driver Churn Rate hằng tháng xuống < 6.5%; nâng cao Switching Cost phi tài chính.*** |

---

## 🔗 THAM CHIẾU TÀI LIỆU TRONG WORKSPACE
DM Team đã tạo và lưu trữ đầy đủ các tài liệu chi tiết phục vụ cho việc thực thi chiến dịch này tại các đường dẫn sau:
- 📝 **Kịch bản chi tiết các nội dung gửi tài xế (Mạng xã hội, Zalo, In-app Push):** [2026-06-family-day-social-post.md](file:///Users/ts-1148/Desktop/Pulu-workspace/Output/Ahamove/03. DRIVER_COMMUNITY/content/2026-06-family-day-social-post.md)
- 📅 **Kế hoạch chi tiết và ngân sách tổ chức sự kiện Offline:** [2026-06-family-day-event-plan.md](file:///Users/ts-1148/Desktop/Pulu-workspace/Output/Ahamove/03. DRIVER_COMMUNITY/events/2026-06-family-day-event-plan.md)
