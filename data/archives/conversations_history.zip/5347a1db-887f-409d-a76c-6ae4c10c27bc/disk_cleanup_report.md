# 🖥️ Báo Cáo Dọn Dẹp Ổ Cứng — 2026-06-12

## 📊 Tổng Quan

| | |
|--|--|
| **Tổng dung lượng** | 228 GB |
| **Đang dùng** | 12 GB (41%) |
| **Còn trống** | 18 GB |
| **Mục tiêu** | Giải phóng thêm ~15-20 GB |

---

## 🔴 XÓA NGAY — An Toàn 100% (~8.4 GB)

### 1. Downloads — Installer cũ (~1.8 GB)
Các file đã cài xong, không cần giữ:

| File | Size | Ghi chú |
|------|------|---------|
| `Obsidian.dmg` | 182 MB | Đã cài xong |
| `Codex.dmg` | 300 MB | Đã cài (hoặc không dùng) |
| `VSCode-darwin-universal.dmg` | 250 MB | Đã cài xong |
| `Claude.dmg` | 242 MB | Đã cài xong |
| `python-3.14.4-macos11.pkg` | 72 MB | Đã cài xong |
| `World.Monitor_2.5.23_x64.dmg` | 43 MB | Đã cài xong |
| `SideloadlySetup.dmg` | 42 MB | Đã cài xong |

**→ Xóa tất cả: ~1.1 GB**

### 2. Library/Caches — Có thể xóa an toàn (~4 GB)

| Thư mục | Size | Ghi chú |
|---------|------|---------|
| `Google` (cache) | 1.8 GB | Chrome cache — xóa được, sẽ tự rebuild |
| `LarkInternational` (cache) | 1.1 GB | Lark cache — xóa được |
| `com.spotify.client` | 761 MB | Spotify offline cache |
| `com.vng.zalo.ShipIt` | 721 MB | Zalo update cache cũ |
| `com.anthropic.claudefordesktop.ShipIt` | 676 MB | Claude update cache cũ |
| `com.openai.atlas` | 412 MB | ChatGPT update cache |
| `antigravity-updater` | 323 MB | Update cache |
| `sideloadly` | 283 MB | |
| `ms-playwright-go` | 251 MB | Playwright browsers — xóa nếu không dev |

**→ Xóa an toàn: ~4 GB**

### 3. npm Cache (~1.1 GB)
```bash
npm cache clean --force
```
**→ Giải phóng: ~1.1 GB**

### 4. Library/Developer (~2.4 GB)
Xcode simulators và build artifacts cũ.
```bash
xcrun simctl delete unavailable  # Xóa simulator cũ
```
**→ Tiết kiệm: 0.5–2 GB**

---

## 🟠 CÂN NHẮC — Tùy Bạn (~35 GB)

### 5. ZaloData (~12 GB) ⚠️
Dữ liệu chat Zalo lưu local. Xóa sẽ mất lịch sử chat offline.
- **Nếu dùng Zalo Web** → có thể xóa
- **Nếu cần lịch sử** → giữ lại

### 6. Claude App Data (~12 GB) ⚠️
```
~/Library/Application Support/Claude (12 GB)
~/Library/Application Support/Claude-3p (340 MB)
```
Có thể chứa conversation history, model files. Kiểm tra trước khi xóa.

### 7. Google Chrome Data (~9.5 GB)
```
~/Library/Application Support/Google (9.5 GB)
```
Profile, extensions, saved passwords — **KHÔNG xóa** nếu muốn giữ data Chrome.

### 8. Fuji Picture (~897 MB)
File ảnh trong Downloads — chuyển vào thư mục Photos hoặc xóa nếu đã backup.

---

## 🟢 KHÔNG XÓA

| Thư mục | Lý do |
|---------|-------|
| `Antigravity IDE` (748 MB) | Đang dùng |
| `LarkInternational` App Support (2.3 GB) | Data Lark |
| `Telegram Desktop` (104 MB) | Chat history |
| `Obsidian` (34 MB) | Vault mới cài |

---

## 🚀 Lệnh Dọn Dẹp Nhanh (Copy-Paste)

```bash
# 1. Xóa DMG/PKG cũ trong Downloads
rm -f ~/Downloads/Obsidian.dmg ~/Downloads/Codex.dmg ~/Downloads/VSCode-darwin-universal.dmg \
      ~/Downloads/Claude.dmg ~/Downloads/python-3.14.4-macos11.pkg \
      ~/Downloads/World.Monitor_2.5.23_x64.dmg ~/Downloads/SideloadlySetup.dmg

# 2. Xóa update ShipIt cache
rm -rf ~/Library/Caches/com.vng.zalo.ShipIt
rm -rf ~/Library/Caches/com.anthropic.claudefordesktop.ShipIt
rm -rf ~/Library/Caches/com.openai.atlas
rm -rf ~/Library/Caches/antigravity-updater
rm -rf ~/Library/Caches/sideloadly

# 3. npm cache
npm cache clean --force

# 4. Xcode simulators cũ
xcrun simctl delete unavailable 2>/dev/null || true
```

---

## 📈 Kết Quả Ước Tính

| Hành động | Giải phóng |
|-----------|-----------|
| Xóa DMG/PKG cũ | ~1.1 GB |
| Xóa ShipIt/Update caches | ~2.1 GB |
| Xóa npm cache | ~1.1 GB |
| Xóa Google/Spotify/Lark cache | ~3.5 GB |
| **Tổng an toàn** | **~7.8 GB** |
| Nếu xóa thêm ZaloData | +12 GB |

*Sau dọn dẹp: ~26 GB trống (từ 18 GB hiện tại)*
