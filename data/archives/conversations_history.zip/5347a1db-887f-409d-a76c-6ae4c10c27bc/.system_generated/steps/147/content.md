Title: GitHub - danny-avila/LibreChat: Enhanced ChatGPT Clone: Features Agents, MCP, Skills, DeepSeek, Anthropic, AWS, OpenAI, Responses API, Azure, Groq, o1, GPT-5, Mistral, OpenRouter, Vertex AI, Gemini, Artifacts, AI model switching, message search, Code Interpreter, langchain, DALL-E-3, OpenAPI Actions, Functions, Secure Multi-User Auth, Presets, open-source for self-hosting. Active · GitHub

Description: Enhanced ChatGPT Clone: Features Agents, MCP, Skills, DeepSeek, Anthropic, AWS, OpenAI, Responses API, Azure, Groq, o1, GPT-5, Mistral, OpenRouter, Vertex AI, Gemini, Artifacts, AI model switching,...

Source: https://github.com/danny-avila/LibreChat

---

[Skip to content](https://github.com/danny-avila/LibreChat#start-of-content)

[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fdanny-avila%2FLibreChat)
- PlatformAI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryNewIntegrate external tools](https://github.com/mcp)DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)[View all features](https://github.com/features)
- AI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
- APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
- SolutionsBY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[View all industries](https://github.com/solutions/industry)[View all solutions](https://github.com/solutions)

- BY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)
- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
- BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
- BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[View all industries](https://github.com/solutions/industry)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)
- ResourcesEXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)[View all resources](https://github.com/resources)
- EXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
- EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
- SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)

- Open SourceCOMMUNITY[GitHub SponsorsFund open source developers](https://github.com/sponsors)PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[Accelerator](https://github.com/accelerator)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- COMMUNITY[GitHub SponsorsFund open source developers](https://github.com/sponsors)
- [GitHub SponsorsFund open source developers](https://github.com/sponsors)
- PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[Accelerator](https://github.com/accelerator)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [Accelerator](https://github.com/accelerator)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
- REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
- EnterpriseENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- ENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [Pricing](https://github.com/pricing)
- AI CODE CREATION[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)[MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- DEVELOPER WORKFLOWS[ActionsAutomate any workflow](https://github.com/features/actions)[CodespacesInstant dev environments](https://github.com/features/codespaces)[IssuesPlan and track work](https://github.com/features/issues)[Code ReviewManage code changes](https://github.com/features/code-review)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
- APPLICATION SECURITY[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)

- EXPLORE[Why GitHub](https://github.com/why-github)[Documentation](https://docs.github.com)[Blog](https://github.blog)[Changelog](https://github.blog/changelog)[Marketplace](https://github.com/marketplace)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
- [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
- [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
- [MCP RegistryNewIntegrate external tools](https://github.com/mcp)
[GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
[GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
[MCP RegistryNewIntegrate external tools](https://github.com/mcp)
- [ActionsAutomate any workflow](https://github.com/features/actions)
- [CodespacesInstant dev environments](https://github.com/features/codespaces)
- [IssuesPlan and track work](https://github.com/features/issues)
- [Code ReviewManage code changes](https://github.com/features/code-review)
[ActionsAutomate any workflow](https://github.com/features/actions)
[CodespacesInstant dev environments](https://github.com/features/codespaces)
[IssuesPlan and track work](https://github.com/features/issues)
[Code ReviewManage code changes](https://github.com/features/code-review)
- [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
- [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
- [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
[GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
[Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
[Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)
- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com)
- [Blog](https://github.blog)
- [Changelog](https://github.blog/changelog)
- [Marketplace](https://github.com/marketplace)
[Why GitHub](https://github.com/why-github)
[Documentation](https://docs.github.com)
[Blog](https://github.blog)
[Changelog](https://github.blog/changelog)
[Marketplace](https://github.com/marketplace)
[View all features](https://github.com/features)
- BY COMPANY SIZE[Enterprises](https://github.com/enterprise)[Small and medium teams](https://github.com/team)[Startups](https://github.com/enterprise/startups)[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)
- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
- BY USE CASE[App Modernization](https://github.com/solutions/use-case/app-modernization)[DevSecOps](https://github.com/solutions/use-case/devsecops)[DevOps](https://github.com/solutions/use-case/devops)[CI/CD](https://github.com/solutions/use-case/ci-cd)[View all use cases](https://github.com/solutions/use-case)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
- BY INDUSTRY[Healthcare](https://github.com/solutions/industry/healthcare)[Financial services](https://github.com/solutions/industry/financial-services)[Manufacturing](https://github.com/solutions/industry/manufacturing)[Government](https://github.com/solutions/industry/government)[View all industries](https://github.com/solutions/industry)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)
- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)

- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)
[Enterprises](https://github.com/enterprise)
[Small and medium teams](https://github.com/team)
[Startups](https://github.com/enterprise/startups)
[Nonprofits](https://github.com/solutions/industry/nonprofits)
- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)
[App Modernization](https://github.com/solutions/use-case/app-modernization)
[DevSecOps](https://github.com/solutions/use-case/devsecops)
[DevOps](https://github.com/solutions/use-case/devops)
[CI/CD](https://github.com/solutions/use-case/ci-cd)
[View all use cases](https://github.com/solutions/use-case)
- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)
[Healthcare](https://github.com/solutions/industry/healthcare)
[Financial services](https://github.com/solutions/industry/financial-services)
[Manufacturing](https://github.com/solutions/industry/manufacturing)
[Government](https://github.com/solutions/industry/government)
[View all industries](https://github.com/solutions/industry)
[View all solutions](https://github.com/solutions)
- EXPLORE BY TOPIC[AI](https://github.com/resources/articles?topic=ai)[Software Development](https://github.com/resources/articles?topic=software-development)[DevOps](https://github.com/resources/articles?topic=devops)[Security](https://github.com/resources/articles?topic=security)[View all topics](https://github.com/resources/articles)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
- EXPLORE BY TYPE[Customer stories](https://github.com/customer-stories)[Events & webinars](https://github.com/resources/events)[Ebooks & reports](https://github.com/resources/whitepapers)[Business insights](https://github.com/solutions/executive-insights)[GitHub Skills](https://skills.github.com)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
- SUPPORT & SERVICES[Documentation](https://docs.github.com)[Customer support](https://support.github.com)[Community forum](https://github.com/orgs/community/discussions)[Trust center](https://github.com/trust-center)[Partners](https://github.com/partners)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)
- [AI](https://github.com/resources/articles?topic=ai)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [View all topics](https://github.com/resources/articles)
[AI](https://github.com/resources/articles?topic=ai)
[Software Development](https://github.com/resources/articles?topic=software-development)
[DevOps](https://github.com/resources/articles?topic=devops)
[Security](https://github.com/resources/articles?topic=security)
[View all topics](https://github.com/resources/articles)
- [Customer stories](https://github.com/customer-stories)
- [Events & webinars](https://github.com/resources/events)
- [Ebooks & reports](https://github.com/resources/whitepapers)
- [Business insights](https://github.com/solutions/executive-insights)
- [GitHub Skills](https://skills.github.com)
[Customer stories](https://github.com/customer-stories)

[Events & webinars](https://github.com/resources/events)
[Ebooks & reports](https://github.com/resources/whitepapers)
[Business insights](https://github.com/solutions/executive-insights)
[GitHub Skills](https://skills.github.com)
- [Documentation](https://docs.github.com)
- [Customer support](https://support.github.com)
- [Community forum](https://github.com/orgs/community/discussions)
- [Trust center](https://github.com/trust-center)
- [Partners](https://github.com/partners)
[Documentation](https://docs.github.com)
[Customer support](https://support.github.com)
[Community forum](https://github.com/orgs/community/discussions)
[Trust center](https://github.com/trust-center)
[Partners](https://github.com/partners)
[View all resources](https://github.com/resources)
- COMMUNITY[GitHub SponsorsFund open source developers](https://github.com/sponsors)
- [GitHub SponsorsFund open source developers](https://github.com/sponsors)
- PROGRAMS[Security Lab](https://securitylab.github.com)[Maintainer Community](https://maintainers.github.com)[Accelerator](https://github.com/accelerator)[GitHub Stars](https://stars.github.com)[Archive Program](https://archiveprogram.github.com)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [Accelerator](https://github.com/accelerator)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
- REPOSITORIES[Topics](https://github.com/topics)[Trending](https://github.com/trending)[Collections](https://github.com/collections)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
- [GitHub SponsorsFund open source developers](https://github.com/sponsors)
[GitHub SponsorsFund open source developers](https://github.com/sponsors)
- [Security Lab](https://securitylab.github.com)
- [Maintainer Community](https://maintainers.github.com)
- [Accelerator](https://github.com/accelerator)
- [GitHub Stars](https://stars.github.com)
- [Archive Program](https://archiveprogram.github.com)
[Security Lab](https://securitylab.github.com)
[Maintainer Community](https://maintainers.github.com)
[Accelerator](https://github.com/accelerator)
[GitHub Stars](https://stars.github.com)
[Archive Program](https://archiveprogram.github.com)
- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)
[Topics](https://github.com/topics)
[Trending](https://github.com/trending)
[Collections](https://github.com/collections)
- ENTERPRISE SOLUTIONS[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- AVAILABLE ADD-ONS[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
- [Enterprise platformAI-powered developer platform](https://github.com/enterprise)
[Enterprise platformAI-powered developer platform](https://github.com/enterprise)
- [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
[GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
[Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
[Premium SupportEnterprise-grade 24/7 support](https://github.com/premium-support)
[Pricing](https://github.com/pricing)

# Search code, repositories, users, issues, pull requests...
[Search syntax tips](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax)

# Provide feedback
We read every piece of feedback, and take your input very seriously.

To see all available qualifiers, see our [documentation](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax).
[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fdanny-avila%2FLibreChat)
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=header+logged+out&ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E&source=header-repo&source_repo=danny-avila%2FLibreChat)
[Reload](https://github.com/danny-avila/LibreChat)
[Reload](https://github.com/danny-avila/LibreChat)
[Reload](https://github.com/danny-avila/LibreChat)
[danny-avila](https://github.com/danny-avila)
[LibreChat](https://github.com/danny-avila/LibreChat)
- 








              Uh oh!

              There was an error while loading. [Please reload this page](https://github.com/danny-avila/LibreChat).






- 
            [Notifications](https://github.com/login?return_to=%2Fdanny-avila%2FLibreChat)    You must be signed in to change notification settings


- 
          [Fork
    8k](https://github.com/login?return_to=%2Fdanny-avila%2FLibreChat)

- 

        [Star
          38.9k](https://github.com/login?return_to=%2Fdanny-avila%2FLibreChat)

There was an error while loading. [Please reload this page](https://github.com/danny-avila/LibreChat).
[Notifications](https://github.com/login?return_to=%2Fdanny-avila%2FLibreChat)
[Fork
    8k](https://github.com/login?return_to=%2Fdanny-avila%2FLibreChat)
[Star
          38.9k](https://github.com/login?return_to=%2Fdanny-avila%2FLibreChat)
- 
  [Code](https://github.com/danny-avila/LibreChat)
- 
  [Issues
          279](https://github.com/danny-avila/LibreChat/issues)
- 
  [Pull requests
          217](https://github.com/danny-avila/LibreChat/pulls)
- 
  [Discussions](https://github.com/danny-avila/LibreChat/discussions)
- 
  [Actions](https://github.com/danny-avila/LibreChat/actions)
- 
  [Projects](https://github.com/danny-avila/LibreChat/projects)
- 
  [Security and quality
          29](https://github.com/danny-avila/LibreChat/security)
- 
  [Insights](https://github.com/danny-avila/LibreChat/pulse)
[Code](https://github.com/danny-avila/LibreChat)
[Issues
          279](https://github.com/danny-avila/LibreChat/issues)
[Pull requests
          217](https://github.com/danny-avila/LibreChat/pulls)
[Discussions](https://github.com/danny-avila/LibreChat/discussions)
[Actions](https://github.com/danny-avila/LibreChat/actions)
[Projects](https://github.com/danny-avila/LibreChat/projects)
[Security and quality
          29](https://github.com/danny-avila/LibreChat/security)
[Insights](https://github.com/danny-avila/LibreChat/pulse)
- 


    [Code](https://github.com/danny-avila/LibreChat)


- 


    [Issues](https://github.com/danny-avila/LibreChat/issues)


- 


    [Pull requests](https://github.com/danny-avila/LibreChat/pulls)


- 


    [Discussions](https://github.com/danny-avila/LibreChat/discussions)


- 


    [Actions](https://github.com/danny-avila/LibreChat/actions)


- 


    [Projects](https://github.com/danny-avila/LibreChat/projects)


- 


    [Security and quality](https://github.com/danny-avila/LibreChat/security)


- 


    [Insights](https://github.com/danny-avila/LibreChat/pulse)


[Code](https://github.com/danny-avila/LibreChat)
[Issues](https://github.com/danny-avila/LibreChat/issues)
[Pull requests](https://github.com/danny-avila/LibreChat/pulls)
[Discussions](https://github.com/danny-avila/LibreChat/discussions)
[Actions](https://github.com/danny-avila/LibreChat/actions)
[Projects](https://github.com/danny-avila/LibreChat/projects)
[Security and quality](https://github.com/danny-avila/LibreChat/security)
[Insights](https://github.com/danny-avila/LibreChat/pulse)

[Branches](https://github.com/danny-avila/LibreChat/branches)
[Tags](https://github.com/danny-avila/LibreChat/tags)

[4,500 Commits](https://github.com/danny-avila/LibreChat/commits/main/)
[.devcontainer](https://github.com/danny-avila/LibreChat/tree/main/.devcontainer)
[.devcontainer](https://github.com/danny-avila/LibreChat/tree/main/.devcontainer)
[.do/gitnexus](https://github.com/danny-avila/LibreChat/tree/main/.do/gitnexus)
[.do/gitnexus](https://github.com/danny-avila/LibreChat/tree/main/.do/gitnexus)
[.github](https://github.com/danny-avila/LibreChat/tree/main/.github)
[.github](https://github.com/danny-avila/LibreChat/tree/main/.github)
[.husky](https://github.com/danny-avila/LibreChat/tree/main/.husky)
[.husky](https://github.com/danny-avila/LibreChat/tree/main/.husky)
[.vscode](https://github.com/danny-avila/LibreChat/tree/main/.vscode)
[.vscode](https://github.com/danny-avila/LibreChat/tree/main/.vscode)
[api](https://github.com/danny-avila/LibreChat/tree/main/api)
[api](https://github.com/danny-avila/LibreChat/tree/main/api)
[client](https://github.com/danny-avila/LibreChat/tree/main/client)
[client](https://github.com/danny-avila/LibreChat/tree/main/client)
[config](https://github.com/danny-avila/LibreChat/tree/main/config)
[config](https://github.com/danny-avila/LibreChat/tree/main/config)
[e2e](https://github.com/danny-avila/LibreChat/tree/main/e2e)
[e2e](https://github.com/danny-avila/LibreChat/tree/main/e2e)
[helm](https://github.com/danny-avila/LibreChat/tree/main/helm)
[helm](https://github.com/danny-avila/LibreChat/tree/main/helm)
[packages](https://github.com/danny-avila/LibreChat/tree/main/packages)
[packages](https://github.com/danny-avila/LibreChat/tree/main/packages)
[redis-config](https://github.com/danny-avila/LibreChat/tree/main/redis-config)
[redis-config](https://github.com/danny-avila/LibreChat/tree/main/redis-config)
[scripts](https://github.com/danny-avila/LibreChat/tree/main/scripts)
[scripts](https://github.com/danny-avila/LibreChat/tree/main/scripts)
[skill](https://github.com/danny-avila/LibreChat/tree/main/skill)
[skill](https://github.com/danny-avila/LibreChat/tree/main/skill)
[src/tests](https://github.com/danny-avila/LibreChat/tree/main/src/tests)
[src/tests](https://github.com/danny-avila/LibreChat/tree/main/src/tests)
[utils](https://github.com/danny-avila/LibreChat/tree/main/utils)
[utils](https://github.com/danny-avila/LibreChat/tree/main/utils)
[.dockerignore](https://github.com/danny-avila/LibreChat/blob/main/.dockerignore)
[.dockerignore](https://github.com/danny-avila/LibreChat/blob/main/.dockerignore)
[.env.example](https://github.com/danny-avila/LibreChat/blob/main/.env.example)
[.env.example](https://github.com/danny-avila/LibreChat/blob/main/.env.example)
[.gitattributes](https://github.com/danny-avila/LibreChat/blob/main/.gitattributes)
[.gitattributes](https://github.com/danny-avila/LibreChat/blob/main/.gitattributes)
[.gitignore](https://github.com/danny-avila/LibreChat/blob/main/.gitignore)
[.gitignore](https://github.com/danny-avila/LibreChat/blob/main/.gitignore)
[.nvmrc](https://github.com/danny-avila/LibreChat/blob/main/.nvmrc)
[.nvmrc](https://github.com/danny-avila/LibreChat/blob/main/.nvmrc)
[.prettierrc](https://github.com/danny-avila/LibreChat/blob/main/.prettierrc)
[.prettierrc](https://github.com/danny-avila/LibreChat/blob/main/.prettierrc)
[AGENTS.md](https://github.com/danny-avila/LibreChat/blob/main/AGENTS.md)
[AGENTS.md](https://github.com/danny-avila/LibreChat/blob/main/AGENTS.md)
[CLAUDE.md](https://github.com/danny-avila/LibreChat/blob/main/CLAUDE.md)
[CLAUDE.md](https://github.com/danny-avila/LibreChat/blob/main/CLAUDE.md)
[Dockerfile](https://github.com/danny-avila/LibreChat/blob/main/Dockerfile)
[Dockerfile](https://github.com/danny-avila/LibreChat/blob/main/Dockerfile)
[Dockerfile.multi](https://github.com/danny-avila/LibreChat/blob/main/Dockerfile.multi)
[Dockerfile.multi](https://github.com/danny-avila/LibreChat/blob/main/Dockerfile.multi)
[LICENSE](https://github.com/danny-avila/LibreChat/blob/main/LICENSE)
[LICENSE](https://github.com/danny-avila/LibreChat/blob/main/LICENSE)
[README.md](https://github.com/danny-avila/LibreChat/blob/main/README.md)
[README.md](https://github.com/danny-avila/LibreChat/blob/main/README.md)
[README.zh.md](https://github.com/danny-avila/LibreChat/blob/main/README.zh.md)
[README.zh.md](https://github.com/danny-avila/LibreChat/blob/main/README.zh.md)
[bun.lock](https://github.com/danny-avila/LibreChat/blob/main/bun.lock)
[bun.lock](https://github.com/danny-avila/LibreChat/blob/main/bun.lock)

## History
[deploy-compose.yml](https://github.com/danny-avila/LibreChat/blob/main/deploy-compose.yml)
[deploy-compose.yml](https://github.com/danny-avila/LibreChat/blob/main/deploy-compose.yml)
[docker-compose.override.yml.example](https://github.com/danny-avila/LibreChat/blob/main/docker-compose.override.yml.example)
[docker-compose.override.yml.example](https://github.com/danny-avila/LibreChat/blob/main/docker-compose.override.yml.example)
[docker-compose.yml](https://github.com/danny-avila/LibreChat/blob/main/docker-compose.yml)
[docker-compose.yml](https://github.com/danny-avila/LibreChat/blob/main/docker-compose.yml)
[eslint.config.mjs](https://github.com/danny-avila/LibreChat/blob/main/eslint.config.mjs)
[eslint.config.mjs](https://github.com/danny-avila/LibreChat/blob/main/eslint.config.mjs)
[librechat.example.yaml](https://github.com/danny-avila/LibreChat/blob/main/librechat.example.yaml)
[librechat.example.yaml](https://github.com/danny-avila/LibreChat/blob/main/librechat.example.yaml)
[package-lock.json](https://github.com/danny-avila/LibreChat/blob/main/package-lock.json)
[package-lock.json](https://github.com/danny-avila/LibreChat/blob/main/package-lock.json)
[package.json](https://github.com/danny-avila/LibreChat/blob/main/package.json)
[package.json](https://github.com/danny-avila/LibreChat/blob/main/package.json)
[rag.yml](https://github.com/danny-avila/LibreChat/blob/main/rag.yml)
[rag.yml](https://github.com/danny-avila/LibreChat/blob/main/rag.yml)
[turbo.json](https://github.com/danny-avila/LibreChat/blob/main/turbo.json)
[turbo.json](https://github.com/danny-avila/LibreChat/blob/main/turbo.json)

## Repository files navigation
- [README](https://github.com/danny-avila/LibreChat)
- [Code of conduct](https://github.com/danny-avila/LibreChat)
- [Contributing](https://github.com/danny-avila/LibreChat)
- [MIT license](https://github.com/danny-avila/LibreChat)
- [Security](https://github.com/danny-avila/LibreChat)
[README](https://github.com/danny-avila/LibreChat)
[Code of conduct](https://github.com/danny-avila/LibreChat)
[Contributing](https://github.com/danny-avila/LibreChat)
[MIT license](https://github.com/danny-avila/LibreChat)
[Security](https://github.com/danny-avila/LibreChat)

[LibreChat](https://librechat.ai)
English · [中文](https://github.com/danny-avila/LibreChat/blob/main/README.zh.md)

- 
🖥️ UI & Experience inspired by ChatGPT with enhanced design and features

- 
🤖 AI Model Selection:

Anthropic (Claude), AWS Bedrock, OpenAI, Azure OpenAI, Google, Vertex AI, OpenAI Responses API (incl. Azure)
[Custom Endpoints](https://www.librechat.ai/docs/quick_start/custom_endpoints): Use any OpenAI-compatible API with LibreChat, no proxy required
Compatible with [Local & Remote AI Providers](https://www.librechat.ai/docs/configuration/librechat_yaml/ai_endpoints):

Ollama, groq, Cohere, Mistral AI, Apple MLX, koboldcpp, together.ai,
OpenRouter, Helicone, Perplexity, ShuttleAI, Deepseek, Qwen, and more




- Anthropic (Claude), AWS Bedrock, OpenAI, Azure OpenAI, Google, Vertex AI, OpenAI Responses API (incl. Azure)
- [Custom Endpoints](https://www.librechat.ai/docs/quick_start/custom_endpoints): Use any OpenAI-compatible API with LibreChat, no proxy required
- Compatible with [Local & Remote AI Providers](https://www.librechat.ai/docs/configuration/librechat_yaml/ai_endpoints):

Ollama, groq, Cohere, Mistral AI, Apple MLX, koboldcpp, together.ai,
OpenRouter, Helicone, Perplexity, ShuttleAI, Deepseek, Qwen, and more


- Ollama, groq, Cohere, Mistral AI, Apple MLX, koboldcpp, together.ai,
- OpenRouter, Helicone, Perplexity, ShuttleAI, Deepseek, Qwen, and more
- 
🔧 [Code Interpreter API](https://www.librechat.ai/docs/features/code_interpreter):

Secure, Sandboxed Execution in Python, Node.js (JS/TS), Go, C/C++, Java, PHP, Rust, and Fortran
Seamless File Handling: Upload, process, and download files directly
No Privacy Concerns: Fully isolated and secure execution


- Secure, Sandboxed Execution in Python, Node.js (JS/TS), Go, C/C++, Java, PHP, Rust, and Fortran
- Seamless File Handling: Upload, process, and download files directly
- No Privacy Concerns: Fully isolated and secure execution
- 
🔦 Agents & Tools Integration:

[LibreChat Agents](https://www.librechat.ai/docs/features/agents):

No-Code Custom Assistants: Build specialized, AI-driven helpers
Agent Marketplace: Discover and deploy community-built agents
Collaborative Sharing: Share agents with specific users and groups
Flexible & Extensible: Use MCP Servers, tools, file search, code execution, and more
[Skills](https://www.librechat.ai/docs/features/skills): Create reusable SKILL.md instruction bundles for manual, automatic, or always-on agent workflows
[Subagents](https://www.librechat.ai/docs/features/subagents): Delegate focused work to isolated child agent runs with their own context windows
Compatible with Custom Endpoints, OpenAI, Azure, Anthropic, AWS Bedrock, Google, Vertex AI, Responses API, and more
[Model Context Protocol (MCP) Support](https://modelcontextprotocol.io/clients#librechat) for Tools




- [LibreChat Agents](https://www.librechat.ai/docs/features/agents):

No-Code Custom Assistants: Build specialized, AI-driven helpers
Agent Marketplace: Discover and deploy community-built agents
Collaborative Sharing: Share agents with specific users and groups
Flexible & Extensible: Use MCP Servers, tools, file search, code execution, and more
[Skills](https://www.librechat.ai/docs/features/skills): Create reusable SKILL.md instruction bundles for manual, automatic, or always-on agent workflows
[Subagents](https://www.librechat.ai/docs/features/subagents): Delegate focused work to isolated child agent runs with their own context windows
Compatible with Custom Endpoints, OpenAI, Azure, Anthropic, AWS Bedrock, Google, Vertex AI, Responses API, and more
[Model Context Protocol (MCP) Support](https://modelcontextprotocol.io/clients#librechat) for Tools


- No-Code Custom Assistants: Build specialized, AI-driven helpers
- Agent Marketplace: Discover and deploy community-built agents
- Collaborative Sharing: Share agents with specific users and groups
- Flexible & Extensible: Use MCP Servers, tools, file search, code execution, and more
- [Skills](https://www.librechat.ai/docs/features/skills): Create reusable SKILL.md instruction bundles for manual, automatic, or always-on agent workflows
- [Subagents](https://www.librechat.ai/docs/features/subagents): Delegate focused work to isolated child agent runs with their own context windows
- Compatible with Custom Endpoints, OpenAI, Azure, Anthropic, AWS Bedrock, Google, Vertex AI, Responses API, and more
- [Model Context Protocol (MCP) Support](https://modelcontextprotocol.io/clients#librechat) for Tools
- 
🔍 Web Search:

Search the internet and retrieve relevant information to enhance your AI context
Combines search providers, content scrapers, and result rerankers for optimal results
Customizable Jina Reranking: Configure custom Jina API URLs for reranking services
[Learn More →](https://www.librechat.ai/docs/features/web_search)


- Search the internet and retrieve relevant information to enhance your AI context
- Combines search providers, content scrapers, and result rerankers for optimal results
- Customizable Jina Reranking: Configure custom Jina API URLs for reranking services
- [Learn More →](https://www.librechat.ai/docs/features/web_search)
- 
🪄 Generative UI with [Code Artifacts](https://youtu.be/GfTj7O4gmd0?si=WJbdnemZpJzBrJo3):

Code Artifacts allow creation of React, HTML, and Mermaid diagrams directly in chat


- [Code Artifacts](https://youtu.be/GfTj7O4gmd0?si=WJbdnemZpJzBrJo3) allow creation of React, HTML, and Mermaid diagrams directly in chat
- 
🎨 Image Generation & Editing

Text-to-image and image-to-image with [GPT-Image-1](https://www.librechat.ai/docs/features/image_gen#1--openai-image-tools-recommended)
Text-to-image with [DALL-E (3/2)](https://www.librechat.ai/docs/features/image_gen#2--dalle-legacy), [Stable Diffusion](https://www.librechat.ai/docs/features/image_gen#3--stable-diffusion-local), [Flux](https://www.librechat.ai/docs/features/image_gen#4--flux), or any [MCP server](https://www.librechat.ai/docs/features/image_gen#5--model-context-protocol-mcp)
Produce stunning visuals from prompts or refine existing images with a single instruction


- Text-to-image and image-to-image with [GPT-Image-1](https://www.librechat.ai/docs/features/image_gen#1--openai-image-tools-recommended)
- Text-to-image with [DALL-E (3/2)](https://www.librechat.ai/docs/features/image_gen#2--dalle-legacy), [Stable Diffusion](https://www.librechat.ai/docs/features/image_gen#3--stable-diffusion-local), [Flux](https://www.librechat.ai/docs/features/image_gen#4--flux), or any [MCP server](https://www.librechat.ai/docs/features/image_gen#5--model-context-protocol-mcp)
- Produce stunning visuals from prompts or refine existing images with a single instruction
- 
💾 Presets & Context Management:

Create, Save, & Share Custom Presets
Switch between AI Endpoints and Presets mid-chat
Edit, Resubmit, and Continue Messages with Conversation branching
Create and share prompts with specific users and groups
[Fork Messages & Conversations](https://www.librechat.ai/docs/features/fork) for Advanced Context control


- Create, Save, & Share Custom Presets
- Switch between AI Endpoints and Presets mid-chat
- Edit, Resubmit, and Continue Messages with Conversation branching
- Create and share prompts with specific users and groups
- [Fork Messages & Conversations](https://www.librechat.ai/docs/features/fork) for Advanced Context control
- 
💬 Multimodal & File Interactions:

Upload and analyze images with Claude 3, GPT-4.5, GPT-4o, o1, Llama-Vision, and Gemini 📸
Chat with Files using Custom Endpoints, OpenAI, Azure, Anthropic, AWS Bedrock, & Google 🗃️


- Upload and analyze images with Claude 3, GPT-4.5, GPT-4o, o1, Llama-Vision, and Gemini 📸
- Chat with Files using Custom Endpoints, OpenAI, Azure, Anthropic, AWS Bedrock, & Google 🗃️
- 
🌎 Multilingual UI:

English, 中文 (简体), 中文 (繁體), العربية, Deutsch, Español, Français, Italiano
Polski, Português (PT), Português (BR), Русский, 日本語, Svenska, 한국어, Tiếng Việt
Türkçe, Nederlands, עברית, Català, Čeština, Dansk, Eesti, فارسی
Suomi, Magyar, Հայերեն, Bahasa Indonesia, ქართული, Latviešu, ไทย, ئۇيغۇرچە


- English, 中文 (简体), 中文 (繁體), العربية, Deutsch, Español, Français, Italiano
- Polski, Português (PT), Português (BR), Русский, 日本語, Svenska, 한국어, Tiếng Việt
- Türkçe, Nederlands, עברית, Català, Čeština, Dansk, Eesti, فارسی
- Suomi, Magyar, Հայերեն, Bahasa Indonesia, ქართული, Latviešu, ไทย, ئۇيغۇرچە
- 
🧠 Reasoning UI:

Dynamic Reasoning UI for Chain-of-Thought/Reasoning AI models like DeepSeek-R1


- Dynamic Reasoning UI for Chain-of-Thought/Reasoning AI models like DeepSeek-R1
- 
🎨 Customizable Interface:

Customizable Dropdown & Interface that adapts to both power users and newcomers


- Customizable Dropdown & Interface that adapts to both power users and newcomers
-

🌊 [Resumable Streams](https://www.librechat.ai/docs/features/resumable_streams):

Never lose a response: AI responses automatically reconnect and resume if your connection drops
Multi-Tab & Multi-Device Sync: Open the same chat in multiple tabs or pick up on another device
Production-Ready: Works from single-server setups to horizontally scaled deployments with Redis


- Never lose a response: AI responses automatically reconnect and resume if your connection drops
- Multi-Tab & Multi-Device Sync: Open the same chat in multiple tabs or pick up on another device
- Production-Ready: Works from single-server setups to horizontally scaled deployments with Redis
- 
🗣️ Speech & Audio:

Chat hands-free with Speech-to-Text and Text-to-Speech
Automatically send and play Audio
Supports OpenAI, Azure OpenAI, and Elevenlabs


- Chat hands-free with Speech-to-Text and Text-to-Speech
- Automatically send and play Audio
- Supports OpenAI, Azure OpenAI, and Elevenlabs
- 
📥 Import & Export Conversations:

Import Conversations from LibreChat, ChatGPT, Chatbot UI
Export conversations as screenshots, markdown, text, json


- Import Conversations from LibreChat, ChatGPT, Chatbot UI
- Export conversations as screenshots, markdown, text, json
- 
🔍 Search & Discovery:

Search all messages/conversations


- Search all messages/conversations
- 
👥 Multi-User & Secure Access:

Multi-User, Secure Authentication with OAuth2, LDAP, & Email Login Support
Built-in Moderation, and Token spend tools


- Multi-User, Secure Authentication with OAuth2, LDAP, & Email Login Support
- Built-in Moderation, and Token spend tools
- 
⚙️ Configuration & Deployment:

Configure Proxy, Reverse Proxy, Docker, & many Deployment options
Use [S3 with CloudFront](https://www.librechat.ai/docs/configuration/cdn/cloudfront) for stable media links, edge delivery, signed cookies, and secured downloads
Use completely local or deploy on the cloud


- Configure Proxy, Reverse Proxy, Docker, & many Deployment options
- Use [S3 with CloudFront](https://www.librechat.ai/docs/configuration/cdn/cloudfront) for stable media links, edge delivery, signed cookies, and secured downloads
- Use completely local or deploy on the cloud
- 
📖 Open-Source & Community:

Completely Open-Source & Built in Public
Community-driven development, support, and feedback


- Completely Open-Source & Built in Public
- Community-driven development, support, and feedback
🖥️ UI & Experience inspired by ChatGPT with enhanced design and features
🤖 AI Model Selection:
- Anthropic (Claude), AWS Bedrock, OpenAI, Azure OpenAI, Google, Vertex AI, OpenAI Responses API (incl. Azure)
- [Custom Endpoints](https://www.librechat.ai/docs/quick_start/custom_endpoints): Use any OpenAI-compatible API with LibreChat, no proxy required
- Compatible with [Local & Remote AI Providers](https://www.librechat.ai/docs/configuration/librechat_yaml/ai_endpoints):

Ollama, groq, Cohere, Mistral AI, Apple MLX, koboldcpp, together.ai,
OpenRouter, Helicone, Perplexity, ShuttleAI, Deepseek, Qwen, and more


- Ollama, groq, Cohere, Mistral AI, Apple MLX, koboldcpp, together.ai,
- OpenRouter, Helicone, Perplexity, ShuttleAI, Deepseek, Qwen, and more
[Custom Endpoints](https://www.librechat.ai/docs/quick_start/custom_endpoints)
[Local & Remote AI Providers](https://www.librechat.ai/docs/configuration/librechat_yaml/ai_endpoints)
- Ollama, groq, Cohere, Mistral AI, Apple MLX, koboldcpp, together.ai,
- OpenRouter, Helicone, Perplexity, ShuttleAI, Deepseek, Qwen, and more
🔧 [Code Interpreter API](https://www.librechat.ai/docs/features/code_interpreter):
- Secure, Sandboxed Execution in Python, Node.js (JS/TS), Go, C/C++, Java, PHP, Rust, and Fortran
- Seamless File Handling: Upload, process, and download files directly
- No Privacy Concerns: Fully isolated and secure execution
🔦 Agents & Tools Integration:
- [LibreChat Agents](https://www.librechat.ai/docs/features/agents):

No-Code Custom Assistants: Build specialized, AI-driven helpers
Agent Marketplace: Discover and deploy community-built agents
Collaborative Sharing: Share agents with specific users and groups
Flexible & Extensible: Use MCP Servers, tools, file search, code execution, and more
[Skills](https://www.librechat.ai/docs/features/skills): Create reusable SKILL.md instruction bundles for manual, automatic, or always-on agent workflows

[Subagents](https://www.librechat.ai/docs/features/subagents): Delegate focused work to isolated child agent runs with their own context windows
Compatible with Custom Endpoints, OpenAI, Azure, Anthropic, AWS Bedrock, Google, Vertex AI, Responses API, and more
[Model Context Protocol (MCP) Support](https://modelcontextprotocol.io/clients#librechat) for Tools


- No-Code Custom Assistants: Build specialized, AI-driven helpers
- Agent Marketplace: Discover and deploy community-built agents
- Collaborative Sharing: Share agents with specific users and groups
- Flexible & Extensible: Use MCP Servers, tools, file search, code execution, and more
- [Skills](https://www.librechat.ai/docs/features/skills): Create reusable SKILL.md instruction bundles for manual, automatic, or always-on agent workflows
- [Subagents](https://www.librechat.ai/docs/features/subagents): Delegate focused work to isolated child agent runs with their own context windows
- Compatible with Custom Endpoints, OpenAI, Azure, Anthropic, AWS Bedrock, Google, Vertex AI, Responses API, and more
- [Model Context Protocol (MCP) Support](https://modelcontextprotocol.io/clients#librechat) for Tools
[LibreChat Agents](https://www.librechat.ai/docs/features/agents)
- No-Code Custom Assistants: Build specialized, AI-driven helpers
- Agent Marketplace: Discover and deploy community-built agents
- Collaborative Sharing: Share agents with specific users and groups
- Flexible & Extensible: Use MCP Servers, tools, file search, code execution, and more
- [Skills](https://www.librechat.ai/docs/features/skills): Create reusable SKILL.md instruction bundles for manual, automatic, or always-on agent workflows
- [Subagents](https://www.librechat.ai/docs/features/subagents): Delegate focused work to isolated child agent runs with their own context windows
- Compatible with Custom Endpoints, OpenAI, Azure, Anthropic, AWS Bedrock, Google, Vertex AI, Responses API, and more
- [Model Context Protocol (MCP) Support](https://modelcontextprotocol.io/clients#librechat) for Tools
[Skills](https://www.librechat.ai/docs/features/skills)

```
SKILL.md
```

[Subagents](https://www.librechat.ai/docs/features/subagents)
[Model Context Protocol (MCP) Support](https://modelcontextprotocol.io/clients#librechat)
🔍 Web Search:
- Search the internet and retrieve relevant information to enhance your AI context
- Combines search providers, content scrapers, and result rerankers for optimal results
- Customizable Jina Reranking: Configure custom Jina API URLs for reranking services
- [Learn More →](https://www.librechat.ai/docs/features/web_search)
[Learn More →](https://www.librechat.ai/docs/features/web_search)
🪄 Generative UI with Code Artifacts:
- [Code Artifacts](https://youtu.be/GfTj7O4gmd0?si=WJbdnemZpJzBrJo3) allow creation of React, HTML, and Mermaid diagrams directly in chat
[Code Artifacts](https://youtu.be/GfTj7O4gmd0?si=WJbdnemZpJzBrJo3)
🎨 Image Generation & Editing
- Text-to-image and image-to-image with [GPT-Image-1](https://www.librechat.ai/docs/features/image_gen#1--openai-image-tools-recommended)
- Text-to-image with [DALL-E (3/2)](https://www.librechat.ai/docs/features/image_gen#2--dalle-legacy), [Stable Diffusion](https://www.librechat.ai/docs/features/image_gen#3--stable-diffusion-local), [Flux](https://www.librechat.ai/docs/features/image_gen#4--flux), or any [MCP server](https://www.librechat.ai/docs/features/image_gen#5--model-context-protocol-mcp)
- Produce stunning visuals from prompts or refine existing images with a single instruction
[GPT-Image-1](https://www.librechat.ai/docs/features/image_gen#1--openai-image-tools-recommended)
[DALL-E (3/2)](https://www.librechat.ai/docs/features/image_gen#2--dalle-legacy)
[Stable Diffusion](https://www.librechat.ai/docs/features/image_gen#3--stable-diffusion-local)
[Flux](https://www.librechat.ai/docs/features/image_gen#4--flux)
[MCP server](https://www.librechat.ai/docs/features/image_gen#5--model-context-protocol-mcp)
💾 Presets & Context Management:
- Create, Save, & Share Custom Presets
- Switch between AI Endpoints and Presets mid-chat
- Edit, Resubmit, and Continue Messages with Conversation branching
- Create and share prompts with specific users and groups
- [Fork Messages & Conversations](https://www.librechat.ai/docs/features/fork) for Advanced Context control
[Fork Messages & Conversations](https://www.librechat.ai/docs/features/fork)
💬 Multimodal & File Interactions:

- Upload and analyze images with Claude 3, GPT-4.5, GPT-4o, o1, Llama-Vision, and Gemini 📸
- Chat with Files using Custom Endpoints, OpenAI, Azure, Anthropic, AWS Bedrock, & Google 🗃️
🌎 Multilingual UI:
- English, 中文 (简体), 中文 (繁體), العربية, Deutsch, Español, Français, Italiano
- Polski, Português (PT), Português (BR), Русский, 日本語, Svenska, 한국어, Tiếng Việt
- Türkçe, Nederlands, עברית, Català, Čeština, Dansk, Eesti, فارسی
- Suomi, Magyar, Հայերեն, Bahasa Indonesia, ქართული, Latviešu, ไทย, ئۇيغۇرچە
🧠 Reasoning UI:
- Dynamic Reasoning UI for Chain-of-Thought/Reasoning AI models like DeepSeek-R1
🎨 Customizable Interface:
- Customizable Dropdown & Interface that adapts to both power users and newcomers
🌊 [Resumable Streams](https://www.librechat.ai/docs/features/resumable_streams):
- Never lose a response: AI responses automatically reconnect and resume if your connection drops
- Multi-Tab & Multi-Device Sync: Open the same chat in multiple tabs or pick up on another device
- Production-Ready: Works from single-server setups to horizontally scaled deployments with Redis
🗣️ Speech & Audio:
- Chat hands-free with Speech-to-Text and Text-to-Speech
- Automatically send and play Audio
- Supports OpenAI, Azure OpenAI, and Elevenlabs
📥 Import & Export Conversations:
- Import Conversations from LibreChat, ChatGPT, Chatbot UI
- Export conversations as screenshots, markdown, text, json
🔍 Search & Discovery:
- Search all messages/conversations
👥 Multi-User & Secure Access:
- Multi-User, Secure Authentication with OAuth2, LDAP, & Email Login Support
- Built-in Moderation, and Token spend tools
⚙️ Configuration & Deployment:
- Configure Proxy, Reverse Proxy, Docker, & many Deployment options
- Use [S3 with CloudFront](https://www.librechat.ai/docs/configuration/cdn/cloudfront) for stable media links, edge delivery, signed cookies, and secured downloads
- Use completely local or deploy on the cloud
[S3 with CloudFront](https://www.librechat.ai/docs/configuration/cdn/cloudfront)
📖 Open-Source & Community:
- Completely Open-Source & Built in Public
- Community-driven development, support, and feedback
[For a thorough review of our features, see our docs here](https://docs.librechat.ai/) 📚

## 🪶 All-In-One AI Conversations with LibreChat
LibreChat is a self-hosted AI chat platform that unifies all major AI providers in a single, privacy-focused interface.
Beyond chat, LibreChat provides AI Agents, Model Context Protocol (MCP) support, Artifacts, Code Interpreter, custom actions, conversation search, and enterprise-ready multi-user authentication.
Open source, actively developed, and built for anyone who values control over their AI infrastructure.

## 🌐 Resources
GitHub Repo:
- RAG API: [github.com/danny-avila/rag_api](https://github.com/danny-avila/rag_api)
- Website: [github.com/LibreChat-AI/librechat.ai](https://github.com/LibreChat-AI/librechat.ai)
[github.com/danny-avila/rag_api](https://github.com/danny-avila/rag_api)
[github.com/LibreChat-AI/librechat.ai](https://github.com/LibreChat-AI/librechat.ai)
Other:
- Website: [librechat.ai](https://librechat.ai)
- Documentation: [librechat.ai/docs](https://librechat.ai/docs)
- Blog: [librechat.ai/blog](https://librechat.ai/blog)
[librechat.ai](https://librechat.ai)
[librechat.ai/docs](https://librechat.ai/docs)
[librechat.ai/blog](https://librechat.ai/blog)

## 📝 Changelog
Keep up with the latest updates by visiting the releases page and notes:
- [Releases](https://github.com/danny-avila/LibreChat/releases)
- [Changelog](https://www.librechat.ai/changelog)
[Releases](https://github.com/danny-avila/LibreChat/releases)
[Changelog](https://www.librechat.ai/changelog)
⚠️ Please consult the [changelog](https://www.librechat.ai/changelog) for breaking changes before updating.

## ✨ Contributions
Contributions, suggestions, bug reports and fixes are welcome!
For new features, components, or extensions, please open an issue and discuss before sending a PR.
If you'd like to help translate LibreChat into your language, we'd love your contribution! Improving our translations not only makes LibreChat more accessible to users around the world but also enhances the overall user experience. Please check out our [Translation Guide](https://www.librechat.ai/docs/translation).

## 🎉 Special Thanks
We thank [Locize](https://locize.com) for their translation management tools that support multiple languages in LibreChat.

## About
Enhanced ChatGPT Clone: Features Agents, MCP, Skills, DeepSeek, Anthropic, AWS, OpenAI, Responses API, Azure, Groq, o1, GPT-5, Mistral, OpenRouter, Vertex AI, Gemini, Artifacts, AI model switching, message search, Code Interpreter, langchain, DALL-E-3, OpenAPI Actions, Functions, Secure Multi-User Auth, Presets, open-source for self-hosting. Active
[librechat.ai/](https://librechat.ai/)

### Topics
[aws](https://github.com/topics/aws)
[google](https://github.com/topics/google)
[ai](https://github.com/topics/ai)
[clone](https://github.com/topics/clone)
[azure](https://github.com/topics/azure)
[mcp](https://github.com/topics/mcp)
[gemini](https://github.com/topics/gemini)
[vision](https://github.com/topics/vision)
[openai](https://github.com/topics/openai)
[artifacts](https://github.com/topics/artifacts)
[webui](https://github.com/topics/webui)
[claude](https://github.com/topics/claude)
[o1](https://github.com/topics/o1)
[chatgpt](https://github.com/topics/chatgpt)
[chatgpt-clone](https://github.com/topics/chatgpt-clone)
[gpt-5](https://github.com/topics/gpt-5)
[anthropic](https://github.com/topics/anthropic)
[librechat](https://github.com/topics/librechat)
[deepseek](https://github.com/topics/deepseek)
[responses-api](https://github.com/topics/responses-api)

### Resources
[Readme](https://github.com/danny-avila/LibreChat#readme-ov-file)

### License
[MIT license](https://github.com/danny-avila/LibreChat#MIT-1-ov-file)

### Code of conduct
[Code of conduct](https://github.com/danny-avila/LibreChat#coc-ov-file)

### Contributing
[Contributing](https://github.com/danny-avila/LibreChat#contributing-ov-file)

### Security policy
[Security policy](https://github.com/danny-avila/LibreChat#security-ov-file)

### Uh oh!
There was an error while loading. [Please reload this page](https://github.com/danny-avila/LibreChat).
[Activity](https://github.com/danny-avila/LibreChat/activity)

### Stars
[38.9k
        stars](https://github.com/danny-avila/LibreChat/stargazers)

### Watchers
[195
        watching](https://github.com/danny-avila/LibreChat/watchers)

### Forks
[8k
        forks](https://github.com/danny-avila/LibreChat/forks)
[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fdanny-avila%2FLibreChat&report=danny-avila+%28user%29)

[Releases](https://github.com/danny-avila/LibreChat/releases)
[93
      tags](https://github.com/danny-avila/LibreChat/tags)

There was an error while loading. [Please reload this page](https://github.com/danny-avila/LibreChat).
[Learn more about GitHub Sponsors](https://github.com/sponsors)

[Packages
      0](https://github.com/users/danny-avila/packages?repo_name=LibreChat)

### Uh oh!
There was an error while loading. [Please reload this page](https://github.com/danny-avila/LibreChat).

### Uh oh!
There was an error while loading. [Please reload this page](https://github.com/danny-avila/LibreChat).

[Contributors](https://github.com/danny-avila/LibreChat/graphs/contributors)

There was an error while loading. [Please reload this page](https://github.com/danny-avila/LibreChat).

- 
        [TypeScript
          77.2%](https://github.com/danny-avila/LibreChat/search?l=typescript)

- 
        [JavaScript
          22.0%](https://github.com/danny-avila/LibreChat/search?l=javascript)

- 
        [CSS
          0.4%](https://github.com/danny-avila/LibreChat/search?l=css)

- 
        [Handlebars
          0.3%](https://github.com/danny-avila/LibreChat/search?l=handlebars)

- 
        [Shell
          0.1%](https://github.com/danny-avila/LibreChat/search?l=shell)

- 
        [Dockerfile
          0.0%](https://github.com/danny-avila/LibreChat/search?l=dockerfile)

[TypeScript
          77.2%](https://github.com/danny-avila/LibreChat/search?l=typescript)
[JavaScript
          22.0%](https://github.com/danny-avila/LibreChat/search?l=javascript)
[CSS
          0.4%](https://github.com/danny-avila/LibreChat/search?l=css)
[Handlebars
          0.3%](https://github.com/danny-avila/LibreChat/search?l=handlebars)
[Shell
          0.1%](https://github.com/danny-avila/LibreChat/search?l=shell)
[Dockerfile
          0.0%](https://github.com/danny-avila/LibreChat/search?l=dockerfile)

- 
            [Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)

- 
            [Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)

- 
            [Security](https://github.com/security)

- 
            [Status](https://www.githubstatus.com/)

- 
            [Community](https://github.community/)

- 
            [Docs](https://docs.github.com/)

- 
            [Contact](https://support.github.com?tags=dotcom-footer)

- 


       Manage cookies



- 


      Do not share my personal information



[Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)
[Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)
[Security](https://github.com/security)
[Status](https://www.githubstatus.com/)
[Community](https://github.community/)
[Docs](https://docs.github.com/)
[Contact](https://support.github.com?tags=dotcom-footer)

