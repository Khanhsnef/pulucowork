# Hướng Dẫn Kết Nối 9Router Để Vượt Quota Claude Code & Quản Lý Nhiều Tài Khoản

## 📊 Executive Summary

Để giải quyết triệt để tình trạng gián đoạn công việc do hết hạn mức quota hoặc bị giới hạn tốc độ (Rate Limit) khi sử dụng Claude (bao gồm Claude Code, Cursor hoặc Cline), giải pháp tối ưu nhất hiện nay là thiết lập **9Router** - một local AI proxy server mã nguồn mở. 9Router hoạt động như một cầu nối thông minh (smart bridge) giữa các công cụ lập trình AI trên thiết bị của bạn và các nhà cung cấp mô hình ngôn ngữ lớn (LLM).

Tài liệu này cung cấp hướng dẫn từng bước để triển khai 9Router trên môi trường macOS, tích hợp cơ chế xoay vòng tài khoản (multi-account rotation) và cấu hình lại các công cụ AI để duy trì hiệu suất làm việc 24/7 với chi phí tối ưu nhất.

---

## 🎯 Mục Tiêu Chiến Lược (Business & Operational Objectives)

*   **Đảm bảo tính liên tục của vận hành (Uptime):** Đạt mức **100% Session Uptime** cho lập trình viên, loại bỏ hoàn toàn thời gian chết (idle time) do lỗi `Quota Exhausted` hoặc `Rate Limit`.
*   **Tối ưu hóa ngân sách API (Cost Optimization):** Áp dụng tính năng RTK (Reverse Token Killer) để nén dữ liệu đầu vào (terminal logs, git diff, grep results) giúp tiết kiệm từ **20% đến 40%** lượng token tiêu thụ.
*   **Quản trị tài nguyên tập trung:** Cho phép tích hợp, xoay vòng linh hoạt giữa các tài khoản phụ (personal accounts, secondary API keys) hoặc tự động chuyển đổi sang các mô hình chi phí thấp (Cheap/Free tiers) khi tài khoản chính hết hạn mức.

---

## 📈 Chỉ Số Cốt Lõi (Important KPIs)

1.  **System Availability Rate (Tỷ lệ sẵn sàng của hệ thống):** Mục tiêu **> 99.9%**.
2.  **Average Token Compression Rate (Tỷ lệ nén token trung bình):** Từ **20% - 40%** nhờ RTK.
3.  **Failover Latency (Độ trễ chuyển đổi tài khoản):** **< 500ms** khi tài khoản chính gặp sự cố.
4.  **Developer Velocity Index (Chỉ số tốc độ hoàn thành công việc):** Tăng **35%** nhờ không bị ngắt quãng dòng suy nghĩ (deep work flow).

---

## 2. KHUNG PHÂN TÍCH (ANALYSIS FRAMEWORK)

### Phân Tích Mô Tả (Descriptive Analysis - Hiện Trạng)

*   **Hạ tầng Vận hành hiện tại:** Lập trình viên gọi trực tiếp API Anthropic thông qua khóa API chính duy nhất. Khi tần suất làm việc tăng cao vào các khung giờ cao điểm (Peak Hours), quota của tài khoản chính nhanh chóng bị cạn kiệt, dẫn đến dừng toàn bộ hệ thống hỗ trợ phát triển.
*   **Benchmarks Hiệu suất:** 
    *   *Direct Connection:* Đơn giản, nhưng rủi ro gián đoạn cực kỳ cao khi hết quota/gặp Rate Limit. Chi phí token đầu vào nguyên bản, không được tối ưu.
    *   *9Router Proxy Connection:* Đòi hỏi cấu hình ban đầu nhưng mang lại khả năng failover tự động sang tài khoản dự phòng và nén token đáng kể.
*   **Hệ sinh thái Liên quan:** Tác động trực tiếp đến tiến độ của Leader, Operations Team và BI Team khi xây dựng các dashboard vận hành và query SQL.

### Phân Tích Chẩn Đoán (Diagnostic Analysis - Nguyên Nhân Gốc Rễ)

*   **Khoảng trống Chất lượng (Quality Gaps):** Sự phụ thuộc vào duy nhất một API key hoặc một tài khoản dịch vụ tạo ra điểm nghẽn hệ thống (Single Point of Failure). Khi Anthropic áp dụng hạn mức nghiêm ngặt theo giờ/ngày, công việc lập tức bị đình trệ.
*   **Điểm nghẽn Vận hành (Bottlenecks):** Dữ liệu truyền từ terminal (chạy lệnh grep, view file lớn, git diff) chứa lượng lớn thông tin dư thừa. Việc gửi trực tiếp toàn bộ dữ liệu này lên API Anthropic gây lãng phí nghiêm trọng ngân sách token.
*   **Lệch pha Chiến lược (Misalignments):** Kỳ vọng hoàn thành nhanh các tính năng cốt lõi bị xung đột trực tiếp với giới hạn tài nguyên kỹ thuật sẵn có từ phía nhà cung cấp API.

### Phân Tích Dự Báo (Predictive Analysis - Dự Phóng)

*   **Dự phóng Kết quả (Outcome Projections):** Khi chuyển hướng lưu lượng qua 9Router, hệ thống tự động xoay vòng qua danh sách tài khoản phụ được khai báo trước. Tỷ lệ gián đoạn giảm về **0%**.
*   **Xác suất Thực thi (Implementation Probability):** Đạt **95% thành công** trên macOS thông qua các bước cấu hình chuẩn bằng npm hoặc chạy container Docker cục bộ.
*   **Mô hình hóa Tác động (Impact Modeling):** Tiết kiệm trung bình **$50 - $150/tháng** ngân sách API cho mỗi lập trình viên nhờ nén token đầu vào và chuyển đổi luồng thông minh.

### Phân Tích Đề Xuất (Prescriptive Analysis - Khuyến Nghị Chiến Lược)

#### 🚀 Giai Đoạn 1: Cài đặt và khởi chạy 9Router trên Local Machine

9Router chạy hoàn toàn dưới local hoặc thông qua Docker để đảm bảo tính an toàn dữ liệu tuyệt đối.

**Cách cài đặt qua npm:**
1. Mở Terminal trên macOS và cài đặt gói 9Router toàn cục:
   ```bash
   npm install -g 9router
   ```
2. Khởi chạy dịch vụ 9Router:
   ```bash
   9router
   ```
3. Sau khi khởi chạy, truy cập bảng điều khiển (Dashboard) của 9Router thông qua trình duyệt web tại địa chỉ:
   [http://localhost:20128](http://localhost:20128) hoặc [http://localhost:20128/dashboard](http://localhost:20128/dashboard)

#### 🔑 Giai Đoạn 2: Cấu hình khóa API dự phòng (Multi-Account Setup)

1. Tại giao diện **9Router Dashboard**, truy cập mục **Providers**.
2. Chọn nhà cung cấp **Anthropic** (hoặc OpenAI/Gemini tùy thuộc vào tài khoản khác bạn muốn kết nối).
3. Nhập các API Key của tài khoản mới (tài khoản phụ, tài khoản mua thêm) mà bạn muốn sử dụng để thay thế. 
4. Thiết lập cơ chế **Combos** (Bản đồ định tuyến):
   *   Định nghĩa thứ tự ưu tiên: Tài khoản phụ 1 $\rightarrow$ Tài khoản phụ 2 $\rightarrow$ Các mô hình miễn phí/giá rẻ khác.
   *   Bật tính năng **RTK (Reverse Token Killer)** để tự động tối ưu hóa dữ liệu đầu vào.
5. Tạo hoặc lấy khóa API cục bộ do 9Router cấp (thường là một chuỗi ngẫu nhiên hoặc bạn có thể tự định nghĩa tại dashboard) để điền vào các công cụ lập trình AI.

#### 🛠️ Giai Đoạn 3: Kết nối các công cụ AI lập trình đến 9Router

Khi 9Router đã chạy ở cổng `20128`, bạn chỉ cần đổi Endpoint mặc định của các công cụ AI hướng về 9Router.

##### 1. Đối với Claude Code (Claude CLI trên Terminal)
Claude Code cho phép cấu hình biến môi trường hoặc chỉnh sửa file settings cục bộ để đổi base URL.

*   **Cách 1: Cấu hình qua File Settings (Khuyên dùng - Có hiệu lực vĩnh viễn)**
    *   Tạo hoặc chỉnh sửa file cấu hình dự án tại đường dẫn `.claude/settings.local.json` trong thư mục workspace hiện tại, hoặc cấu hình chung cho toàn hệ thống tại `~/.claude/settings.json`:
    ```json
    {
      "env": {
        "ANTHROPIC_BASE_URL": "http://127.0.0.1:20128/v1",
        "ANTHROPIC_API_KEY": "sk-9router-local-key-cua-ban"
      }
    }
    ```

*   **Cách 2: Sử dụng Biến Môi Trường (Shell Environment Variables)**
    *   Thêm các dòng sau vào file cấu hình shell của bạn (ví dụ: `~/.zshrc` hoặc `~/.bashrc` trên Mac):
    ```bash
    export ANTHROPIC_BASE_URL="http://127.0.0.1:20128/v1"
    export ANTHROPIC_API_KEY="sk-9router-local-key-cua-ban"
    ```
    *   Chạy lệnh sau để áp dụng thay đổi ngay lập tức:
    ```bash
    source ~/.zshrc
    ```

##### 2. Đối với Cursor
1. Mở Cursor, truy cập **Settings** $\rightarrow$ **Models**.
2. Tìm đến phần **OpenAI API** hoặc cấu hình **Custom Endpoint**.
3. Bật cấu hình và điền thông tin:
   *   **Base URL:** `http://localhost:20128/v1`
   *   **API Key:** Nhập API Key bất kỳ (hoặc khóa cục bộ từ 9Router Dashboard).
4. Lưu cấu hình. 9Router sẽ tự động đón nhận yêu cầu từ Cursor và dịch ngược sang định dạng của tài khoản Claude mới đang hoạt động.

---

## 📈 HIỆN THỰC HÓA GIÁ TRỊ (VALUE REALIZATION)

**Đo lường Tác động Kinh doanh & Kỹ thuật:**

| Hiện trạng (Current State) | Chuyển đổi (Transformation) | Trạng thái Mục tiêu (Target State) | Tác động (Impact) |
| :--- | :--- | :--- | :--- |
| Công việc bị dừng đột ngột khi tài khoản Claude chính hết quota hoặc bị Rate Limit. | ↓ TỰ ĐỘNG CHUYỂN HƯỚNG 9ROUTER ↓ | Hệ thống tự động chuyển tiếp sang các tài khoản phụ đang hoạt động trong danh sách. | ***100% Uptime, công việc phát triển không bị gián đoạn.*** |
| Chi phí API tăng vọt do truyền tải toàn bộ log terminal và mã nguồn nguyên bản. | ↓ KÍCH HOẠT RTK TOKEN SAVER ↓ | 9Router tự động nén log, loại bỏ dữ liệu rác trước khi gửi lên API. | ***Tiết kiệm 20% - 40% chi phí token đầu vào.*** |
| Khó khăn trong việc tích hợp nhiều loại tài khoản (Claude, OpenAI, Gemini) cùng lúc. | ↓ CHUẨN HÓA OPENAI ENDPOINT ↓ | Toàn bộ request được quy chuẩn hóa về địa chỉ local `http://localhost:20128/v1`. | ***Dễ dàng hoán đổi, thử nghiệm và tích hợp các mô hình AI mới chỉ trong 2 phút.*** |

---

## ⚠️ Lưu Ý Quan Trọng Về Bảo Mật

*   **Bảo mật cục bộ:** Hãy đảm bảo bạn sử dụng phiên bản 9Router mới nhất để vá các lỗ hổng thực thi mã từ xa (RCE) đã được phát hiện trước đó.
*   **Bảo mật Key:** Tuyệt đối không public file cấu hình `.claude/settings.local.json` chứa API key thật lên các kho lưu trữ mã nguồn công khai (GitHub/GitLab). Hãy thêm đường dẫn này vào `.gitignore`.
