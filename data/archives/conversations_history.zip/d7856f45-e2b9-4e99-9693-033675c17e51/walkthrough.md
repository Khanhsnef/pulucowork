# Data Insight & DataFlow Engine Dashboard

The complex Google Sheets data has been successfully transformed into a premium, interactive web dashboard. 

## Accomplishments
- **Data Parsing:** A Python script (`parse_data.py`) was written to parse the raw CSV export of the Google Sheet into a structured `data.json` file.
- **Premium UI Implementation:** `dashboard.html` was completely rewritten to use a modern, dark-themed "glassmorphism" aesthetic with a glowing background mesh, custom font (`Outfit`), and fluid hover animations.
- **Interactive Timeframe Filters:** The dashboard allows users to dynamically filter all insights (KPIs, Charts, and Channel lists) by timeframe toggles (`7 Days`, `30 Days`, and `All Time`).
- **Dynamic KPI Metrics:**
  - **Total Requests & Total Demand:** Accurately aggregated across all the dates.
  - **Conversion Rate:** Computed dynamically to show the ratio of Demand to Requests.
  - **Peak Demand Day:** Automatically identified the highest traffic day.
- **Interactive Charts:** Integrated `Chart.js` to render beautifully styled charts:
  - **Main Trend Line:** Visualizing total Requests vs. total Demand over time.
  - **Demand Composition Doughnut:** Breaking down the demand channels.
  - **Top Channel Activity List:** Dynamically ranking the channels by volume with progress indicators.

## Dashboard Preview

Here is a full demonstration of the dashboard running locally:

![Dashboard Demo Recording](/Users/ts-1148/.gemini/antigravity/brain/d7856f45-e2b9-4e99-9693-033675c17e51/dashboard_demo_1772706353050.webp)

And here is a demonstration of the synchronizing timeframe filters (both the top dropdown and the chart buttons):

![Time Filter Demo](/Users/ts-1148/.gemini/antigravity/brain/d7856f45-e2b9-4e99-9693-033675c17e51/top_filter_demo_1772707783865.webp)

### Section Screenshots
````carousel
![Top KPIs and Main Chart](/Users/ts-1148/.gemini/antigravity/brain/d7856f45-e2b9-4e99-9693-033675c17e51/dashboard_charts_top_1772706474764.png)
<!-- slide -->
![Middle Section with Donut Chart](/Users/ts-1148/.gemini/antigravity/brain/d7856f45-e2b9-4e99-9693-033675c17e51/dashboard_charts_middle_1772706475804.png)
<!-- slide -->
![Bottom Section with Top Channel Activity](/Users/ts-1148/.gemini/antigravity/brain/d7856f45-e2b9-4e99-9693-033675c17e51/dashboard_charts_bottom_1772706476830.png)
````

## How to use
To view the dashboard yourself:
1. Open a terminal in `/Users/ts-1148/Downloads/AI Agent - Testing`.
2. Run `python3 -m http.server 8000`.
3. Open a web browser and navigate to `http://localhost:8000/dashboard.html`.
