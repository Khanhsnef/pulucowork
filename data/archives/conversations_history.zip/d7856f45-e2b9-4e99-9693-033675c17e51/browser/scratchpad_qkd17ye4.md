# Task: Interact with Dashboard Filters

- [x] Open http://localhost:8000/dashboard.html
- [x] Wait 2 seconds
- [x] Click "Filter: All Time" button
- [x] Wait 1 second
- [x] Click "Last 30 Days"
- [x] Wait 1 second
- [x] Observe update and return success
