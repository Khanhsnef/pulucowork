# Dashboard Execution Plan

The goal is to build a fully dynamic and visually stunning dashboard in `dashboard.html` that reads the insights directly from the parsed `data.json` file.

## User Review Required
No breaking changes. The dashboard will continue to be a single HTML file (along with the generated `data.json` file) but will be drastically improved with real data fetched dynamically.

## Proposed Changes

### Dashboard Updates
#### [MODIFY] [dashboard.html](file:///Users/ts-1148/Downloads/AI%20Agent%20-%20Testing/dashboard.html)
- **Data Loading**: Implement a `fetch('data.json')` call to asynchronously load the Google Sheets data.
- **KPI Cards Construction**:
  - Calculate **Total Request** over the period.
  - Calculate **Total Demand** over the period.
  - Calculate **Overall Conversion Rate** (Demand / Request).
  - Identify the **Peak Demand Day** and display it.
- **Charts Generation (using Chart.js)**:
  - **Main Line Chart**: Compare Daily "Request" vs "Demand" over the provided timeline.
  - **Doughnut Chart**: Breakdown of Demand by sub-segments (`SME`, `MP`, `KA`, `GHN`, `TRUCK`, `WH`).
  - **Stacked Bar Chart**: Daily breakdown of Requests by segment.
- **UI/UX Polishing**:
  - Employ a premium modern dark mode aesthetic (already partially present, will refine styling, add micro-interactions, responsive grids).
  - Add formatting utilities for large numbers (e.g. `1,200,000` -> `1.2M`).

## Verification Plan

### Manual Verification
- The user will open `dashboard.html` in their Mac browser (e.g., Chrome or Safari). Since fetching `data.json` via the `file://` protocol may be blocked by CORS policies, the user should be advised to run a local dev server (e.g., `python3 -m http.server 8000`) and visit `http://localhost:8000/dashboard.html`.
- Verify the KPI cards show correct aggregations.
- Verify the charts render with the correct datasets.
