# Kế Hoạch Nâng Cấp Bảo Mật & Hiệu Năng PuluSmartFlow

Kế hoạch này chi tiết hóa việc nâng cấp hệ thống điều phối AI cục bộ **PuluSmartFlow** trên cả hai nền tảng macOS/Linux (`pulu_smartflow.sh`) và Windows PowerShell (`pulu_smartflow.ps1`) nhằm loại bỏ các lỗ hổng bảo mật credentials, sửa lỗi độ trễ gõ phím, tối ưu hóa định tuyến từ khóa và khắc phục cơ chế popup xin quyền của hệ thống.

## User Review Required

> [!IMPORTANT]
> **Thay đổi luồng lưu trữ API Key:** Toàn bộ API Key của 9Router/Anthropic sẽ không được hardcode hay lưu trữ dạng plain-text trong profile chính nữa. Thay vào đó, hệ thống sẽ tự động tìm và load từ tệp tin cấu hình bảo mật bên ngoài:
> *   **Mac/Linux:** `$HOME/.config/pulu/env.sh`
> *   **Windows:** `$env:USERPROFILE\.config\pulu\env.ps1`
> Người dùng cần điền API key vào các file này (được tạo tự động ở lần chạy đầu tiên) để hệ thống hoạt động bình thường.

## Proposed Changes

### 1. `_scripts/`

---

#### [MODIFY] [pulu_smartflow.sh](file:///Users/ts-1148/Desktop/Pulu-workspace/_scripts/pulu_smartflow.sh)
*   **Tách biệt và tải tệp cấu hình bảo mật:**
    *   Thêm logic kiểm tra sự tồn tại của thư mục `$HOME/.config/pulu` và tệp `env.sh`. Nếu chưa có, tự động tạo cấu trúc thư mục và file mẫu.
    *   Load các biến cấu hình thông qua lệnh `source`.
*   **Đồng bộ hóa Regex Route (định tuyến thông minh giai đoạn 1):**
    *   Đồng bộ hóa đầy đủ các từ khóa Regex định tuyến (thêm `sql`, `git`, `docker`, `k8s` vào nhóm **Sonnet - Max Coding**).
*   **Thêm hàm `smart_chat` (alias `chat`) cho chế độ tương tác:**
    *   Xây dựng hàm `smart_chat` tương tự bản PowerShell để khởi động Claude CLI trong môi trường TTY tương tác hoàn toàn (không dùng `-p` để tránh triệt tiêu TTY), cho phép hiển thị popup xác thực quyền (y/N) thay vì tự động bỏ qua.
*   **Thêm alias/hàm `use-9router` & `9router`:**
    *   `use-9router`: Thiết lập `export ANTHROPIC_BASE_URL="http://localhost:20128/api/v1"` để trỏ Claude CLI về proxy cục bộ.
    *   `9router`: Wrapper alias cho lệnh `9router` trên Mac/Linux.
*   **Thêm template Circuit Breaker chống đệ quy lặp vô hạn:**
    *   Tích hợp biến bảo vệ `_PULU_CNF_DEPTH` ngăn đệ quy vô hạn nếu tích hợp vào `command_not_found_handler`.

---

#### [MODIFY] [pulu_smartflow.ps1](file:///Users/ts-1148/Desktop/Pulu-workspace/_scripts/pulu_smartflow.ps1)
*   **Đồng bộ hóa Regex Route:**
    *   Thêm đầy đủ các từ khóa hệ thống/code (`git`, `docker`, `k8s`) vào Regex nhóm Sonnet (dòng 57 và 90) để đồng nhất với bản Mac/Linux.

---

## Verification Plan

### Automated Tests
*   Chạy cú pháp kiểm tra lỗi tĩnh:
    ```bash
    zsh -n _scripts/pulu_smartflow.sh
    ```

### Manual Verification
*   Nạp thử file profile mới trên terminal thực tế:
    ```bash
    source _scripts/pulu_smartflow.sh
    ```
*   Chạy lệnh `ai "phân tích tài chính"` -> Xác nhận hệ thống định tuyến về model **Opus**.
*   Chạy lệnh `ai "viết code python"` -> Xác nhận hệ thống định tuyến về model **Sonnet**.
*   Chạy lệnh `use-9router` -> Xác nhận biến môi trường `ANTHROPIC_BASE_URL` được thiết lập chính xác.
