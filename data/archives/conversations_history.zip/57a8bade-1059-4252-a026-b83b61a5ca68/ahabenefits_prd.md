# 🚀 PRODUCT REQUIREMENT DOCUMENT: HỆ THỐNG AHABENEFITS V2.0

## 1. TÓM TẮT THỰC THI (EXECUTIVE SUMMARY)

> [!NOTE]
> **Executive Summary:** Dự án AhaBenefits v2.0 (AhaPoints) là bước chuyển mình chiến lược nhằm thay đổi hành vi tài xế từ "cày cuốc ngắn hạn" sang "gắn kết dài hạn" thông qua cơ chế Gamification. Thay vì phụ thuộc hoàn toàn vào ngân sách incentive tiền mặt (Cash Promo) để giải quyết bài toán cung-cầu, hệ thống tích/đổi điểm (AhaPoints) cung cấp một rổ giá trị hữu hình (Value Realization) như voucher xăng, bảo dưỡng, nhu yếu phẩm, giúp giảm CPO dài hạn và tạo ra năng lực cạnh tranh cốt lõi.

**🎯 Mục tiêu Kinh doanh (Business Objectives - S-C-R Framework):**
*   **S - Tình huống (Situation):** Hiện tại, động lực của tài xế phụ thuộc quá nhiều vào thu nhập từng đơn và tiền thưởng mặt trong giờ cao điểm. Việc "đốt" ngân sách incentive dài hạn là không bền vững và không tối ưu được CPO.
*   **C - Thách thức (Complication):** Thiếu công cụ điều hướng hành vi tài xế (như chạy giờ khó, khu vực thời tiết xấu) mà không sử dụng tiền mặt. Tài xế thiếu gắn kết dài hạn với nền tảng, dễ rời bỏ (churn) khi nền tảng khác chạy khuyến mãi.
*   **R - Giải pháp (Resolution):** Xây dựng hệ thống tự động tích điểm (AhaPoints) theo đơn hàng và cửa hàng đổi thưởng in-app (AhaBenefits Store). Tính năng cung cấp giá trị quy đổi linh hoạt, giúp Ops điều phối supply dễ dàng thông qua hệ số nhân điểm (Multiplier) và tối ưu hóa ngân sách.

**📈 Chỉ số Cốt lõi (Important KPIs):**
*   **% Daily Active Drivers:** Tăng trưởng đều đặn (nhờ hiệu ứng thói quen).
*   **Acceptance Rate (AR) / Fulfillment Rate (FR):** Tăng thêm **2-3%** vào các khung giờ peak.
*   **Driver Churn Rate:** Giảm thiểu đáng kể.
*   **Tỷ lệ Burn Rate (Điểm đổi / Điểm phát):** Duy trì **> 60%**.
*   **Redemption Rate (% Voucher được sử dụng thành công tại điểm bán):** **> 80%** (Tỷ lệ drop-off tại trang chi tiết voucher < 20%).
*   **Ngân sách CPO (Cost Per Order):** Tối ưu và giảm tổng ngân sách dài hạn.

---

## 2. KHUNG PHÂN TÍCH (ANALYSIS FRAMEWORK)

### Phân tích Mô tả (Đánh giá Hiện trạng - Descriptive Analysis)
*   *Hạ tầng Vận hành hiện tại:* Điểm chạm lợi ích của tài xế chủ yếu ở mức độ đơn lẻ (theo chuyến). Việc điều phối Supply trong giờ cao điểm phụ thuộc hoàn toàn vào việc tăng giá hoặc thưởng tiền mặt. Chưa có hệ thống ví điểm in-app và luồng đổi thưởng trực tiếp trên Driver App.
*   *Benchmarks Hiệu suất:* Các đối thủ trong ngành (GrabRewards, BeLoyalty) đã có hệ thống tích điểm với hệ sinh thái đổi quà phong phú, tạo ra *barrier of exit* (rào cản rời bỏ) lớn đối với tài xế của họ.
*   *Hệ sinh thái Liên quan:* Đòi hỏi sự đồng bộ chặt chẽ giữa team Ops (cấu hình quy tắc điểm), team Product (xây dựng luồng trải nghiệm in-app), và team Business Development (phát triển mạng lưới đối tác cung cấp dịch vụ như xăng dầu, bảo dưỡng).

### Phân tích Chẩn đoán (Điều tra Nguyên nhân Gốc rễ - Diagnostic Analysis)
*   *Khoảng trống Chất lượng (Quality Gaps):* Hệ thống hiện tại thiếu các điểm neo tâm lý (gamification) để tài xế duy trì online khi thu nhập ca không đạt kỳ vọng ngắn hạn. Trải nghiệm nhận "quyền lợi" còn phân mảnh, chưa có nơi lưu trữ và quản lý tập trung.
*   *Điểm nghẽn Vận hành (Bottlenecks):* Việc tặng thưởng bằng tiền mặt làm căng thẳng P&L. Ops thiếu một công cụ "nhẹ" hơn tiền mặt để linh hoạt kích cung vào các điều kiện khó (mưa, kẹt xe) hoặc tại các hub chuyên biệt mà không làm biến dạng thị trường.

### Phân tích Dự báo (Mô hình hóa Tương lai - Predictive Analysis)
*   *Mô hình hóa Tác động (Impact Modeling):* Bằng việc thay thế một phần tỷ lệ % incentive tiền mặt bằng AhaPoints có chi phí vốn thấp hơn (nhờ các deal B2B với đối tác như chiết khấu voucher xăng/nhớt), ROI dự kiến sẽ dương. Điểm tích luỹ sẽ làm tăng Driver LTV (Lifetime Value) và giảm Churn Rate.
*   *Xác suất Thực thi (Implementation Probability):* Rất khả thi. Việc ứng dụng mô hình đổi điểm in-app tích hợp quét mã QR/Barcode tại điểm bán lẻ offline với flow dưới 3 clicks đảm bảo ma sát cực thấp, giúp Redemption Rate đạt mức mục tiêu > 80%.

### Phân tích Đề xuất (Khuyến nghị Chiến lược - Prescriptive Analysis)

Dưới đây là Lộ trình Tối ưu và Bản đồ Thực thi cho các tính năng cốt lõi của hệ thống AhaBenefits:

**A. Giao diện (UI) & Luồng thao tác (UX Flow)**
1.  **AhaBenefits Homepage:** Hiển thị Banner carousel (quảng cáo đối tác), số dư **AhaPoints** nổi bật, và Lịch sử giao dịch.
2.  **Danh mục Voucher (Tabbed Navigation):** Phân loại rõ ràng Xăng/Nhớt, Nhu yếu phẩm, AhaStore.
3.  **Chi tiết Voucher & Đổi quà:** Thông tin điều kiện, tỷ lệ quy đổi → Click "Đổi ngay" → Popup xác nhận trừ điểm → Hệ thống sinh mã QR/Barcode theo thời gian thực.
4.  **Tab "Quà của tôi":** Trạm lưu trữ toàn bộ voucher chưa sử dụng để truy xuất nhanh gọn khi tài xế có mặt tại cửa hàng offline.

**B. Luồng Tích Điểm (Earning Flow)**
*   **Công thức Base:** `earned_pts = round((trip_GSV ÷ 5.000) × layer_multiplier)`.
*   **Trạng thái Điểm:** Chuyến hoàn thành điểm tạm tính ở trạng thái `PENDING`. Sau khi kết ca và hệ thống validate (đủ % online in zone & điều kiện hoạt động), điểm sẽ được credit thành `AVAILABLE` vào lúc **T+1**, cộng thêm Bonus hoàn ca.
*   **Xử lý Edge Cases:** Đơn overflow nhận vào layer không khớp sẽ có hệ số `multiplier = 1.0` (không có bonus layer).

**C. Luồng Đổi Thưởng (Redemption Flow)**
*   **Xác thực Logic:** Kiểm tra Số dư `balance` hiện tại, Hạng `rank` tối thiểu, và Quỹ quà `reward slots` còn lại.
*   **Xử lý Giao dịch:** Chuyển điểm sang `RESERVED` trong lúc gọi Partner API (timeout 30s). Nếu thành công → `REDEEMED`. Nếu Partner API timeout hoặc lỗi → Hoàn điểm về `AVAILABLE`.
*   **Đặc quyền Rank 1 (Kim Cương):** Áp dụng luồng tự động đăng ký/gia hạn gói bảo hiểm tai nạn trước ngày 25 hàng tháng.

**D. Quản lý Vòng đời Điểm (Point Timeline & Adjustment)**
*   **Chính sách Hết hạn:** Điểm tự động hết hạn vào **23:59 ngày cuối cùng của mỗi Quý** (31/3, 30/6, 30/9, 31/12). *Lưu ý: Điểm đang `RESERVED` được bảo lưu không bị expire nếu giao dịch đổi thưởng vắt ngang kỳ reset.*
*   **Chế tài & Thưởng nóng (Adjustment System):** Hệ thống hoặc Ops có thể tiến hành trừ điểm (`-50 pts`) ngay khi xác nhận vi phạm ĐBCL/gian lận. Thưởng điểm đột xuất cho các chiến dịch Mega Sales. 

**E. Mô hình Dữ liệu (Data Model Requirements)**
*   **`PointTransaction`:** Ghi nhận mọi giao dịch với các loại `EARNED`, `BONUS`, `REDEEMED`, `DEDUCTED`, `EXPIRED`, `REFUNDED`, `ADJUSTED`.
*   **`DriverPointWallet`:** Cập nhật real-time trạng thái số dư `available_balance` và `reserved_balance`.
*   *(Nguyên tắc Bảo lưu)*: Rewards đã đổi thành công không bị thu hồi khi tài xế bị rớt hạng (Downgrade rank).

---

## 3. 📈 HIỆN THỰC HÓA GIÁ TRỊ (VALUE REALIZATION)

**Đo lường Tác động Kinh doanh (Measurable Business Impact):**

| Hiện trạng (Current State) | Chuyển đổi (Transformation) | Trạng thái Mục tiêu (Target State) | Tác động (Impact) |
| :--- | :--- | :--- | :--- |
| Động lực của Driver phụ thuộc hoàn toàn vào Incentive tiền mặt ngắn hạn, P&L áp lực cao tại các mốc peak hour. | ↓ GAMIFICATION & ĐIỂM THƯỞNG ↓ | Hệ thống AhaPoints thay thế linh hoạt một phần ngân sách bằng điểm thưởng quy đổi sinh thái quà tặng B2B. | ***Giảm % ngân sách CPO tổng & Tăng mạnh Loyalty dài hạn*** |
| Thiếu hụt tài xế cục bộ, khó điều hướng chạy các đơn khó hoặc tại khu vực thời tiết xấu. | ↓ DYNAMIC MULTIPLIER ↓ | Ops cấu hình hệ số nhân điểm (Multiplier) theo layer/thời tiết để tạo động lực mạnh mà không xả thẳng tiền mặt. | ***Tăng 2-3% Fulfillment/Acceptance Rate trong giờ Peak*** |
| Trải nghiệm nhận quyền lợi, voucher rời rạc, thủ công, không có nền tảng in-app để quản lý tài sản điểm. | ↓ NỀN TẢNG THỐNG NHẤT ↓ | Cửa hàng AhaBenefits Store & Tab "Quà của tôi" tích hợp trả mã QR/Barcode mượt mà, Zero lỗi đồng bộ. | ***Burn Rate > 60% & Redemption Rate > 80%*** |
